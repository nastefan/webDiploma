scram b
cmsRun Demo/DemoAnalyzer/demoanalyzer_cfg.py

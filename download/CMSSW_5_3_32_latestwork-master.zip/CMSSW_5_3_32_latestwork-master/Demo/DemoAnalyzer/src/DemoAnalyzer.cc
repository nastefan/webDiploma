// -*- C++ -*-
//
// Package:    DemoAnalyzer
// Class:      DemoAnalyzer
// 
/**\class DemoAnalyzer DemoAnalyzer.cc Demo/DemoAnalyzer/src/DemoAnalyzer.cc

 Description: [one line class summary]

 Implementation:
     [Notes on implementation]
*/
//
// Original Author:  
//         Created:  Mon May  4 15:24:13 CEST 2015
// $Id$
// ..
//

// *** UNDER CONSTRUCTION ! ***
// *** not (yet) for public use ! *** 

// **************************************************************************************
// version of DEMO setup provided by CMS open data access team               		*
// expanded/upgraded to contain validation examples for                      		*
// - general reference distributions (also technical)                        		*
// - minumum bias track multiplicities and pt/eta distributions (QCD-10-006) 		*
// - J/psi mass peak (BPH-10-002)                                            		*
// - dimuon mass spectrum (MUO-10-004)                                       		*
// - Z mass peak (EWK-10-)                                                   		*
// - inelastic proton-proton cross section (FWD-11-001)                      		*
//                                                                           		*
//                      I.Dutta and A.Geiser, 30.6.15                     		*
//									     		*
// Technical points: 									*
//							     				*
// - DL calculations implemented for J/Psi and D0 candidates		     		*
// - Possibility for Vertex Fit with CMS and ZEUS(has to check) fitter implemented	*
// - Created algorithm to select tracks from the Vertex and find SV			*
//										     	*
// 			N. Stefaniuk, 01.01.2016					*
// **************************************************************************************

// system include files
#include <memory>
// user include files
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "FWCore/Framework/interface/EDAnalyzer.h"

#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"

#include "FWCore/ParameterSet/interface/ParameterSet.h"


//------ ADD EXTRA HEADER FILES--------------------//
#include "math.h"
#include "FWCore/Framework/interface/EventSetup.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "FWCore/MessageLogger/interface/MessageLogger.h"
#include "FWCore/ServiceRegistry/interface/Service.h"
#include "CommonTools/UtilAlgos/interface/TFileService.h"
#include "DataFormats/Common/interface/Ref.h"
// for histogramming
#include "TH1.h"
#include "TH2.h"
#include "TH3.h"
#include "TStyle.h"
// for tracking information
#include "DataFormats/TrackReco/interface/Track.h"
#include "DataFormats/TrackReco/interface/TrackFwd.h"
#include "DataFormats/TrackReco/interface/HitPattern.h"
// for vertex information 
#include "DataFormats/VertexReco/interface/Vertex.h"
#include "DataFormats/VertexReco/interface/VertexFwd.h"
// for muon information
#include "DataFormats/MuonReco/interface/Muon.h"
#include "DataFormats/MuonReco/interface/MuonFwd.h"
#include "DataFormats/MuonReco/interface/MuonSelectors.h"
#include "DataFormats/MuonReco/interface/MuonIsolation.h"
//for beamspot information
#include "DataFormats/BeamSpot/interface/BeamSpot.h"
//for electron informaton
#include "DataFormats/EgammaCandidates/interface/GsfElectron.h"
#include "DataFormats/GsfTrackReco/interface/GsfTrack.h"

//for MET informaton

#include "DataFormats/METReco/interface/PFMET.h"
#include "DataFormats/METReco/interface/PFMETFwd.h"
#include "DataFormats/METReco/interface/CaloMET.h"
#include "DataFormats/METReco/interface/CaloMETFwd.h"
#include "DataFormats/METReco/interface/MET.h"
#include "DataFormats/METReco/interface/METFwd.h"

// for jet information
#include "DataFormats/Common/interface/Handle.h"
#include "DataFormats/Math/interface/deltaR.h"
#include "DataFormats/JetReco/interface/Jet.h"
#include "DataFormats/JetReco/interface/PFJet.h"
#include "DataFormats/JetReco/interface/PFJetCollection.h"
#include "DataFormats/JetReco/interface/TrackJetCollection.h"
#include "DataFormats/JetReco/interface/GenJet.h"
#include "DataFormats/JetReco/interface/GenJetCollection.h"
#include "DataFormats/JetReco/interface/JetExtendedAssociation.h"
#include "DataFormats/JetReco/interface/JetID.h"

// for vertices refit:
#include "TrackingTools/TransientTrack/interface/TransientTrackBuilder.h"
#include "TrackingTools/Records/interface/TransientTrackRecord.h"

#include "RecoVertex/AdaptiveVertexFit/interface/AdaptiveVertexFitter.h"
#include "RecoVertex/AdaptiveVertexFinder/interface/AdaptiveVertexReconstructor.h"
#include "RecoVertex/TrimmedKalmanVertexFinder/interface/KalmanTrimmedVertexFinder.h"

#include "RecoVertex/VertexPrimitives/interface/TransientVertex.h"
#include "RecoVertex/VertexPrimitives/interface/VertexException.h"
#include "TrackingTools/TransientTrack/interface/TrackTransientTrack.h"
//#include "TrackingTools/TransientTrack/interface/TransientTrack.h"

// for PVcies:
#include "RecoVertex/PrimaryVertexProducer/interface/PrimaryVertexProducerAlgorithm.h"

// Vertices: 
#include "RecoVertex/VertexTools/interface/VertexDistance3D.h"

/// for tracks: 
//#include "TrackingTools/TrajectoryParametrization/interface/CartesianTrajectoryError.h" 
#include "TrackingTools/TrajectoryParametrization/interface/GlobalTrajectoryParameters.h"
//#include "DataFormats/GeometryVector/interface/GlobalVector.h"
//#include "MagneticField/Engine/interface/MagneticField.h"
//#include "FWCore/Utilities/interface/Likely.h"
//#include "DataFormats/Math/interface/AlgebraicROOTObjects.h"
//#include "DataFormats/GeometrySurface/interface/Surface.h"
//#include "TrackingTools/TrajectoryParametrization/interface/LocalTrajectoryParameters.h"
#include "TrackingTools/TrajectoryParametrization/interface/PerigeeTrajectoryParameters.h"
#include "RecoVZero/VZeroFinding/interface/VZeroFinder.h"




/// new 
#include "Demo/DemoAnalyzer/src/inverceM.h"
#include "TMatrixT.h"
#include "Math/SMatrix.h"
#include "Math/StaticCheck.h"
//#include <MatrixRepresentationsStatic.h>
#include "Math/Expression.h"

#include <iostream>
using namespace std;
// class declaration
//

// #include "Demo/DemoAnalyzer/interface/vxlite/VertexFitter.cc"
#include "Demo/DemoAnalyzer/interface/vxlite/LinearizedTrack.hh"
#include "Demo/DemoAnalyzer/interface/vxlite/VertexFitter.hh"
// 
// #include "Demo/DemoAnalyzer/interface/vxlite/DAFVertexFinder.cc"
#include "Demo/DemoAnalyzer/interface/vxlite/DAFVertexFinder.hh"

using namespace VxLite;


#include "Demo/DemoAnalyzer/include/HelixTransClass.h"



class DemoAnalyzer : public edm::EDAnalyzer 
{
   public:
      explicit DemoAnalyzer(const edm::ParameterSet&);
      ~DemoAnalyzer();

  // declare variables
  double deltaz;
  double firstz;

   private:
      virtual void beginJob() ;
      virtual void analyze(const edm::Event&, const edm::EventSetup&);
      virtual void endJob() ;

  // ----------member data ---------------------------
  // declare histograms
  TH1D *histset[2000];
  TH2D *hxhy[1000];
};

//
// constants, enums and typedefs
//
double s1,s2,s,scorr,s3,s4,pz,rap,w,M, pt_jpsi;
double sqm1 = pow(0.105658,2);

//(0.105658)*(0.105658);
double mumass=0.105658;
double jpsim=3.097;
double Kmass=0.49367;
double Pimass=0.13957;
double MD0Actual=1.86484;  // [PDG]
double MDstarActual=2.01022;

double binsy[43]={1};
double binsz[101];

bool debug2 = false;

bool DmesonProduction = false;
bool DmesonsDL = false;

bool JpsiProduction = true;
bool JPsiDL = true;

bool VxliteProc = false;
//
// static data member definitions
//

//
// constructors and destructor


DemoAnalyzer::DemoAnalyzer(const edm::ParameterSet& iConfig)

{
  //now do what ever initialization is needed
  edm::Service<TFileService> fs;
//Loop for
    for (int i=0; i!=43; i++){
        
        if (i>=0 && i<=19) binsy[i]= 0.1*i;
        else if (i>19 && i<=30) binsy[i]=2+(i-20)*0.5;
        else if (i>=31 && i<=38) binsy[i]=8+(i-31);
        else if (i==39) binsy[i]=17;
        else if (i==40) binsy[i]=20;
        else if (i==41) binsy[i]=25;
        else if (i==42) binsy[i]=30;
        //cout<< binsy[i] << endl;
    }

  ////////------------------------------------ Book Histograms ------------------------------------////////
    // define subfolders;
    TFileDirectory muon       = fs->mkdir( "Muons" );
    TFileDirectory TMmuon     = fs->mkdir( "TMuons" );
    TFileDirectory Gmuon      = fs->mkdir( "GMuons" );
    TFileDirectory pfjetsF    = fs->mkdir( "PFJets" );
    TFileDirectory PrVertex   = fs->mkdir( "PrVertex" );
    TFileDirectory tracks     = fs->mkdir( "Tracks" );
    TFileDirectory electron   = fs->mkdir( "Electrons" );
    TFileDirectory acceptance = fs->mkdir( "Acceptance");
    TFileDirectory dmesonsBridget    	= fs->mkdir( "DMesons_Bridget" );
    TFileDirectory dmesonsAtlas    	= fs->mkdir( "DMesons_Atlas_cuts" );
    TFileDirectory dmesonsAtlasWS    	= fs->mkdir( "DMesons_Atlas_cutsWS" );
    TFileDirectory dmesonsCommon    	= fs->mkdir( "DMesons_Common" );
    TFileDirectory upsilon    = fs->mkdir( "Upsilons");
    TFileDirectory jpsi       = fs->mkdir( "J_Psi" ); 
    TFileDirectory RevertexDL = fs->mkdir( "RevertexDL" ); 
    TFileDirectory bplus      = fs->mkdir( "B+" );	

    
    
    // book histograms
    //-------------------------Minimum Bias---------------------------------//
    {
        /*
    histset[300]  = pfjetsF.make<TH1D>("PFJets_PT" , "PFJets_PT" , 200 , 0 , 20 );
    histset[300]->GetXaxis()->SetTitle("PFJets PT");
    histset[300]->GetYaxis()->SetTitle("Number of PFJets");
    
    histset[301]  = pfjetsF.make<TH1D>("PFJets_Eta" , "PFJets_Eta" , 100 , -7.0 , 7.0 );
    histset[301]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[301]->GetYaxis()->SetTitle("Number of PFJets");
    
    histset[302]  = pfjetsF.make<TH1D>("TrackJets_PT" , "TrackJet_PT" , 200 , 0 , 20 );
    histset[302]->GetXaxis()->SetTitle("TrackJets PT");
    histset[302]->GetYaxis()->SetTitle("Number of PFJets");
    
    histset[303]  = pfjetsF.make<TH1D>("TrackJets_Eta" , "TrackJets_Eta" , 100 , -7.0 , 7.0 );
    histset[303]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[303]->GetYaxis()->SetTitle("Number of PFJets");
    
    histset[304]  = pfjetsF.make<TH1D>("TrackJet.Ntracks" , "TrackJet.Ntracks" , 35 , 0 , 35.0 );
    histset[304]->GetXaxis()->SetTitle("Ntracks");
    histset[304]->GetYaxis()->SetTitle("Number of TrackJets");
    
    histset[305]  = pfjetsF.make<TH1D>("TrackJet.fromHardVertex" , "TrackJet.fromHardVertex" , 20 , -5 , 5.0 );
    histset[305]->GetXaxis()->SetTitle("FromHardVertex");
    histset[305]->GetYaxis()->SetTitle("Number of TrackJets");
    
    histset[306]  = pfjetsF.make<TH1D>("TrackJet.primaryVertex.tracksSize" , "TrackJet.primaryVertex.tracksSize" , 100 , 0 ,200.0 );
    histset[306]->GetXaxis()->SetTitle("N tracks in the assosiated Primary Vertex");
    histset[306]->GetYaxis()->SetTitle("Number of TrackJets");
    */


    histset[300] = PrVertex.make<TH1D>("posx_ZEUSfit", "Position X",100, 0.0,.2); 					// Track position x
    histset[301] = PrVertex.make<TH1D>("posy_ZEUSfit", "Position Y",100, -.1,.1);					// track position y
    histset[302] = PrVertex.make<TH1D>("posz_ZEUSfit", "Position Z",100, -25.0,25.0); 					// Track position z
    histset[303] = PrVertex.make<TH1D>("vertexDistance", "vertexDistance",400, 0 , 2.0); 				// Track position z
    histset[304] = PrVertex.make<TH1D>("Chi2_ndof_ZEUSfit", "Chi2_ndof",50, 0., 5.0);
    histset[305] = PrVertex.make<TH1D>("Chi2_ndof", "Chi2_ndof",50, 0., 5.0);


    //----------------------------------------------------------------------//
    histset[6]  = tracks.make<TH1D>("tracks" , "Tracks" , 300 , 0 , 300 ); 					// Track Multiplicity
    
    histset[34] = tracks.make<TH1D>("momentum", "Momentum",200, 0,20.0); 					// Track momentum
    histset[35] = tracks.make<TH1D>("pt", "PT",200, 0,4.0); 							// Track pt
    histset[36] = PrVertex.make<TH1D>("posx", "Position X",100, 0.0,.2); 					// Track position x
    histset[37] = PrVertex.make<TH1D>("posy", "Position Y",100, -.1,.1);					// track position y
    histset[7]  = PrVertex.make<TH1D>("posz", "Position Z",100, -25.0,25.0); 					// Track position z
    histset[38] = tracks.make<TH1D>("eta", "Eta",100, -3.5,3.5); 						// Track eta
    histset[81] = tracks.make<TH1D>("track_phi", "Track_Phi",314, -3.15,3.15); 				// Track phi
    histset[8]  = PrVertex.make<TH1D>("propvertex" , "ProperVertices" , 20 , 0 , 20 ); 			// Proper vertices, i.e.after checking the number of tracks for the vertex
    histset[9]  = tracks.make<TH1D>("0.2pt" , "0.2pt" , 100 , 0 , 4.0 );					// Tracks with absolute value of eta less than 0.2
    histset[10] = tracks.make<TH1D>("0.4pt" , "0.4pt" , 100 , 0 , 4.0 );					// Tracks with absolute value mof eta between 0.2 and 0.4
    histset[11] = tracks.make<TH1D>("0.6pt" , "0.6pt" , 100 , 0 , 4.0 );					// and so on...
    histset[12] = tracks.make<TH1D>("0.8pt" , "0.8pt" , 100 , 0 , 4.0 );
    histset[13] = tracks.make<TH1D>("1.0pt" , "1.0pt" , 100 , 0 , 4.0 );
    histset[14] = tracks.make<TH1D>("1.2pt" , "1.2pt" , 100 , 0 , 4.0 );
    histset[15] = tracks.make<TH1D>("1.4pt" , "1.4pt" , 100 , 0 , 4.0 );
    histset[16] = tracks.make<TH1D>("1.6pt" , "1.6pt" , 100 , 0 , 4.0 );
    histset[17] = tracks.make<TH1D>("1.8pt" , "1.8pt" , 100 , 0 , 4.0 );
    histset[18] = tracks.make<TH1D>("2.0pt" , "2.0pt" , 100 , 0 , 4.0 );
    histset[19] = tracks.make<TH1D>("2.2pt" , "2.2pt" , 100 , 0 , 4.0 );
    histset[20] = tracks.make<TH1D>("2.4pt" , "2.4pt" , 100 , 0 , 4.0 );
    histset[21] = tracks.make<TH1D>("2.6pt" , "2.6pt" , 100 , 0 , 4.0 );
    histset[22] = PrVertex.make<TH1D>("deltaz" , "DeltaZ" , 300 , 0 , 30.0 );				// the absolute value of the distance in the z coordinate of all vertices from Primvertex->begin()
    //histset[23] = fs->make<TH1D>("track_vertex_x" , "TrackVertexX" , 100 , -30.0 , 30.0 );
    //histset[24] = fs->make<TH1D>("track_vertex_y" , "TrackVertexY" , 100 , -30.0 , 30.0 );
    //histset[25] = fs->make<TH1D>("track_vertex_z" , "TrackVertexZ" , 100 , -30.0 , 30.0 );
    histset[26] = PrVertex.make<TH1D>("vertex" , "Vertices" , 20 , 0 , 20 ); 				// Just vertex multiplicity, without any corrections
    
    histset[27] = PrVertex.make<TH1D>("VertexTrack_pt", "Vertex.Track_Pt",200,0,4.0); 			// Pt of tracks associated with a particular vertex
    histset[28] = PrVertex.make<TH1D>("VertexTrack_momentum", "VertexTrack_Momentum",200, 0,20.0); 	// Track momentum
    histset[82] = PrVertex.make<TH1D>("Vertex.Track_phi", "Vertex.Track_Phi",100, -3.5,3.5); 		//Track phi
    
    // set axis labels
    
    histset[34]->GetXaxis()->SetTitle("Momentum (in GeV/c)");
    histset[34]->GetYaxis()->SetTitle("Number of Events");
    
    histset[35]->GetXaxis()->SetTitle("Transverse Momentum (in GeV/c)");
    histset[35]->GetYaxis()->SetTitle("Number of Events");
    
    histset[36]->GetXaxis()->SetTitle("Position X of Vertices (in cm)");
    histset[36]->GetYaxis()->SetTitle("Number of Events");
    
    histset[37]->GetXaxis()->SetTitle("Position Y of Vertices (in cm)");
    histset[37]->GetYaxis()->SetTitle("Number of Events");
    
    histset[7]->GetXaxis()->SetTitle("Position z of Vertices (in cm)");
    histset[7]->GetYaxis()->SetTitle("Number of Events");
    
    histset[38]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[38]->GetYaxis()->SetTitle("Number of Events");
    
    histset[8]->GetXaxis()->SetTitle("Number of vertices with a non zero number of tracks associated to it");
    histset[8]->GetYaxis()->SetTitle("Number of Events");
    
    histset[9]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<0.2(in GeV/c)");
    histset[9]->GetYaxis()->SetTitle("Number of Events");
    histset[9]->SetLineColor(kRed);
    
    histset[10]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<0.4 and |eta|>=0.2(in GeV/c)");
    histset[10]->GetYaxis()->SetTitle("Number of Events");
    
    histset[11]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<0.6 and |eta|>=0.4(in GeV/c)");
    histset[11]->GetYaxis()->SetTitle("Number of Events");
    
    histset[12]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<0.8 and |eta|>=0.6(in GeV/c)");
    histset[12]->GetYaxis()->SetTitle("Number of Events");
    
    histset[13]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<1.0 and |eta|>=0.8(in GeV/c)");
    histset[13]->GetYaxis()->SetTitle("Number of Events");
    
    histset[14]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<1.2 and |eta|>=1.0(in Gev/c)");
    histset[14]->GetYaxis()->SetTitle("Number of Events");
    
    histset[15]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<1.4 and |eta|>=1.2(in GeV/c)");
    histset[15]->GetYaxis()->SetTitle("Number of Events");
    
    histset[16]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<1.6 and |eta|>=1.4(in GeV/c)");
    histset[16]->GetYaxis()->SetTitle("Number of Events");
    
    histset[17]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<1.8 and |eta|>=1.6(in Gev/c)");
    histset[17]->GetYaxis()->SetTitle("Number of Events");
    
    histset[18]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<2.0 and |eta|>=1.8(in GeV/c)");
    histset[18]->GetYaxis()->SetTitle("Number of Events");
    
    histset[19]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<2.2 and |eta|>=2.0(in Gev/c)");
    histset[19]->GetYaxis()->SetTitle("Number of Events");
    
    histset[20]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<2.4 and |eta|>=2.2(in GeV/c)");
    histset[20]->GetYaxis()->SetTitle("Number of Events");
    
    histset[21]->GetXaxis()->SetTitle("Transverse Momentum for |eta|<2.6 and |eta|>=2.4(in GeV/c)");
    histset[21]->GetYaxis()->SetTitle("Number of Events");
    
    histset[22]->GetXaxis()->SetTitle("Absolute value of the z distance of Vertices from the first primary vertex (in cm)");
    histset[22]->GetYaxis()->SetTitle("Number of Events");
    
    histset[26]->GetXaxis()->SetTitle("Vertex multiplicity");
    histset[26]->GetYaxis()->SetTitle("Number of Events");
    
    histset[28]->GetXaxis()->SetTitle("Momentum of tracks associated with a vertex (in GeV/c)");
    histset[28]->GetYaxis()->SetTitle("Number of Events");
    
    histset[27]->GetXaxis()->SetTitle("Transverse Momentum of tracks associated with a vertex (in GeV/c)");
    histset[27]->GetYaxis()->SetTitle("Number of Events");
    
    
    //------------------------------Muons and Onia--------------------------------------//
    // use either global muons from inclusive Mu sample
    // or tracker muons from Onia sample (preselected 2.5<m<4.1 GeV)
    
    
    histset[1] = Gmuon.make<TH1D>("GMmomentum" , "GM_Momentum" , 240 , 0. , 120. );				//TrackCollection_GMuon momentum
    histset[2] = Gmuon.make<TH1D>("GM_Transverse_momentum" , "TransverseMomentum" , 240 , 0. , 120. );	//TrackCollection_GMuon Transverse_momentum
    histset[3] = Gmuon.make<TH1D>("GM_eta" , "GM_Eta" , 140 ,-3.5 , 3.5 );					//TrackColletion_GMuon eta
    histset[83]= Gmuon.make<TH1D>("GM_phi", "GM_phi",314, -3.15,3.15);
    histset[4] = Gmuon.make<TH1D>("GMmultiplicty" , "GMmultiplicity" , 8 , 0 , 8 );				//TrackCollection_GMuon multiplicity
    histset[5] = Gmuon.make<TH1D>("GMmass" , "GMmass" ,120 , 0. , 12. );					//TrackCollection_GMuon mas
    histset[44]= Gmuon.make<TH1D>("GMmass_extended" , "GMmass" ,120 , 0. , 120. );				//TrackCollection_GMuon mass
    histset[29]= muon.make<TH1D>("Muon_momentum" , "Muon_momentum" ,100 , 0. , 20. );			//MuonCollection_ momentum
    histset[30]= muon.make<TH1D>("Muon_pt" , "Muon_PT" ,100 , 0. , 20. );					//MuonCollection_pt
    histset[31]= muon.make<TH1D>("Muon_eta" , "Muon_eta" ,140 , -3.5 , 3.5 );				//MuonCollection_ eta
    histset[84]= muon.make<TH1D>("Muon_phi", "Muon_phi",314, -3.15,3.15);
    histset[32]= TMmuon.make<TH1D>("TM_mass" , "TM_mass" ,120 , 0. , 12. );					//MuonCollection_TMuon mass
    histset[33]= muon.make<TH1D>("NMuons" , "Muon_Size" ,10 , 0. ,10  );					//MuonCollection_Muon size
    
    histset[39]= TMmuon.make<TH1D>("TM_mass1.2_j_psi" , "TM_mass" ,90 ,2.6  , 3.5 );				//MuonCollection_TMuon mass_j/psi
    histset[40]= TMmuon.make<TH1D>("TM_mass1.6_j_psi" , "TM_mass" ,90 , 2.6 , 3.5 );				//MuonCollection_TMuon mass_j/psi
    histset[41]= TMmuon.make<TH1D>("TM_mass2.4_j_psi" , "TM_mass" ,90 ,2.6 , 3.5 );				//MuonCollection_TMuon mass_j/psi
    
    histset[42]= TMmuon.make<TH1D>("TM_mass1_upsilon" , "TM_mass" ,80 ,8.  , 12. );				//MuonCollection_TMuon mass_upsilon
    
    histset[43]= TMmuon.make<TH1D>("TM_mass2.4_upsilon" , "TM_mass" ,80 ,8. ,12. );				//MuonCollection_TMuon mass_ upsilon
    histset[45]= TMmuon.make<TH1D>("TM_mass_likeCharges" , "TM_mass_Like Charges" ,120 , 0. , 12. );		//MuonCollection_TMuon mass_ FOR LIKE CHARGES
    histset[46]= Gmuon.make<TH1D>("GM_mass_likeCharges" , "GM_mass_Like Charges" ,120 , 0. , 12. );		//TrackCollection_GMuon mass_ FOR LIKE CHARGES
    
    
    histset[47]= Gmuon.make<TH1D>("GM_mass1.2_j_psi" , "GM_mass" ,90 ,2.6  , 3.5 );				//TrackCollection_GMuon mass_j/psi
    histset[48]= Gmuon.make<TH1D>("GM_mass1.6_j_psi" , "GM_mass" ,90 , 2.6 , 3.5 );				//TrackCollection_GMuon mass_j/psi
    histset[49]= Gmuon.make<TH1D>("GM_mass2.4_j_psi" , "GM_mass" ,90 ,2.6 , 3.5 );				//TrackCollection_gMuon mass_j/psi
    
    histset[50]= TMmuon.make<TH1D>("TM_chi2" , "TM_Chi2" ,500 ,0 , 100 );					//MuonCollection
    histset[51]= TMmuon.make<TH1D>("TM_Ndof" , "TM_Ndof" ,60 ,0 , 60 );					//MuonCollection
    histset[52]= TMmuon.make<TH1D>("TM_NormalizedChi2" , "TM_NormalizedChi2" ,200 ,0 , 20 );			//MuonCollection
    
    histset[53]= Gmuon.make<TH1D>("GM_chi2" , "GM_Chi2" ,300 ,0 , 150 );					//TrackCollection
    histset[54]= Gmuon.make<TH1D>("GM_ndof" , "GM_ndof" ,100 ,0 , 100 );					//TrackCollection
    histset[55]= Gmuon.make<TH1D>("GM_normalizedchi2" , "GM_normalizedChi2" ,200 ,0 , 20 );			//TrackCollection
    
    histset[56]= muon.make<TH1D>("Muon_chi2" , "Muon_Chi2" ,500 ,0 , 100 );				//MuonCollection
    histset[57]= muon.make<TH1D>("Muon_Ndof" , "Muon_Ndof" ,60 ,0 , 60 );					//MuonCollection
    histset[58]= muon.make<TH1D>("Muon_NormalizedChi2" , "Muon_NormalizedChi2" ,200 ,0 , 20 );		//MuonCollection
    
    histset[59]= Gmuon.make<TH1D>("GM_HitsOK" , "GM_Tracks with good Hits" ,10 ,0 , 10 );			//TrackCollection
    
    histset[60]= Gmuon.make<TH1D>("GM_validhits" , "GM_ValidHits" ,100, 0. ,100 );				//TrackCollection
    histset[61]= Gmuon.make<TH1D>("GM_pixelhits" , "GM_pixelhits" ,14 , 0. ,14 );				//TrackCollection
    
    histset[62]= TMmuon.make<TH1D>("TM_HitsOK" , "TM_Tracks with good Hits" ,10 ,0 , 10 );			//MuonCollection
    
    histset[63]= TMmuon.make<TH1D>("TM_validhits" , "TM_ValidHits" ,40, 0. ,40 );				//MuonCollection
    histset[64]= TMmuon.make<TH1D>("TM_pixelhits" , "TM_pixelhits" ,14 , 0. ,14 );				//MuonCollection
    
    
    histset[65]= TMmuon.make<TH1D>("TM_mass_C" , "TM_mass" ,120 , 0. , 12. );				//MuonCollection_TMuon mass_corrected
    histset[66]= Gmuon.make<TH1D>("GMmass_C" , "GMmass" ,120 , 0. , 12. );					//TrackCollection_GMuon mass_corrected
    histset[67]= Gmuon.make<TH1D>("GMmass_extended_C" , "GMmass" ,120 , 0. , 120. );			//TrackCollection_GMuon mass_corrected
    
    histset[68]= Gmuon.make<TH1D>("GM_mass1.2_j_psi_C" , "GM_mass" ,90 ,2.6  , 3.5 );			//TrackCollection_GMuon mass_j/psi
    histset[69]= Gmuon.make<TH1D>("GM_mass1.6_j_psi_C" , "GM_mass" ,90 , 2.6 , 3.5 );			//TrackCollection_GMuon mass_j/psi
    histset[70]= Gmuon.make<TH1D>("GM_mass2.4_j_psi_C" , "GM_mass" ,90 ,2.6 , 3.5 );			//TrackCollection_gMuon mass_j/psi
    
    histset[71]= TMmuon.make<TH1D>("TM_mass1_upsilon_C" , "TM_mass" ,80 ,8.  , 12. );			//MuonCollection_TMuon mass_upsilon
    
    histset[72]= TMmuon.make<TH1D>("TM_mass2.4_upsilon_C" , "TM_mass" ,80 ,8. ,12. );			//MuonCollection_TMuon mass_ upsilon
    
    
    histset[73]= TMmuon.make<TH1D>("TM_mass1.2_j_psi_C" , "TM_mass" ,90 ,2.6  , 3.5 );			//MuonCollection_TMuon mass_j/psi
    histset[74]= TMmuon.make<TH1D>("TM_mass1.6_j_psi_C" , "TM_mass" ,90 , 2.6 , 3.5 );			//MuonCollection_TMuon mass_j/psi
    histset[75]= TMmuon.make<TH1D>("TM_mass2.4_j_psi_C" , "TM_mass" ,90 ,2.6 , 3.5 );			//MuonCollection_TMuon mass_j/psi
    
    histset[76]= Gmuon.make<TH1D>("GM_mass1_upsilon" , "GM_mass" ,80 ,8.  , 12. );				//TrackCollection_TMuon mass_upsilon
    
    histset[77]= Gmuon.make<TH1D>("GM_mass2.4_upsilon" , "GM_mass" ,80 ,8. ,12. );				//TrackCollection_TMuon mass_ upsilon
    
    histset[78]= Gmuon.make<TH1D>("GM_mass1_upsilon_C" , "GM_mass" ,80 ,8.  , 12. );			//TrackCollection_TMuon mass_upsilon
    
    histset[79]= Gmuon.make<TH1D>("GM_mass2.4_upsilon_C" , "GM_mass" ,80 ,8. ,12. );			//TrackCollection_TMuon mass_ upsilon
    
    histset[80]= Gmuon.make<TH1D>("GM_Zmass", "GM_Zmass",30, 60.0,120.0);
    histset[94]= Gmuon.make<TH1D>("GM_Zmass_cuts", "GM_Zmass_cuts",30, 60.0,120.0);
    
    histset[95]= Gmuon.make<TH1D>("GM_Zmass_cuts_like_charges", "GM_Zmass_cuts_like_charges",30, 60.0,120.0);
    
    histset[85]= PrVertex.make<TH1D>("Vertex.Track_eta", "Vertex.Track_Eta",100, -3.5,3.5); 					//Track eta if Muon not found
    
    histset[86]= PrVertex.make<TH1D>("tracks_per_vertex_using_counter" , "Tracks per Vertex using counter" , 200 , 0 , 200 );	// Track Multiplicity
    histset[87]= PrVertex.make<TH1D>("tracks_per_vertex" , "Tracks per Vertex" , 200 , 0 , 200 );					// Track Multiplicity
    
    histset[88]= Gmuon.make<TH1D>("dx_muon" , "dx_muon" , 100 , 0 , 1 );
    histset[89]= Gmuon.make<TH1D>("dy_muon" , "dy_muon" , 100 , 0 , 1 );
    histset[90]= Gmuon.make<TH1D>("dz_muon" , "dz_muon" , 200 , 0 , 2 );
    histset[91]= Gmuon.make<TH1D>("dxy_Gmuon" , "dxy_gmuon" , 100 , 0 , 1 );
    histset[92]= Gmuon.make<TH1D>("goodMuonChamberHit_Gmuon" , "goodMuonChamberHit_gmuon" , 40,0 , 40 );
    histset[93]= Gmuon.make<TH1D>("MuonStations_Tmuon" , "MuonStations_Tmuon" , 2,0 , 2 );
    
    histset[96]= electron.make<TH1D>("Electron_momentum" , "Electron_momentum" ,400 , 0. , 200. );		//ElectronCollection_ momentum
    histset[97]= electron.make<TH1D>("Electron_pt" , "Electron_PT" ,400 , 0. , 200. );				//ElectronCollection_pt
    histset[98]= electron.make<TH1D>("Electron_eta" , "Electron_eta" ,140 , -3.5 , 3.5 );			//ElectronCollection_ eta
    histset[99]= electron.make<TH1D>("Electron_phi", "Electron_phi",314, -3.17,3.17);
    histset[104]= electron.make<TH1D>("Z_electron_mass" , "electron_mass" ,30 , 60. , 120. );			//ElectronCollection mass
    histset[105]= electron.make<TH1D>("Nelectrons" , "Electron_Size" ,10 , 0. ,10  );				//ElectronCollection_Muon size
    histset[106]= electron.make<TH1D>("Super Cluster_eta" , "Super Cluster_eta" ,140 , 0 , 3.5 );		//Electron super cluster_ eta
    histset[107]= electron.make<TH1D>("Super Cluster_rawenergy" , "Super Cluster_rawenergy" ,200 , 0 , 200 );	//Electron super cluster_ energy
    histset[118]= electron.make<TH1D>("Electron Et" , "Electron Et" ,200 , 0 , 200 );				//Electron et
    
    histset[119]= electron.make<TH1D>("Z_electron_mass_cuts" , "electron_mass_cuts" ,30 , 60. , 120. );	//ElectronCollection mass
    histset[108]= electron.make<TH1D>("Barrel_Electron_track isolation" , "Barrel_Electron Track Isolation" ,500 , 0. , 0.5 );
    histset[109]= electron.make<TH1D>("Barrel_Electron_Ecal isolation" , "Barrel_Electron ECAL Isolation" ,500 , 0. ,0.5 );
    histset[110]= electron.make<TH1D>("Barrel_Electron_hcal isolation" , "Barrel_Electron HCAL Isolation" ,500 , 0. ,0.5 );
    histset[111]= electron.make<TH1D>("Electron_track missing hit" , "Electron Track missing hits" ,5 , 0. ,5);
    histset[112]= electron.make<TH1D>("Electron_Dcot" , "Electron Dcot" ,1000 , -0.05 ,0.05);
    histset[113]= electron.make<TH1D>("Electron_Dist" , "Electron Dist" ,1000 , -0.05 ,0.05);
    histset[114]= electron.make<TH1D>("Barrel_Electron_sigmaIetaIeta" , "Barrel_Electron sigmaIetaIeta" ,300 , 0. ,0.03);
    histset[115]= electron.make<TH1D>("Barrel_Electron_deltaphi" , "Barrel_Electron deltaphi" ,10000 , -0.5 ,0.5);
    histset[116]= electron.make<TH1D>("Barrel_Electron_deltaeta" , "Barrel_Electron deltaeta" ,10000 , -0.05 ,0.05);
    histset[117]= electron.make<TH1D>("Barrel_Electron_H/E" , "Barrel_Electron H/E" ,1200 , 0. ,0.2);
    
    
    histset[120]= electron.make<TH1D>("Endcap_Electron_track isolation" , "Endcap_Electron Track Isolation" ,500 , 0. , 0.5 );
    histset[121]= electron.make<TH1D>("Endcap_Electron_Ecal isolation" , "Endcap_Electron ECAL Isolation" ,500 , 0. ,0.5 );
    histset[122]= electron.make<TH1D>("Endcap_Electron_hcal isolation" , "Endcap_Electron HCAL Isolation" ,500 , 0. ,0.5 );
    histset[123]= electron.make<TH1D>("Endcap_Electron_sigmaIetaIeta" , "Endcap_Electron sigmaIetaIeta" ,1000 , 0. ,0.1);
    histset[124]= electron.make<TH1D>("Endcap_Electron_deltaphi" , "Endcap_Electron deltaphi" ,1000 , -0.5,0.5);
    histset[125]= electron.make<TH1D>("Endcap_Electron_deltaeta" , "Endcap_Electron deltaeta" ,400 , -0.01 ,0.01);
    histset[126]= electron.make<TH1D>("Endcap_Electron_H/E" , "Endcap_Electron H/E" ,1000 , 0. ,0.1);
    histset[127]= electron.make<TH1D>("Z_electron_mass_likeCharges" , "electron_mass_likeCharges" ,30 , 60. , 120. );		//ElectronCollection mass
    histset[128]= electron.make<TH1D>("Z_electron_mass_cuts_likeCharges" , "electron_mass_cuts_likeCharges" ,30 , 60. , 120. );//ElectronCollection mass
    histset[129]= electron.make<TH1D>("W_muon_transverseMass" , "muon_transverseMass" ,30 , 0. , 120. );			//MuonCollection mass
    histset[130]= electron.make<TH1D>("W_muon_transverseMass_cuts" , "muon_transverseMass_cuts" ,30 , 0. , 120. );		//MuonCollection mass
    histset[131]= electron.make<TH1D>("W_electron_transverseMass" , "electron_transverseMass" ,30 , 0. , 120. );		//ElectronCollection mass
    histset[132]= electron.make<TH1D>("W_electron_transverseMass_cuts" , "electron_transverseMass_cuts" ,30 , 0. , 120. );	//ElectronCollection mass
    histset[133]= electron.make<TH1D>("Event_PFMET" , "Event_PFMET" ,28 , 0. , 70. );						//ElectronCollection MET for W's
    histset[134]= electron.make<TH1D>("Event_CaloMET" , "Event_CaloMET" ,28 , 0. , 70. );					//ElectronCollection MET for W's
    histset[135]= electron.make<TH1D>("muonCorrCaloMET" , "muonCorrCaloMET" ,28 , 0. , 70. );					//ElectronCollection MET for W's
    histset[136]= electron.make<TH1D>("Event_PFMET_electroncuts" , "Event_PFMET" ,28 , 0. , 70. );				//ElectronCollection MET for W's
    histset[137]= electron.make<TH1D>("Event_PFMET_muoncuts" , "Event_PFMET" ,28 , 0. , 70. );					//ElectronCollection MET for W's
    histset[138]= electron.make<TH1D>("Electron_Z_Dcot" , "Electron Dcot" ,1000 ,-0.5 ,0.5);
    histset[139]= electron.make<TH1D>("Electron_Z_Dist" , "Electron Dist" ,1000 ,-0.5 ,0.5);
    
    
    
    
    
    // change binning to correspond to log(0.3) - log(500), 200 bins/log10 unit
    histset[100] = Gmuon.make<TH1D>("GM_mass_log", "GM mass log", 644, -.52, 2.7 );					//TrackCollection_GMuon mass
    histset[101] = TMmuon.make<TH1D>("TM_mass_log", "TM mass log", 644, -.52, 2.7 );					//MuonCollection_TMuon mass
    histset[102] = Gmuon.make<TH1D>("GM_mass_log_likecharges", "GM mass log like", 644, -.52, 2.7 );			//TrackCollection_GMuon mass
    histset[103] = TMmuon.make<TH1D>("TM_mass_log_likecharges", "TM mass log like", 644, -.52, 2.7 );			//MuonCollection_TMuon mass
    
    
    // set axis labels
    
    histset[1]->GetXaxis()->SetTitle("Global Muon Momentum from track collection(in GeV/c)");
    histset[1]->GetYaxis()->SetTitle("Number of Events");
    
    histset[2]->GetXaxis()->SetTitle("Transverse Momentum of global muons from track collection(in GeV/c)");
    histset[2]->GetYaxis()->SetTitle("Number of Events");
    
    histset[3]->GetXaxis()->SetTitle("Eta of global muons from track collection (in radians)");
    histset[3]->GetYaxis()->SetTitle("Number of Events");
    histset[4]->GetXaxis()->SetTitle("Number of Global Muons");
    histset[4]->GetYaxis()->SetTitle("Number of Events");
    
    histset[5]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[5]->GetYaxis()->SetTitle("Number of Events");
    
    histset[6]->GetXaxis()->SetTitle("Number of Tracks");
    histset[6]->GetYaxis()->SetTitle("Number of Events");
    
    histset[29]->GetXaxis()->SetTitle("Momentum (in GeV/c)");
    histset[29]->GetYaxis()->SetTitle("Number of Events");
    
    histset[30]->GetXaxis()->SetTitle("Transverse Momentum (in GeV/c)");
    histset[30]->GetYaxis()->SetTitle("Number of Events");
    
    histset[31]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[31]->GetYaxis()->SetTitle("Number of Events");
    
    histset[33]->GetXaxis()->SetTitle("Number of Muons");
    histset[33]->GetYaxis()->SetTitle("Number of Events");
    
    histset[39]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 with|eta|<1.2(in GeV/c^2)");
    histset[39]->GetYaxis()->SetTitle("Number of Events");
    
    histset[40]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 with |eta|>1.2 and |eta|<1.6 (in GeV/c^2)");
    histset[40]->GetYaxis()->SetTitle("Number of Events");
    
    histset[41]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 with |eta|>1,6 and |eta|<2.4 (in GeV/c^2)");
    histset[41]->GetYaxis()->SetTitle("Number of Events");
    
    histset[32]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[32]->GetYaxis()->SetTitle("Number of Events");
    histset[44]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[44]->GetYaxis()->SetTitle("Number of Events");
    histset[42]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[42]->GetYaxis()->SetTitle("Number of Events");
    histset[43]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[43]->GetYaxis()->SetTitle("Number of Events");
    
    histset[45]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[45]->GetYaxis()->SetTitle("Number of Events");
    histset[46]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[46]->GetYaxis()->SetTitle("Number of Events");
    
    histset[47]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[47]->GetYaxis()->SetTitle("Number of Events");
    
    histset[48]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[48]->GetYaxis()->SetTitle("Number of Events");
    histset[49]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[49]->GetYaxis()->SetTitle("Number of Events");
    
    histset[50]->GetXaxis()->SetTitle("Chi2 values");
    histset[50]->GetYaxis()->SetTitle("Number of Events");
    histset[51]->GetXaxis()->SetTitle("Ndof values");
    histset[51]->GetYaxis()->SetTitle("Number of Events");
    histset[52]->GetXaxis()->SetTitle("NormalizedChi2 values");
    histset[52]->GetYaxis()->SetTitle("Number of Events");
    
    histset[53]->GetXaxis()->SetTitle("Chi2 values");
    histset[53]->GetYaxis()->SetTitle("Number of Events");
    histset[54]->GetXaxis()->SetTitle("Ndof values");
    histset[54]->GetYaxis()->SetTitle("Number of Events");
    histset[55]->GetXaxis()->SetTitle("NormalizedChi2 values");
    histset[55]->GetYaxis()->SetTitle("Number of Events");
    
    histset[56]->GetXaxis()->SetTitle("Chi2 values");
    histset[56]->GetYaxis()->SetTitle("Number of Events");
    histset[57]->GetXaxis()->SetTitle("Ndof values");
    histset[57]->GetYaxis()->SetTitle("Number of Events");
    histset[58]->GetXaxis()->SetTitle("NormalizedChi2 values");
    histset[58]->GetYaxis()->SetTitle("Number of Events");
    
    histset[59]->GetXaxis()->SetTitle("Good Track multiplicity");
    histset[59]->GetYaxis()->SetTitle("Number of Events");
    
    histset[60]->GetXaxis()->SetTitle("Number of valid hits");
    histset[60]->GetYaxis()->SetTitle("Number of Events");
    
    histset[61]->GetXaxis()->SetTitle("Munber of pixel hits");
    histset[61]->GetYaxis()->SetTitle("Number of Events");
    histset[62]->GetXaxis()->SetTitle("Good Track multiplicity");
    histset[62]->GetYaxis()->SetTitle("Number of Events");
    
    histset[63]->GetXaxis()->SetTitle("Number of valid hits");
    histset[63]->GetYaxis()->SetTitle("Number of Events");
    
    histset[64]->GetXaxis()->SetTitle("Munber of pixel hits");
    histset[64]->GetYaxis()->SetTitle("Number of Events");
    
    histset[65]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[65]->GetYaxis()->SetTitle("Number of Events");
    
    histset[66]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[66]->GetYaxis()->SetTitle("Number of Events");
    
    histset[67]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[67]->GetYaxis()->SetTitle("Number of Events");
    
    histset[68]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[68]->GetYaxis()->SetTitle("Number of Events");
    
    histset[69]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[69]->GetYaxis()->SetTitle("Number of Events");
    histset[70]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[70]->GetYaxis()->SetTitle("Number of Events");
    histset[72]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[72]->GetYaxis()->SetTitle("Number of Events");
    histset[71]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[71]->GetYaxis()->SetTitle("Number of Events");
    
    histset[73]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[73]->GetYaxis()->SetTitle("Number of Events");
    
    histset[74]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[74]->GetYaxis()->SetTitle("Number of Events");
    histset[75]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[75]->GetYaxis()->SetTitle("Number of Events");
    
    histset[76]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[76]->GetYaxis()->SetTitle("Number of Events");
    histset[77]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[77]->GetYaxis()->SetTitle("Number of Events");
    histset[78]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[78]->GetYaxis()->SetTitle("Number of Events");
    histset[79]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[79]->GetYaxis()->SetTitle("Number of Events");
    histset[80]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[80]->GetYaxis()->SetTitle("Number of Events");
    
    histset[81]->GetXaxis()->SetTitle("Phi");
    histset[81]->GetYaxis()->SetTitle("Number of Events");
    histset[82]->GetXaxis()->SetTitle("Phi");
    histset[82]->GetYaxis()->SetTitle("Number of Events");
    histset[83]->GetXaxis()->SetTitle("Phi");
    histset[83]->GetYaxis()->SetTitle("Number of Events");
    histset[84]->GetXaxis()->SetTitle("Phi");
    histset[84]->GetYaxis()->SetTitle("Number of Events");
    
    histset[85]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[85]->GetYaxis()->SetTitle("Number of Events");
    
    histset[86]->GetXaxis()->SetTitle("Number of Tracks");
    histset[86]->GetYaxis()->SetTitle("Number of Vertices");
    histset[87]->GetXaxis()->SetTitle("Number of Tracks");
    histset[87]->GetYaxis()->SetTitle("Number of Vertices");
    
    histset[88]->GetXaxis()->SetTitle("difference in x");
    histset[88]->GetYaxis()->SetTitle("Number of Events");
    histset[89]->GetXaxis()->SetTitle("difference in y");
    histset[89]->GetYaxis()->SetTitle("Number of Events");
    histset[90]->GetXaxis()->SetTitle("difference in z");
    histset[90]->GetYaxis()->SetTitle("Number of Events");
    histset[91]->GetXaxis()->SetTitle("Transverse impact paramemter w.r.t. BS");
    histset[91]->GetYaxis()->SetTitle("Number of Events");
    histset[92]->GetXaxis()->SetTitle("Number of valid hits");
    histset[92]->GetYaxis()->SetTitle("Number of Events");
    histset[93]->GetXaxis()->SetTitle("Muons matching with at least two muon stations");
    histset[93]->GetYaxis()->SetTitle("Number of Events");
    
    histset[94]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[94]->GetYaxis()->SetTitle("Number of Events");
    histset[95]->GetXaxis()->SetTitle("Invariant Mass for Nmuon>=2 (in GeV/c^2)");
    histset[95]->GetYaxis()->SetTitle("Number of Events");
    
    histset[96]->GetXaxis()->SetTitle("Momentum (in GeV/c)");
    histset[96]->GetYaxis()->SetTitle("Number of Events");
    histset[97]->GetXaxis()->SetTitle("Transverse Momentum (in GeV/c)");
    histset[97]->GetYaxis()->SetTitle("Number of Events");
    histset[98]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[98]->GetYaxis()->SetTitle("Number of Events");
    histset[99]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[99]->GetYaxis()->SetTitle("Number of Events");
    histset[104]->GetXaxis()->SetTitle("Invariant Mass for Nelectron>=2 (in GeV/c^2)");
    histset[104]->GetYaxis()->SetTitle("Number of Events");
    histset[105]->GetXaxis()->SetTitle("Number of Electrons");
    histset[105]->GetYaxis()->SetTitle("Number of Events");
    
    histset[106]->GetXaxis()->SetTitle("Super Cluster Eta(in radians)");
    histset[106]->GetYaxis()->SetTitle("Number of Events");
    histset[107]->GetXaxis()->SetTitle("Super Cluster Energy");
    histset[107]->GetYaxis()->SetTitle("Number of Events");
    histset[108]->GetXaxis()->SetTitle("Track Isolation");
    histset[108]->GetYaxis()->SetTitle("Number of Events");
    histset[109]->GetXaxis()->SetTitle("Ecal Isolation");
    histset[109]->GetYaxis()->SetTitle("Number of Events");
    histset[110]->GetXaxis()->SetTitle("Hcal Isolation");
    histset[110]->GetYaxis()->SetTitle("Number of Events");
    histset[111]->GetXaxis()->SetTitle("gsfTrack Hit type");
    histset[111]->GetYaxis()->SetTitle("Number of Events");
    histset[112]->GetXaxis()->SetTitle("Dcot");
    histset[112]->GetYaxis()->SetTitle("Number of Events");
    histset[113]->GetXaxis()->SetTitle("Dist");
    histset[113]->GetYaxis()->SetTitle("Number of Events");
    histset[114]->GetXaxis()->SetTitle("sigmaIetaIeta");
    histset[114]->GetYaxis()->SetTitle("Number of Events");
    histset[115]->GetXaxis()->SetTitle("DeltaPhi");
    histset[115]->GetYaxis()->SetTitle("Number of Events");
    histset[116]->GetXaxis()->SetTitle("DeltaEta");
    histset[116]->GetYaxis()->SetTitle("Number of Events");
    histset[117]->GetXaxis()->SetTitle("H/E");
    histset[117]->GetYaxis()->SetTitle("Number of Events");
    histset[118]->GetXaxis()->SetTitle("Electron Et");
    histset[118]->GetYaxis()->SetTitle("Number of Events");
    histset[119]->GetXaxis()->SetTitle("Invariant Mass for Nelectron>=2 (in GeV/c^2)");
    histset[119]->GetYaxis()->SetTitle("Number of Events");
    histset[120]->GetXaxis()->SetTitle("Track Isolation");
    histset[120]->GetYaxis()->SetTitle("Number of Events");
    histset[121]->GetXaxis()->SetTitle("Ecal Isolation");
    histset[121]->GetYaxis()->SetTitle("Number of Events");
    histset[122]->GetXaxis()->SetTitle("Hcal Isolation");
    histset[122]->GetYaxis()->SetTitle("Number of Events");
    
    histset[123]->GetXaxis()->SetTitle("sigmaIetaIeta");
    histset[123]->GetYaxis()->SetTitle("Number of Events");
    histset[124]->GetXaxis()->SetTitle("DeltaPhi");
    histset[124]->GetYaxis()->SetTitle("Number of Events");
    histset[125]->GetXaxis()->SetTitle("DeltaEta");
    histset[125]->GetYaxis()->SetTitle("Number of Events");
    histset[126]->GetXaxis()->SetTitle("H/E");
    histset[126]->GetYaxis()->SetTitle("Number of Events");
    histset[127]->GetXaxis()->SetTitle("Invariant Mass for Nelectron>=2 (in GeV/c^2)");
    histset[127]->GetYaxis()->SetTitle("Number of Events");
    histset[128]->GetXaxis()->SetTitle("Invariant Mass for Nelectron>=2 (in GeV/c^2)");
    histset[128]->GetYaxis()->SetTitle("Number of Events");
    
    histset[129]->GetXaxis()->SetTitle("Transverse Mass for muons+MET (in GeV/c^2)");
    histset[129]->GetYaxis()->SetTitle("Number of Events");
    histset[130]->GetXaxis()->SetTitle("Transverse Mass for muons+MET (in GeV/c^2)");
    histset[130]->GetYaxis()->SetTitle("Number of Events");
    histset[131]->GetXaxis()->SetTitle("Transverse Mass for electrons+MET (in GeV/c^2)");
    histset[131]->GetYaxis()->SetTitle("Number of Events");
    histset[132]->GetXaxis()->SetTitle("Transverse Mass for electrons+MET (in GeV/c^2)");
    histset[132]->GetYaxis()->SetTitle("Number of Events");
    histset[133]->GetXaxis()->SetTitle("MET (in GeV)");
    histset[133]->GetYaxis()->SetTitle("Number of Events");
    histset[134]->GetXaxis()->SetTitle("MET (in GeV)");
    histset[134]->GetYaxis()->SetTitle("Number of Events");
    histset[135]->GetXaxis()->SetTitle("MET (in GeV)");
    histset[135]->GetYaxis()->SetTitle("Number of Events");
    histset[136]->GetXaxis()->SetTitle("MET (in GeV)");
    histset[136]->GetYaxis()->SetTitle("Number of Events");
    histset[137]->GetXaxis()->SetTitle("MET (in GeV)");
    histset[137]->GetYaxis()->SetTitle("Number of Events");
    
    
    
    
    
    histset[100]->GetXaxis()->SetTitle("Invariant Log10(Mass) for Nmuon>=2 (in GeV/c^2)");
    histset[100]->GetYaxis()->SetTitle("Number of Events/GeV");
    histset[101]->GetXaxis()->SetTitle("Invariant Log10(Mass) for Nmuon>=2 (in GeV/c^2)");
    histset[101]->GetYaxis()->SetTitle("Number of Events/GeV");
    histset[102]->GetXaxis()->SetTitle("Invariant Log10(Mass) for Nmuon>=2 (in GeV/c^2)");
    histset[102]->GetYaxis()->SetTitle("Number of Events/GeV");
    histset[103]->GetXaxis()->SetTitle("Invariant Log10(Mass) for Nmuon>=2 (in GeV/c^2)");
    histset[103]->GetYaxis()->SetTitle("Number of Events/GeV");



//                event property histograms                //

// histograms to check and simulate JSON
  histset[200]=fs->make<TH1D>("Run number", "Run number", 3100, 146400, 149500);
  histset[201]=fs->make<TH1D>("Run number, no JSON", "Run number, no JSON, should be empty!", 3100, 146400, 149500);
  histset[202]=fs->make<TH1D>("Event number", "Event number", 2000, 0, 2000000000);
  histset[203]=fs->make<TH1D>("Lumi section", "Lumi section", 300, 0, 3000);
  histset[204]=fs->make<TH1D>("Run number, JSON", "Run number, JSON, should be filled", 3100, 146400, 149500);

  histset[240]=fs->make<TH1D>("Track_Multiplicity", "Track_Multiplicity", 400, 0, 400);

} //Fold for I's Histograms
    
                //// ---------- Check InvMass Function ---------- ////
    
                    histset[207]  =   fs->make<TH1D>("h_Jspimass" , "" ,90 ,2.6 , 3.5 );
    
                //// ---------- J/Psi Acceptance ---------- ////
    
                    hxhy[1]       =   acceptance.make<TH2D>("h_Paircount", "", 100,0, 2.4, 400, 0.001, 0.5);
		    hxhy[100]     =   acceptance.make<TH2D>("Ntracks_dR", "", 200, 0., 200, 100, 0, 10);	
                    histset[205]  =   acceptance.make<TH1D>("h_JpsiPT", "", 100, 0, 30);
                    hxhy[2]       =   acceptance.make<TH2D>("h_Paircount2", "", 24, 0, 2.4, 42, binsy );
    
                //// ------------- D* Anaylsis ------------ ////
    
                    histset[206]  =   dmesonsCommon.make<TH1D>("h_D0mass", "", 60, 1.6, 2.2); //D0 mass histogram
		    
                    histset[208]  =   dmesonsCommon.make<TH1D>("h_deltaM", "", 64, 0.138, 0.17); //Mass difference histogram for 'right charge' paring
//                     histset[209]  =   dmesonsCommon.make<TH1D>("h_deltaMwrongcharge", "", 64, 0.138, 0.17); //Mass difference histogram for 'wrong charge' pairing
    
		    /// cuts from Bridget
                    histset[217]  =   dmesonsBridget.make<TH1D>("h_D0masscut", "", 60, 1.6, 2.2); //D0 mass histogram with a cut on delta M
                    histset[223]  =   dmesonsBridget.make<TH1D>("h_D0masscutwrongsign", "", 60, 1.6, 2.2);
		    
		    /// cuts from Bridget
                    histset[230]  =   dmesonsBridget.make<TH1D>("h_D0masscut_rightDLcut", "", 60, 1.6, 2.2); //D0 mass histogram with a cut on delta M
                    histset[231]  =   dmesonsBridget.make<TH1D>("h_D0masscutwrongsign_rightDLcut", "", 60, 1.6, 2.2);
		    
		    /// cuts from Bridget
                    histset[234]  =   dmesonsBridget.make<TH1D>("h_D0masscut_leftDLcut", "", 60, 1.6, 2.2); //D0 mass histogram with a cut on delta M
                    histset[235]  =   dmesonsBridget.make<TH1D>("h_D0masscutwrongsign_leftDLcut", "", 60, 1.6, 2.2);
		    
//     		    /// Atlas cuts		
//                     histset[212]  =   dmesonsAtlas.make<TH1D>("h_deltaMassD0Dstar", "", 64, 0.138, 0.17); 	//Mass difference histogram for 'right charge' paring (Atlas Cuts)
//                     histset[224]  =   dmesonsAtlas.make<TH1D>("h_D0masscut", "", 60, 1.6, 2.2); 		//D0 mass histogram with a cut on delta M
//                     histset[232]  =   dmesonsAtlas.make<TH1D>("h_D0masscut_rightDLcut", "", 60, 1.6, 2.2); 	//D0 mass histogram with a cut on delta M
//                     histset[236]  =   dmesonsAtlas.make<TH1D>("h_D0masscut_leftDLcut", "", 60, 1.6, 2.2); 	//D0 mass histogram with a cut on delta M

    
// 		    /// Atlas cuts
//                     histset[1212]  =   dmesonsAtlasWS.make<TH1D>("h_deltaMassD0Dstar", "", 64, 0.138, 0.17); 	//Mass difference histogram for 'wrong charge' pairing (Atlas Cuts)
//                     histset[1224]  =   dmesonsAtlasWS.make<TH1D>("h_D0masscut", "", 60, 1.6, 2.2);
//                     histset[1232]  =   dmesonsAtlasWS.make<TH1D>("h_D0masscut_rightDLcut", "", 60, 1.6, 2.2);
//                     histset[1236]  =   dmesonsAtlasWS.make<TH1D>("h_D0masscut_leftDLcut", "", 60, 1.6, 2.2);



                    histset[210]  =   dmesonsCommon.make<TH1D>("h_z","",100,0,0.5);
                    histset[211]  =   dmesonsCommon.make<TH1D>("h_n","",100, 0 ,200);
                    histset[214]  =   dmesonsCommon.make<TH1D>("h_d0pt","",100, 0 ,15);
                    histset[215]  =   dmesonsCommon.make<TH1D>("h_dstarpt","",100, 0 ,15);
                    histset[216]  =   dmesonsCommon.make<TH1D>("h_PS3pt","",100, 0 ,2);
                    histset[218]  =   dmesonsCommon.make<TH1D>("h_K1pt","",100, 0 ,10);
                    histset[219]  =   dmesonsCommon.make<TH1D>("h_P2pt","",100, 0 ,10);
    
    
                    histset[220]  =   dmesonsCommon.make<TH1D>("h_PS3eta","",50, -3 ,3);
                    histset[221]  =   dmesonsCommon.make<TH1D>("h_P2eta","",50, -3 ,3);
                    histset[222]  =   dmesonsCommon.make<TH1D>("h_K1eta","",50, -3 ,3);
    
                    hxhy[3]       =   dmesonsAtlas.make<TH2D>("h_D0deltaM","",60,1.6,2.2,64,0.138,0.17);
                    hxhy[4]       =   dmesonsAtlasWS.make<TH2D>("h_D0deltaMWrongCharge","",60,1.6,2.2,64,0.138,0.17);
                //// ------------- Y cut implementation ------------ ////
    /// by Nazar , 17.11.15
                    histset[250]  =  upsilon.make<TH1D>("h_Upsilon","",80, 8, 12);
                    histset[251]  =  upsilon.make<TH1D>("h_Upsilon_eta","",80, 8, 12);
                    histset[252]  =  upsilon.make<TH1D>("h_Upsiloncorr","",80, 8, 12);
                    histset[253]  =  upsilon.make<TH1D>("h_Upsilon_etacorr","",80, 8, 12);
                 //// ------------- JETS implementation ------------ ////
		    
		    
		    
		    /// D star plots		
                    histset[212]  =   dmesonsAtlas.make<TH1D>("h_deltaMassD0Dstar", "", 64, 0.138, 0.17); 	//Mass difference histogram for 'right charge' paring (Atlas Cuts)	    
		    histset[950]  =  dmesonsAtlas.make<TH1D>("h_deltaMassD0Dstar_leftDLcut", "", 64, 0.138, 0.17);
		    histset[951]  =  dmesonsAtlas.make<TH1D>("h_deltaMassD0Dstar_rightDLcut", "", 64, 0.138, 0.17);
		    
		    /// D star plots
                    histset[224]  =   dmesonsAtlas.make<TH1D>("h_D0masscut", "", 60, 1.6, 2.2); 		//D0 mass histogram with a cut on delta M
                    histset[232]  =   dmesonsAtlas.make<TH1D>("h_D0masscut_rightDLcut", "", 60, 1.6, 2.2); 	//D0 mass histogram with a cut on delta M
                    histset[236]  =   dmesonsAtlas.make<TH1D>("h_D0masscut_leftDLcut", "", 60, 1.6, 2.2); 	//D0 mass histogram with a cut on delta M
		    
		    /// DL all mass spectrum: 
		    histset[952]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_allMassD0","",400, -3, 3);
		    histset[953]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_allMassD0_gamma","",400, -3, 3);		
		    histset[954]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_allMassD0_left_clone","",400, -3, 3);
		    histset[955]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_allMassD0_leftDLcut","",400, -3, 3);		
		    histset[956]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_allMassD0_rightDLcut","",400, -3, 3);	
		    
		    
		    /// D0 DL left side of D0 mass spectrum: MD0<1.8 && MD0 > 1.75
		    histset[510]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_leftSide","",400, -3, 3);			
		    histset[511]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_leftSide_gamma","",400, -3, 3);
		    histset[512]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_leftSide_left_clone","",400, -3, 3);
		    histset[513]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_leftSide_leftDLcut","",400, -3, 3);			
		    histset[514]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_leftSide_rightDLcut","",400, -3, 3);			

		    /// D0 DL right side of D0 mass spectrum: MD0>1.93 && MD0 < 1.98
		    histset[520]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_rightSide","",400, -3, 3);			
		    histset[521]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_rightSide_gamma","",400, -3, 3);
		    histset[522]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_rightSide_lelf_clone","",400, -3, 3);
		    histset[523]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_rightSide_leftDLcut","",400, -3, 3);			
		    histset[524]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_rightSide_rightDLcut","",400, -3, 3);
		
		    /// D0 peak region: |MD0-MD0Actual| < 0.025
		    histset[580]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection","",400, -3, 3);		
		    histset[581]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_gamma","",400, -3, 3);		
		    histset[582]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_left_clone","",400, -3, 3);
		    histset[583]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_leftDLcut","",400, -3, 3);		
		    histset[584]  =  dmesonsAtlas.make<TH1D>("D0_BS_DL_projection_rightDLcut","",400, -3, 3);	

		    /// D0 fitted Vertex parameters:  (fitted with CMS fitter)
                    histset[500]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_Ntracks","",20, 0, 5);
                    histset[501]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_PosX","",200, -1, 1);
                    histset[502]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_PosY","",200, -1, 1);
                    histset[503]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_PosZ","",200, -50, 50);
                    histset[504]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_Chi2_Ndof","",400, 0, 100);
                    histset[525]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_Chi2_Ndof_leftSide","",400, 0, 100);
                    histset[526]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_Chi2_Ndof_rightSide","",400, 0, 100);	
                    histset[527]  =  dmesonsAtlas.make<TH1D>("Vertex_D0_Chi2_Ndof_signal","",400, 0, 100);
		    
		    /// add PT distributions for D0: 
		    histset[700]  =  dmesonsAtlas.make<TH1D>("D0_allSpectrum_PT", "", 200, 0, 40);
		    histset[701]  =  dmesonsAtlas.make<TH1D>("D0_allSpectrum_PT_leftDLcut", "", 200, 0, 40);
		    histset[702]  =  dmesonsAtlas.make<TH1D>("D0_allSpectrum_PT_rightDLcut", "", 200, 0, 40);

		    histset[703]  =  dmesonsAtlas.make<TH1D>("D0_signal_PT", "", 200, 0, 40);
		    histset[704]  =  dmesonsAtlas.make<TH1D>("D0_signal_PT_leftDLcut", "", 200, 0, 40);
		    histset[705]  =  dmesonsAtlas.make<TH1D>("D0_signal_PT_rightDLcut", "", 200, 0, 40);

		    histset[706]  =  dmesonsAtlas.make<TH1D>("D0_PT_leftSide", "", 200, 0, 40);  
		    histset[707]  =  dmesonsAtlas.make<TH1D>("D0_PT_rightSide", "", 200, 0, 40);

		    histset[708]  =  dmesonsAtlas.make<TH1D>("D0_PT_leftSide_leftDLcut", "", 200, 0, 40); 
		    histset[709]  =  dmesonsAtlas.make<TH1D>("D0_PT_rightSide_leftDLcut", "", 200, 0, 40);
		    histset[710]  =  dmesonsAtlas.make<TH1D>("D0_PT_leftSide_rightDLcut", "", 200, 0, 40);
		    histset[711]  =  dmesonsAtlas.make<TH1D>("D0_PT_rightSide_rightDLcut", "", 200, 0, 40);

		    /// general parameters
		    histset[730]  =  dmesonsAtlas.make<TH1D>("Vertex_Multiplicity_D0mass_allSpectrum", "", 10, 0, 10);
		    histset[731]  =  dmesonsAtlas.make<TH1D>("Vertex_Multiplicity_D0mass_peak", "", 10, 0, 10);
		    histset[732]  =  dmesonsAtlas.make<TH1D>("Ncand_D0mass_allSpectrum", "", 10, 0, 10);


/*
/// Histograms with cuts from Bridget: 

                    histset[800]  =  dmesonsBridget.make<TH1D>("Vertex_D0_Ntracks","",20, 0, 5);
                    histset[801]  =  dmesonsBridget.make<TH1D>("Vertex_D0_PosX","",200, -1, 1);
                    histset[802]  =  dmesonsBridget.make<TH1D>("Vertex_D0_PosY","",200, -1, 1);
                    histset[803]  =  dmesonsBridget.make<TH1D>("Vertex_D0_PosZ","",200, -50, 50);
                    histset[804]  =  dmesonsBridget.make<TH1D>("Vertex_D0_Chi2_Ndof","",400, 0, 100);

		    histset[805]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_leftSide","",600, -2, 4);			
		    histset[806]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_leftSide_gamma","",600, -2, 4);
		    histset[807]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_leftSide_left_clone","",600, -2, 4);
		    
		    histset[808]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_leftSide_leftDLcut","",600, -2, 4);			
		    histset[809]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_leftSide_rightDLcut","",600, -2, 4);			

		    histset[810]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_rightSide","",600, -2, 4);			
		    histset[811]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_rightSide_gamma","",600, -2, 4);
		    histset[812]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_rightSide_lelf_clone","",600, -2, 4);
		    
		    histset[813]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_rightSide_leftDLcut","",600, -2, 4);			
		    histset[814]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_rightSide_rightDLcut","",600, -2, 4);	

                    histset[815]  =  dmesonsBridget.make<TH1D>("Vertex_D0_Chi2_Ndof_leftSide","",400, 0, 100);
                    histset[816]  =  dmesonsBridget.make<TH1D>("Vertex_D0_Chi2_Ndof_rightSide","",400, 0, 100);		
                    histset[837]  =  dmesonsBridget.make<TH1D>("Vertex_D0_Chi2_Ndof_signal","",400, 0, 100);

		    histset[817]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection","",600, -2, 4);		
		    histset[818]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_gamma","",600, -2, 4);		
		    histset[819]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_left_clone","",600, -2, 4);
		    
		    histset[820]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_leftDLcut","",600, -2, 4);		
		    histset[821]  =  dmesonsBridget.make<TH1D>("D0_BS_DL_projection_rightDLcut","",600, -2, 4);		

		    /// add PT distributions for D0: 
		    histset[822]  =  dmesonsBridget.make<TH1D>("D0_allSpectrum_PT", "", 200, 0, 40);
		    histset[823]  =  dmesonsBridget.make<TH1D>("D0_allSpectrum_PT_leftDLcut", "", 200, 0, 40);
		    histset[824]  =  dmesonsBridget.make<TH1D>("D0_allSpectrum_PT_rightDLcut", "", 200, 0, 40);
		    histset[825]  =  dmesonsBridget.make<TH1D>("D0_signal_PT", "", 200, 0, 40);
		    histset[826]  =  dmesonsBridget.make<TH1D>("D0_signal_PT_leftDLcut", "", 200, 0, 40);
		    histset[827]  =  dmesonsBridget.make<TH1D>("D0_signal_PT_rightDLcut", "", 200, 0, 40);

		    histset[828]  =  dmesonsBridget.make<TH1D>("D0_PT_leftSide", "", 200, 0, 40);  
		    histset[829]  =  dmesonsBridget.make<TH1D>("D0_PT_rightSide", "", 200, 0, 40);
		    histset[830]  =  dmesonsBridget.make<TH1D>("D0_PT_leftSide_leftDLcut", "", 200, 0, 40); 
		    histset[831]  =  dmesonsBridget.make<TH1D>("D0_PT_rightSide_leftDLcut", "", 200, 0, 40);
		    histset[832]  =  dmesonsBridget.make<TH1D>("D0_PT_leftSide_rightDLcut", "", 200, 0, 40);
		    histset[833]  =  dmesonsBridget.make<TH1D>("D0_PT_rightSide_rightDLcut", "", 200, 0, 40);

		    histset[834]  =  dmesonsBridget.make<TH1D>("Vertex_Multiplicity_D0mass_allSpectrum", "", 10, 0, 10);
		    histset[835]  =  dmesonsBridget.make<TH1D>("Vertex_Multiplicity_D0mass_peak", "", 10, 0, 10);

		    histset[836]  =  dmesonsBridget.make<TH1D>("Ncand_D0mass_allSpectrum", "", 10, 0, 10);
		    // 837 booked	

		    histset[900]  =  RevertexDL.make<TH1D>("RevertexDL", "", 1000, -5, 5);
 		    histset[901]  =  RevertexDL.make<TH1D>("RevertexDLless0", "", 250, -5, 0);
		    histset[902]  =  RevertexDL.make<TH1D>("DLSign", "", 800, -100, 100);	
		    histset[903]  =  RevertexDL.make<TH1D>("MassVtxCluster", "", 50, 0, 10);	
		    histset[904]  =  RevertexDL.make<TH1D>("DLSignChi2_cut", "", 800, -100, 100);
		    histset[905]  =  RevertexDL.make<TH1D>("DLSignMass_cut", "", 800, -100, 100);
		    histset[906]  =  RevertexDL.make<TH1D>("DLSignChi2andMass_cut", "", 800, -100, 100);
		    histset[910]  =  RevertexDL.make<TH1D>("RevertexDLChi2_cut", "", 1000, -5, 5);
		    histset[911]  =  RevertexDL.make<TH1D>("RevertexDLMass_cut", "", 1000, -5, 5);
		    histset[912]  =  RevertexDL.make<TH1D>("RevertexDLChi2andMass_cut", "", 1000, -5, 5);
		    
    /// end Nazar , 17.11.15
    */
		    histset[900]  =  RevertexDL.make<TH1D>("Nclusters_per_vtx", "", 100, 0, 15);
		    histset[901]  =  RevertexDL.make<TH1D>("Ntracks_per_cluster", "", 100, 0, 100);
		    histset[902]  =  RevertexDL.make<TH1D>("DL_mm", "", 400, -5, 5);
		    histset[903]  =  RevertexDL.make<TH1D>("DLsign_mm", "", 400, -40, 60);
		    histset[904]  =  RevertexDL.make<TH1D>("Chi2_ndof", "", 400, 0, 40);
		    histset[905]  =  RevertexDL.make<TH1D>("BS_DL_mm", "", 400, -5, 5);
		    histset[906]  =  RevertexDL.make<TH1D>("BS_DLsign_mm", "", 400, -40, 60);
		    histset[907]  =  RevertexDL.make<TH1D>("BS_Chi2_ndof", "", 400, 0, 40);


		    histset[930]  =  RevertexDL.make<TH1D>("ZEUS_Nclusters_per_vtx", "", 100, 0, 15);
		    histset[932]  =  RevertexDL.make<TH1D>("ZEUS_DL_mm", "", 400, -5, 5);
		    histset[933]  =  RevertexDL.make<TH1D>("ZEUS_DLsign_mm", "", 400, -40, 60);
		    histset[934]  =  RevertexDL.make<TH1D>("ZEUS_Chi2_ndof", "", 400, 0, 40);
		    histset[935]  =  RevertexDL.make<TH1D>("ZEUS_BS_DL_mm", "", 400, -5, 5);
		    histset[936]  =  RevertexDL.make<TH1D>("ZEUS_BS_DLsign_mm", "", 400, -40, 60);
		    histset[937]  =  RevertexDL.make<TH1D>("ZEUS_BS_Chi2_ndof", "", 400, 0, 40);
		    histset[938]  =  RevertexDL.make<TH1D>("ZEUS_VtxMass", "", 200, 0, 40);	


		    hxhy[300]     =   RevertexDL.make<TH2D>("ZEUS_DL_mm_vs_Mass","",200, 0, 40, 400, -5, 5 );
		    hxhy[301]     =   RevertexDL.make<TH2D>("ZEUS_DLsign_mm_vs_Mass","",200, 0, 40, 400, -40, 60 );
		    hxhy[302]     =   RevertexDL.make<TH2D>("ZEUS_BS_DL_mm_vs_Mass","",200, 0, 40, 400, -5, 5 );
		    hxhy[303]     =   RevertexDL.make<TH2D>("ZEUS_BS_DLsign_mm_vs_Mass","",200, 0, 40, 400, -40, 60 );
		    hxhy[304]     =   RevertexDL.make<TH2D>("CMS_DL_mm_vs_Mass","",200, 0, 40, 400, -5, 5 );
		    hxhy[305]     =   RevertexDL.make<TH2D>("CMS_DLsign_mm_vs_Mass","",200, 0, 40, 400, -40, 60 );
		    hxhy[306]     =   RevertexDL.make<TH2D>("CMS_BS_DL_mm_vs_Mass","",200, 0, 40, 400, -5, 5 );
		    hxhy[307]     =   RevertexDL.make<TH2D>("CMS_BS_DLsign_mm_vs_Mass","",200, 0, 40, 400, -40, 60 );


                histset[261]  = pfjetsF.make<TH1D>("h_jetPT" , "" , 200 , 0 , 20 );
                histset[262]  = pfjetsF.make<TH1D>("h_JetETA" , "" , 100 , -3 , 3 );
  
/*  
    histset[302]  = pfjetsF.make<TH1D>("h_TrackerJetPT" , "" , 200 , 0 , 20 );
    
    histset[303]  = pfjetsF.make<TH1D>("TrackJets_Eta" , "TrackJets_Eta" , 100 , -7.0 , 7.0 );
    histset[303]->GetXaxis()->SetTitle("Eta (in radians)");
    histset[303]->GetYaxis()->SetTitle("Number of PFJets");
    
    histset[304]  = pfjetsF.make<TH1D>("TrackJet.Ntracks" , "TrackJet.Ntracks" , 35 , 0 , 35.0 );
    histset[304]->GetXaxis()->SetTitle("Ntracks");
    histset[304]->GetYaxis()->SetTitle("Number of TrackJets");
    
    histset[305]  = pfjetsF.make<TH1D>("TrackJet.fromHardVertex" , "TrackJet.fromHardVertex" , 20 , -5 , 5.0 );
    histset[305]->GetXaxis()->SetTitle("FromHardVertex");
    histset[305]->GetYaxis()->SetTitle("Number of TrackJets");
    
    histset[306]  = pfjetsF.make<TH1D>("TrackJet.primaryVertex.tracksSize" , "TrackJet.primaryVertex.tracksSize" , 100 , 0 ,200.0 );
    histset[306]->GetXaxis()->SetTitle("N tracks in the assosiated Primary Vertex");
    histset[306]->GetYaxis()->SetTitle("Number of TrackJets");
  */  

/// JPsi

  histset[308]  = jpsi.make<TH1D>("Ntracks_before_check" , "Ntracks_before_check" , 10 , 0 , 10.0 );
    histset[308]->GetXaxis()->SetTitle("N tracks");
    histset[308]->GetYaxis()->SetTitle("Events");

  histset[309]  = jpsi.make<TH1D>("Ntracks_after_check" , "Ntracks_after_check" , 10 , 0 , 10.0 );
    histset[309]->GetXaxis()->SetTitle("N tracks");
    histset[309]->GetYaxis()->SetTitle("Events");

  histset[307]  = jpsi.make<TH1D>("Ntracks_afterValidVtx_check" , "Ntracks_afterValidVtx_check" , 10 , 0 , 10.0 );
    histset[307]->GetXaxis()->SetTitle("N tracks");
    histset[307]->GetYaxis()->SetTitle("Events");

//   histset[310]  = jpsi.make<TH1D>("MyVertex.OriginalTracks" , "MyVertex.OriginalTracks" , 10 , 0 , 10.0 );
//     histset[310]->GetXaxis()->SetTitle("N tracks in the vertex");
//     histset[310]->GetYaxis()->SetTitle("N vertices");

  histset[311]  = jpsi.make<TH1D>("Chi2Normalised" , "Chi2Normalised" , 150 , 0 , 15.0 );
    histset[311]->GetXaxis()->SetTitle("Chi2/ndof");
    histset[311]->GetYaxis()->SetTitle("N vertices");

  histset[312]  = jpsi.make<TH1D>("DL_xy_JPsi" , "DL_xy_JPsi" , 200 , -10 , 10.0 );
    histset[312]->GetXaxis()->SetTitle("DL, mm");
    histset[312]->GetYaxis()->SetTitle("N vertices");

//   histset[313]  = jpsi.make<TH1D>("cos_JPsi_DL" , "cos(JPSI/dL)" , 100 , -1.1 , 1.1 );
//     histset[313]->GetXaxis()->SetTitle("cos(JPSI/DLvect), rad");
//     histset[313]->GetYaxis()->SetTitle("N");

  histset[314]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma" , "DL_xy_JPsi_with_gamma" , 200 , -10 , 10.0 );
    histset[314]->GetXaxis()->SetTitle("DL*Mass(J/Psi)/Pt(J/Psi), mm");
    histset[314]->GetYaxis()->SetTitle("N vertices");

  histset[315]  = jpsi.make<TH1D>("DL_xy_JPsi_cov" , "DL_xy_JPsi_cov" , 150 , -10 , 10.0 );
    histset[315]->GetXaxis()->SetTitle("DL_cov calculations, mm");
    histset[315]->GetYaxis()->SetTitle("N vertices");

  histset[316]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma_cov" , "DL_xy_JPsi_with_gamma_cov" , 300 , -15 , 15.0 );
    histset[316]->GetXaxis()->SetTitle("DL_cov*invMass(J/Psi)/Pt(J/Psi), mm");
    histset[316]->GetYaxis()->SetTitle("N vertices");

  histset[317]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma_bin1" , "DL_xy_JPsi_with_gamma_bin1" , 200 , -10 , 10.0 );
    histset[317]->GetXaxis()->SetTitle("DL*Mass(J/Psi)/Pt(J/Psi), mm");
    histset[317]->GetYaxis()->SetTitle("N vertices");

  histset[318]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma_bin2" , "DL_xy_JPsi_with_gamma_bin2" , 200 , -10 , 10.0 );
    histset[318]->GetXaxis()->SetTitle("DL*Mass(J/Psi)/Pt(J/Psi), mm");
    histset[318]->GetYaxis()->SetTitle("N vertices");

  histset[319]  = jpsi.make<TH1D>("DL_xy_JPsi_bin1" , "DL_xy_JPsi_bin1" , 200 , -10 , 10.0 );
    histset[319]->GetXaxis()->SetTitle("DL, mm");
    histset[319]->GetYaxis()->SetTitle("N vertices");

  histset[320]  = jpsi.make<TH1D>("DL_xy_JPsi_bin2" , "DL_xy_JPsi_bin2" , 200 , -10 , 10.0 );
    histset[320]->GetXaxis()->SetTitle("DL, mm");
    histset[320]->GetYaxis()->SetTitle("N vertices");

  histset[321]  = jpsi.make<TH1D>("DL_xy_JPsi_cov_bin1" , "DL_xy_JPsi_cov_bin1" , 200 , -10 , 10.0 );
    histset[321]->GetXaxis()->SetTitle("DL_cov calculations, mm");
    histset[321]->GetYaxis()->SetTitle("N vertices");

  histset[322]  = jpsi.make<TH1D>("DL_xy_JPsi_cov_bin2" , "DL_xy_JPsi_cov_bin2" , 200 , -10 , 10.0 );
    histset[322]->GetXaxis()->SetTitle("DL_cov calculations, mm");
    histset[322]->GetYaxis()->SetTitle("N vertices");

/// JPsi invariant mass in range (2.6;3.5) + |eta| bin1 : [1.2,1.6], bin2 : [1.6,2.4]
  
  double xbin1[37]={-1.,-0.7,-0.5,-0.45,-0.4,-0.35,-0.3,-0.25,-0.2,-0.17,-0.14,-0.1,-0.07,-0.04,-0.01,0.03,0.07,0.1,0.13,0.17,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.6,0.7,0.8,0.9,1.,1.34,1.68,2., 2.5, 3.};
  //double xbin1[3] = {-1.,-0.7,-0.5,-0.45};	 
  histset[323]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma_cov_bin1" , "DL_xy_JPsi_with_gamma_cov_bin1" , /*200 , -10 , 10.0*/ 36, xbin1 );
    histset[323]->GetXaxis()->SetTitle("DL_cov*invMass(J/Psi)/Pt(J/Psi), mm");
    histset[323]->GetYaxis()->SetTitle("N vertices");

  histset[324]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma_cov_bin2" , "DL_xy_JPsi_with_gamma_cov_bin2" , /*200 , -10 , 10.0*/ 36, xbin1 );
    histset[324]->GetXaxis()->SetTitle("DL_cov*invMass(J/Psi)/Pt(J/Psi), mm");
    histset[324]->GetYaxis()->SetTitle("N vertices");

  histset[325]  = jpsi.make<TH1D>("JPsi_Pt" , "JPsi_Pt" , 120 , 0 , 40.0 );
    histset[325]->GetXaxis()->SetTitle("JPsi_Pt, GeV/c");
    histset[325]->GetYaxis()->SetTitle("Nvertices");

  histset[326]  = jpsi.make<TH1D>("JPsi_Eta" , "JPsi_Eta" , 80 , -4. , 4.0 );
    histset[326]->GetXaxis()->SetTitle("JPsi_Eta, rad");
    histset[326]->GetYaxis()->SetTitle("Nvertices");

  histset[327]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5" , "JPsi_invmass cut : (2.6,3.5) GeV/c^2" , 200 , 2.6 , 3.5 );
    histset[327]->GetXaxis()->SetTitle("JPsi_invmass with cut : (2.6,3.5) GeV/c^2, GeV");
    histset[327]->GetYaxis()->SetTitle("Number of JPsi");

  histset[328]  = jpsi.make<TH1D>("JPsi_invmass" , "JPsi_invmass" , 200 , 0 , 12.0 );
    histset[328]->GetXaxis()->SetTitle("JPsi_invmass, GeV");
    histset[328]->GetYaxis()->SetTitle("Number of JPsi");

  histset[329]  = jpsi.make<TH1D>("DL_xy_JPsi_range" , "DL_xy_JPsi_range" , 400 , -10 , 10.0 );
    histset[329]->GetXaxis()->SetTitle("DL, mm");
    histset[329]->GetYaxis()->SetTitle("N vertices");

  histset[330]  = jpsi.make<TH1D>("DL_xy_JPsi_cov_range" , "DL_xy_JPsi_cov_range" , 400 , -10 , 10.0 );
    histset[330]->GetXaxis()->SetTitle("DL_cov calculations, mm");
    histset[330]->GetYaxis()->SetTitle("N vertices");

  histset[331]  = jpsi.make<TH1D>("DL_xy_JPsi_with_gamma_range" , "DL_xy_JPsi_with_gamma_cov_range" , 400 , -10 , 10.0 );
    histset[331]->GetXaxis()->SetTitle("DL_cov*invMass(J/Psi)/Pt(J/Psi), mm");
    histset[331]->GetYaxis()->SetTitle("N vertices");

  histset[332]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5_forTail" , "JPsi_invmass cut : (2.6,3.5) GeV/c^2 & DL > 0.2" , 200 , 2.6 , 3.5 );
    histset[332]->GetXaxis()->SetTitle("JPsi_invmass with cut : (2.6,3.5) GeV/c^2, GeV");
    histset[332]->GetYaxis()->SetTitle("Number of JPsi");



  histset[333]  = jpsi.make<TH1D>("JPsi_DLxy_Sign_before_cuts" , "JPsi_DLxy_sign_before_cuts" , 400 , -40 , 60.0 );
    histset[333]->GetXaxis()->SetTitle("DL significance");
    histset[333]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[334]  = jpsi.make<TH1D>("JPsi_DLxy_Sign_JPsi_M_cut" , "JPsi_DLxy_sign_JPsi_M_cut" , 400 , -40 , 60.0);
    histset[334]->GetXaxis()->SetTitle("DL significance");
    histset[334]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[335]  = jpsi.make<TH1D>("JPsi_DLxy_Sign_JPsi_M_cut_bin1" , "JPsi_DLxy_sign_JPsi_M_cut_bin1" , 400 , -50 , 50.0);
    histset[335]->GetXaxis()->SetTitle("DL significance");
    histset[335]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[336]  = jpsi.make<TH1D>("JPsi_DLxy_Sign_JPsi_M_cut_bin2" , "JPsi_DLxy_sign_JPsi_M_cut_bin2" , 400 , -50 , 50.0 );
    histset[336]->GetXaxis()->SetTitle("DL significance");
    histset[336]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[337]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5_bin1" , "JPsi_invmass cut : (2.6,3.5) GeV/c^2" , 200 , 2.6 , 3.5 );
    histset[337]->GetXaxis()->SetTitle("JPsi_invmass with cut : (2.6,3.5) GeV/c^2, GeV");
    histset[337]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[338]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5_bin2" , "JPsi_invmass cut : (2.6,3.5) GeV/c^2" , 200 , 2.6 , 3.5 );
    histset[338]->GetXaxis()->SetTitle("JPsi_invmass with cut : (2.6,3.5) GeV/c^2, GeV");
    histset[338]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[339]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5_etaBin1" , "JPsi_invmass cut, Eta bin 1" , 200 , 2.6 , 3.5 );
    histset[339]->GetXaxis()->SetTitle("JPsi_invmass, GeV");
    histset[339]->GetYaxis()->SetTitle("Number of JPsi");

  histset[340]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5_etaBin2" , "JPsi_invmass cut, Eta bin 2" , 200 , 2.6 , 3.5 );
    histset[340]->GetXaxis()->SetTitle("JPsi_invmass, GeV");
    histset[340]->GetYaxis()->SetTitle("Number of JPsi");

  histset[341]  = jpsi.make<TH1D>("JPsi_invmass2.6_3.5_etaBin3" , "JPsi_invmass cut, Eta bin 3" , 200 , 2.6 , 3.5 );
    histset[341]->GetXaxis()->SetTitle("JPsi_invmass, GeV");
    histset[341]->GetYaxis()->SetTitle("Number of JPsi");

///
 histset[342]  = jpsi.make<TH1D>("BS_DL_xy_JPsi" , "DL_xy_JPsi" , 200 , -10 , 10.0 );
    histset[342]->GetXaxis()->SetTitle("DL, mm");
    histset[342]->GetYaxis()->SetTitle("N vertices");
    
 histset[343]  = jpsi.make<TH1D>("BS_DL_xy_JPsi_with_gamma" , "DL_xy_JPsi_with_gamma" , 200 , -10 , 10.0 );
    histset[343]->GetXaxis()->SetTitle("DL*Mass(J/Psi)/Pt(J/Psi), mm");
    histset[343]->GetYaxis()->SetTitle("N vertices");
    
 histset[344]  = jpsi.make<TH1D>("BS_DL_xy_JPsi_with_gamma_cov_bin1" , "DL_xy_JPsi_with_gamma_cov_bin1" , /*200 , -10 , 10.0*/ 36, xbin1 );
    histset[344]->GetXaxis()->SetTitle("DL_cov*invMass(J/Psi)/Pt(J/Psi), mm");
    histset[344]->GetYaxis()->SetTitle("N vertices");

  histset[345]  = jpsi.make<TH1D>("BS_DL_xy_JPsi_with_gamma_cov_bin2" , "DL_xy_JPsi_with_gamma_cov_bin2" , /*200 , -10 , 10.0*/ 36, xbin1 );
    histset[345]->GetXaxis()->SetTitle("DL_cov*invMass(J/Psi)/Pt(J/Psi), mm");
    histset[345]->GetYaxis()->SetTitle("N vertices");

  histset[346]  = jpsi.make<TH1D>("BS_JPsi_DLxy_Sign_JPsi_M_cut" , "JPsi_DLxy_sign_JPsi_M_cut" , 400 , -40 , 60.0);
    histset[346]->GetXaxis()->SetTitle("DL significance");
    histset[346]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[347]  = jpsi.make<TH1D>("BS_JPsi_DLxy_Sign_JPsi_M_cut_bin1" , "JPsi_DLxy_sign_JPsi_M_cut_bin1" , 400 , -50 , 50.0);
    histset[347]->GetXaxis()->SetTitle("DL significance");
    histset[347]->GetYaxis()->SetTitle("Number of JPsi cand.");

  histset[348]  = jpsi.make<TH1D>("BS_JPsi_DLxy_Sign_JPsi_M_cut_bin2" , "JPsi_DLxy_sign_JPsi_M_cut_bin2" , 400 , -50 , 50.0 );
    histset[348]->GetXaxis()->SetTitle("DL significance");
    histset[348]->GetYaxis()->SetTitle("Number of JPsi cand.");
    
    
  histset[349]  = jpsi.make<TH1D>("BS_JPsi_DLxy_Sign_before_cuts" , "JPsi_DLxy_sign_before_cuts" , 400 , -40 , 60.0 );
    histset[349]->GetXaxis()->SetTitle("DL significance");
    histset[349]->GetYaxis()->SetTitle("Number of JPsi cand.");

    
    
    
	  /// D mesons, WS
    
     		    /// D star plots		
                    histset[1212]  =  dmesonsAtlasWS.make<TH1D>("h_deltaMassD0Dstar", "", 64, 0.138, 0.17); 	//Mass difference histogram for 'right charge' paring (Atlas Cuts)	    
		    histset[1950]  =  dmesonsAtlasWS.make<TH1D>("h_deltaMassD0Dstar_leftDLcut", "", 64, 0.138, 0.17);
		    histset[1951]  =  dmesonsAtlasWS.make<TH1D>("h_deltaMassD0Dstar_rightDLcut", "", 64, 0.138, 0.17);
		    
		    /// D star plots
                    histset[1224]  =  dmesonsAtlasWS.make<TH1D>("h_D0masscut", "", 60, 1.6, 2.2); 		//D0 mass histogram with a cut on delta M
                    histset[1232]  =  dmesonsAtlasWS.make<TH1D>("h_D0masscut_rightDLcut", "", 60, 1.6, 2.2); 	//D0 mass histogram with a cut on delta M
                    histset[1236]  =  dmesonsAtlasWS.make<TH1D>("h_D0masscut_leftDLcut", "", 60, 1.6, 2.2); 	//D0 mass histogram with a cut on delta M
		    
		    /// DL all mass spectrum: 
		    histset[1952]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_allMassD0","",400, -3, 3);
		    histset[1953]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_allMassD0_gamma","",400, -3, 3);		
		    histset[1954]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_allMassD0_left_clone","",400, -3, 3);
		    histset[1955]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_allMassD0_leftDLcut","",400, -3, 3);		
		    histset[1956]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_allMassD0_rightDLcut","",400, -3, 3);	
		    
		    
		    /// D0 DL left side of D0 mass spectrum: MD0<1.8 && MD0 > 1.75
		    histset[1510]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_leftSide","",400, -3, 3);			
		    histset[1511]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_leftSide_gamma","",400, -3, 3);
		    histset[1512]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_leftSide_left_clone","",400, -3, 3);
		    histset[1513]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_leftSide_leftDLcut","",400, -3, 3);			
		    histset[1514]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_leftSide_rightDLcut","",400, -3, 3);			

		    /// D0 DL right side of D0 mass spectrum: MD0>1.93 && MD0 < 1.98
		    histset[1520]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_rightSide","",400, -3, 3);			
		    histset[1521]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_rightSide_gamma","",400, -3, 3);
		    histset[1522]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_rightSide_lelf_clone","",400, -3, 3);
		    histset[1523]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_rightSide_leftDLcut","",400, -3, 3);			
		    histset[1524]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_rightSide_rightDLcut","",400, -3, 3);
		
		    /// D0 peak region: |MD0-MD0Actual| < 0.025
		    histset[1580]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection","",400, -3, 3);		
		    histset[1581]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_gamma","",400, -3, 3);		
		    histset[1582]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_left_clone","",400, -3, 3);
		    histset[1583]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_leftDLcut","",400, -3, 3);		
		    histset[1584]  =  dmesonsAtlasWS.make<TH1D>("D0_BS_DL_projection_rightDLcut","",400, -3, 3);	

		    /// D0 fitted Vertex parameters:  (fitted with CMS fitter)
                    histset[1500]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_Ntracks","",20, 0, 5);
                    histset[1501]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_PosX","",200, -1, 1);
                    histset[1502]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_PosY","",200, -1, 1);
                    histset[1503]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_PosZ","",200, -50, 50);
                    histset[1504]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_Chi2_Ndof","",400, 0, 100);
                    histset[1525]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_Chi2_Ndof_leftSide","",400, 0, 100);
                    histset[1526]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_Chi2_Ndof_rightSide","",400, 0, 100);	
                    histset[1527]  =  dmesonsAtlasWS.make<TH1D>("Vertex_D0_Chi2_Ndof_signal","",400, 0, 100);
		    
		    /// add PT distributions for D0: 
		    histset[1700]  =  dmesonsAtlasWS.make<TH1D>("D0_allSpectrum_PT", "", 200, 0, 40);
		    histset[1701]  =  dmesonsAtlasWS.make<TH1D>("D0_allSpectrum_PT_leftDLcut", "", 200, 0, 40);
		    histset[1702]  =  dmesonsAtlasWS.make<TH1D>("D0_allSpectrum_PT_rightDLcut", "", 200, 0, 40);

		    histset[1703]  =  dmesonsAtlasWS.make<TH1D>("D0_signal_PT", "", 200, 0, 40);
		    histset[1704]  =  dmesonsAtlasWS.make<TH1D>("D0_signal_PT_leftDLcut", "", 200, 0, 40);
		    histset[1705]  =  dmesonsAtlasWS.make<TH1D>("D0_signal_PT_rightDLcut", "", 200, 0, 40);

		    histset[1706]  =  dmesonsAtlasWS.make<TH1D>("D0_PT_leftSide", "", 200, 0, 40);  
		    histset[1707]  =  dmesonsAtlasWS.make<TH1D>("D0_PT_rightSide", "", 200, 0, 40);

		    histset[1708]  =  dmesonsAtlasWS.make<TH1D>("D0_PT_leftSide_leftDLcut", "", 200, 0, 40); 
		    histset[1709]  =  dmesonsAtlasWS.make<TH1D>("D0_PT_rightSide_leftDLcut", "", 200, 0, 40);
		    histset[1710]  =  dmesonsAtlasWS.make<TH1D>("D0_PT_leftSide_rightDLcut", "", 200, 0, 40);
		    histset[1711]  =  dmesonsAtlasWS.make<TH1D>("D0_PT_rightSide_rightDLcut", "", 200, 0, 40);

		    /// general parameters
		    histset[1730]  =  dmesonsAtlasWS.make<TH1D>("Vertex_Multiplicity_D0mass_allSpectrum", "", 10, 0, 10);
		    histset[1731]  =  dmesonsAtlasWS.make<TH1D>("Vertex_Multiplicity_D0mass_peak", "", 10, 0, 10);
		    histset[1732]  =  dmesonsAtlasWS.make<TH1D>("Ncand_D0mass_allSpectrum", "", 10, 0, 10);
    
    
		/// Bplus plots: 
		histset[400]  =  bplus.make<TH1D>("Bplus_M_spectrum", "", 120, 4.8, 5.7);	
		histset[401]  =  bplus.make<TH1D>("Bplus_P", "", 100, 0, 100);
		histset[402]  =  bplus.make<TH1D>("Bplus_Pt", "", 50, 0, 50);
		histset[403]  =  bplus.make<TH1D>("Bplus_Px", "", 50, 0, 50);
		histset[404]  =  bplus.make<TH1D>("Bplus_Py", "", 50, 0, 50);
		histset[405]  =  bplus.make<TH1D>("Bplus_Pz", "", 100, 0, 100);
                histset[406]  =  bplus.make<TH1D>("Bplus_Rapidity", "", 60, -3, 3);

		histset[409]  =  bplus.make<TH1D>("Bplus_M_spectrum_cut_on_DLcorrBplus_noMcut", "", 120, 4.8, 5.7);
		histset[410]  =  bplus.make<TH1D>("Bplus_Vtx_Chi2_ndof", "", 400, 0., 50);	
		histset[411]  =  bplus.make<TH1D>("Bplus_N_candidates_per_event","", 15, 0., 15);
                histset[407]  =  bplus.make<TH1D>("Bplus_DLxy_mm", "", 160, -4, 4 );
                histset[408]  =  bplus.make<TH1D>("Bplus_DLxy_corr ", "", 160, -4, 4);
		histset[412]  =  bplus.make<TH1D>("Bplus_DLxy_Sign_mm", "", 400, -40, 60 );
		hxhy[200]     =  bplus.make<TH2D>("Bplus_M_vs_ct", "", 160, -4, 4, 120, 4.8, 5.7);	
		hxhy[201]     =  bplus.make<TH2D>("Bplus_M_vs_Sign", "", 160, -20, 20, 120, 4.8, 5.7);

		histset[414]  =  bplus.make<TH1D>("Bplus_DLxy_mm_peak", "", 160, -4, 4 );
                histset[415]  =  bplus.make<TH1D>("Bplus_DLxy_corr_peak ", "", 160, -4, 4);
		histset[416]  =  bplus.make<TH1D>("Bplus_DLxy_Sign_mm_peak", "", 400, -40, 60 );
		histset[417]  =  bplus.make<TH1D>("JPsi_N_candidates_per_event","", 15, 0., 15);
		histset[418]  =  bplus.make<TH1D>("Bplus_DLxy_corr_peak_leftMirr", "", 160, -4, 4);
		histset[419]  =  bplus.make<TH1D>("Bplus_DLxy_Sign_mm_peak_leftMirr", "", 400, -40, 60);
		

		histset[450]  =  bplus.make<TH1D>("Bplus_M_spectrum_1perevent", "", 120, 4.8, 5.7);	
		histset[451]  =  bplus.make<TH1D>("Bplus_P_1perevent", "", 100, 0, 100);
		histset[452]  =  bplus.make<TH1D>("Bplus_Pt_1perevent", "", 50, 0, 50);
		histset[453]  =  bplus.make<TH1D>("Bplus_Px_1perevent", "", 50, 0, 50);
		histset[454]  =  bplus.make<TH1D>("Bplus_Py_1perevent", "", 50, 0, 50);
		histset[455]  =  bplus.make<TH1D>("Bplus_Pz_1perevent", "", 100, 0, 100);
                histset[456]  =  bplus.make<TH1D>("Bplus_Rapidity_1perevent", "", 60, -3, 3);
                histset[457]  =  bplus.make<TH1D>("Bplus_DLxy_mm_1perevent", "", 160, -4, 4 );
                histset[458]  =  bplus.make<TH1D>("Bplus_DLxy_corr_1perevent ", "", 160, -4, 4);
		histset[462]  =  bplus.make<TH1D>("Bplus_DLxy_Sign_mm_1perevent", "", 400, -40, 60 );
		histset[464]  =  bplus.make<TH1D>("Bplus_DLxy_mm_peak_1perevent", "", 160, -4, 4 );
                histset[465]  =  bplus.make<TH1D>("Bplus_DLxy_corr_peak_1perevent ", "", 160, -4, 4);
		histset[466]  =  bplus.make<TH1D>("Bplus_DLxy_Sign_mm_peak_1perevent", "", 400, -40, 60 );

                histset[467]  =  bplus.make<TH1D>("BS_Bplus_DLxy_mm_1perevent", "", 160, -4, 4 );
                histset[468]  =  bplus.make<TH1D>("BS_Bplus_DLxy_corr_1perevent ", "", 160, -4, 4);
		histset[469]  =  bplus.make<TH1D>("BS_Bplus_DLxy_Sign_mm_1perevent", "", 400, -40, 60 );
		histset[470]  =  bplus.make<TH1D>("BS_Bplus_DLxy_mm_peak_1perevent", "", 160, -4, 4 );
                histset[471]  =  bplus.make<TH1D>("BS_Bplus_DLxy_corr_peak_1perevent ", "", 160, -4, 4);
		histset[472]  =  bplus.make<TH1D>("BS_Bplus_DLxy_Sign_mm_peak_1perevent", "", 400, -40, 60 );

		histset[473]  =  bplus.make<TH1D>("Bplus_M_spectrum_cut_on_DLcorrBplus_1perevent", "", 120, 4.8, 5.7);
		histset[474]  =  bplus.make<TH1D>("BS_Bplus_M_spectrum_cut_on_DLcorrBplus_1perevent", "", 120, 4.8, 5.7);
		histset[475]  =  bplus.make<TH1D>("Bplus_M_spectrum_cut_on_DLcorrBplus_peak", "", 120, 4.8, 5.7);
		histset[476]  =  bplus.make<TH1D>("BS_Bplus_M_spectrum_cut_on_DLcorrBplus_peak", "", 120, 4.8, 5.7);
}


DemoAnalyzer::~DemoAnalyzer()
{
 
   // do anything here that needs to be done at destruction time
   // (e.g. close files, deallocate resources etc.)

}


//
// member functions
//

inline double invMass(double p1, double p1x, double p1y, double p1z, double m1 , double p2, double p2x, double p2y, double p2z, double m2);

// ------------ method called for each event  ------------
void
DemoAnalyzer::analyze(const edm::Event& iEvent, const edm::EventSetup& iSetup)
{

// using namespace VxLite;

   using namespace edm;
   using namespace reco;
   using namespace std;
   //using reco::TrackCollection;
   //using reco::VertexCollection;
   //using reco::MuonCollection;


// cout<<"Event Number = "<<iEvent.id().event()<<endl;

Handle<reco::BeamSpot> beamSpotHandle;
Handle<reco::TrackCollection> tracks;
Handle<reco::TrackCollection> gmuons;
Handle<reco::VertexCollection> Primvertex;
Handle<reco::MuonCollection> muons;
Handle<reco::GsfElectronCollection> electrons;

    
 edm:: Handle<edm::View<reco::PFMET> > pfmets;// Handle<reco::PFMET> mets;  didn't work for some reason
edm:: Handle<edm::View<reco::CaloMET> > calomets;
edm:: Handle<edm::View<reco::CaloMET> > muCorrmets;

  #ifdef THIS_IS_AN_EVENT_EXAMPLE 
   Handle<ExampleData> pIn;
   iEvent.getByLabel("example",pIn);
   #endif

   // should we use this?   
   #ifdef THIS_IS_AN_EVENTSETUP_EXAMPLE
   ESHandle<SetupData> pSetup;
   iSetup.get<SetupRecord>().get(pSetup);
   #endif
 
// cout<<"Event Nr "<<iEvent.id().event()<<endl;

  
   //                   fill basic event information                  //
   //    *** still under very preliminary construction   ****
    // JSON Checkers
   //LogInfo("Demo")<<"Event number"<<iEvent.id()<<" Run number"<<iEvent.run();
    {
 histset[200]->Fill(iEvent.run());
 histset[202]->Fill((iEvent.id()).event());
 histset[203]->Fill(iEvent.luminosityBlock());
 // check JSON "by hand"; according to documentation, JSON provides a
 // "list of good lumi sections"
 // if badJSON nonzero event should not be used for analysis
 int badJSON = 0;
 if (iEvent.run() == 146428) {
  if ((iEvent.luminosityBlock() > 2 && iEvent.luminosityBlock() < 11) ||
      (iEvent.luminosityBlock() > 52 && iEvent.luminosityBlock() < 55) ||
      (iEvent.luminosityBlock() > 92))
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146430) {
  if ((iEvent.luminosityBlock() > 12 && iEvent.luminosityBlock() < 18) ||
      (iEvent.luminosityBlock() > 47 && iEvent.luminosityBlock() < 50) ||
      (iEvent.luminosityBlock() > 62 && iEvent.luminosityBlock() < 65) ||
      (iEvent.luminosityBlock() > 90))
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146431) {
  if (iEvent.luminosityBlock() > 23)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146436) {
  if (iEvent.luminosityBlock() > 532)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146437) {
  if (iEvent.luminosityBlock() > 798)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146510) {
  if (iEvent.luminosityBlock() > 510)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146511) {
  if (iEvent.luminosityBlock() == 64 || iEvent.luminosityBlock() > 778)
    badJSON = iEvent.run(); 
 }
else if (iEvent.run() == 146513) {
  if (iEvent.luminosityBlock() == 2 || iEvent.luminosityBlock() > 15)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146514) {
  if (iEvent.luminosityBlock() == 546 || iEvent.luminosityBlock() == 547 || iEvent.luminosityBlock() > 871)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146589) {
  if (iEvent.luminosityBlock() < 34 || iEvent.luminosityBlock() > 248)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146644) {
   if (iEvent.luminosityBlock() < 89 || iEvent.luminosityBlock() == 118 || iEvent.luminosityBlock() == 566 || iEvent.luminosityBlock() == 868 || iEvent.luminosityBlock() == 1033 || (iEvent.luminosityBlock() > 2171 && iEvent.luminosityBlock() < 2369) || iEvent.luminosityBlock() > 2465)
   badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146698) {
   if (iEvent.luminosityBlock() < 155 || (iEvent.luminosityBlock() > 180 && iEvent.luminosityBlock() < 186) || iEvent.luminosityBlock() > 189)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146710) {
   if (iEvent.luminosityBlock() == 116 || (iEvent.luminosityBlock() > 49 && iEvent.luminosityBlock() < 114) || iEvent.luminosityBlock() > 214)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146712) {
   if (iEvent.luminosityBlock() > 69)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146713) {
   if (iEvent.luminosityBlock() == 49 || iEvent.luminosityBlock() > 256)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146715) {
   if (iEvent.luminosityBlock() > 125)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146721) {
   if (iEvent.luminosityBlock() > 6)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146724) {
   if (iEvent.luminosityBlock() == 107 || iEvent.luminosityBlock() == 108 || (iEvent.luminosityBlock() > 109 && iEvent.luminosityBlock() < 112) || iEvent.luminosityBlock() == 151 || iEvent.luminosityBlock() > 159)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146804) {
   if (iEvent.luminosityBlock() < 111 || iEvent.luminosityBlock() == 149 || iEvent.luminosityBlock() == 521 || iEvent.luminosityBlock() == 790 || iEvent.luminosityBlock() == 823 || iEvent.luminosityBlock() > 905)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146807) {
   if (iEvent.luminosityBlock() < 132 || iEvent.luminosityBlock() == 363 || iEvent.luminosityBlock() == 364 || iEvent.luminosityBlock() == 421 || iEvent.luminosityBlock() > 469)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 146944) {
   if (iEvent.luminosityBlock() < 177 || iEvent.luminosityBlock() > 669)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147043) {
   if (iEvent.luminosityBlock() < 161 || iEvent.luminosityBlock() > 500)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147048) {
   if (iEvent.luminosityBlock() < 94 || iEvent.luminosityBlock() > 484)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147114) {
   if (iEvent.luminosityBlock() < 180 || (iEvent.luminosityBlock() > 187 && iEvent.luminosityBlock() < 227) || (iEvent.luminosityBlock() > 240 && iEvent.luminosityBlock() < 247) || iEvent.luminosityBlock() > 667)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147115) {
   if (iEvent.luminosityBlock() > 546)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147116) {
   if (iEvent.luminosityBlock() > 54)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147196) {
   if (iEvent.luminosityBlock() > 90)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147214) {
   if (iEvent.luminosityBlock() > 79)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147216) {
   if (iEvent.luminosityBlock() > 63)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147217) {
   if (iEvent.luminosityBlock() > 193)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147218) {
   if (iEvent.luminosityBlock() > 45)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147219) {
   if ((iEvent.luminosityBlock() > 293 && iEvent.luminosityBlock() < 309) || iEvent.luminosityBlock() > 320)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147222) {
   if (iEvent.luminosityBlock() > 444)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147284) {
   if (iEvent.luminosityBlock() < 32 || iEvent.luminosityBlock() > 306)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147390) {
   if (iEvent.luminosityBlock() == 479 || iEvent.luminosityBlock() > 837)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147450) {
   if (iEvent.luminosityBlock() < 80 || iEvent.luminosityBlock() > 166)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147451) {
   if (iEvent.luminosityBlock() == 117 || iEvent.luminosityBlock() > 129)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147452) {
   if (iEvent.luminosityBlock() > 44)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147453) {
   if (iEvent.luminosityBlock() > 146)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147454) {
   if (iEvent.luminosityBlock() > 97)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147754) {
   if (iEvent.luminosityBlock() == 168 || iEvent.luminosityBlock() == 169 || iEvent.luminosityBlock() > 377)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147755) {
   if (iEvent.luminosityBlock() < 81 || iEvent.luminosityBlock() > 231)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147757) {
   if (iEvent.luminosityBlock() > 359)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147926) {
   if (iEvent.luminosityBlock() < 77 || iEvent.luminosityBlock() > 548)
   badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147927) {
   if (iEvent.luminosityBlock() > 152)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 147929) {
   if ((iEvent.luminosityBlock() > 266 && iEvent.luminosityBlock() < 272) || iEvent.luminosityBlock() == 619 || iEvent.luminosityBlock() > 643)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148002) {
   if (iEvent.luminosityBlock() < 92 || iEvent.luminosityBlock() > 203)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148029) {
   if (iEvent.luminosityBlock() < 50 || iEvent.luminosityBlock() == 484 || iEvent.luminosityBlock() == 570 || iEvent.luminosityBlock() > 571)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148031) {
   if ((iEvent.luminosityBlock() > 341 && iEvent.luminosityBlock() < 472) || iEvent.luminosityBlock() == 758 || iEvent.luminosityBlock() > 855)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148032) {
  if (iEvent.luminosityBlock() > 199)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148058) {
   if (iEvent.luminosityBlock() > 97)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148822) {
   if (iEvent.luminosityBlock() > 446)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148829) {
   if ((iEvent.luminosityBlock() > 240 && iEvent.luminosityBlock() < 244) || iEvent.luminosityBlock() == 74 || iEvent.luminosityBlock() > 303)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148860) {
   if (iEvent.luminosityBlock() > 39)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148862) {
   if (iEvent.luminosityBlock() == 19 || iEvent.luminosityBlock() == 109 || iEvent.luminosityBlock() == 150 || (iEvent.luminosityBlock() > 165 && iEvent.luminosityBlock() < 224) || (iEvent.luminosityBlock() > 258 && iEvent.luminosityBlock() < 262) || iEvent.luminosityBlock() == 298 || iEvent.luminosityBlock() == 367 || (iEvent.luminosityBlock() > 504 && iEvent.luminosityBlock() < 512) || iEvent.luminosityBlock() > 679)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148864) {
   if (iEvent.luminosityBlock() == 32 || (iEvent.luminosityBlock() > 141 && iEvent.luminosityBlock() < 224) || iEvent.luminosityBlock() == 237 || iEvent.luminosityBlock() == 477 || iEvent.luminosityBlock() > 680)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148952) {
   if (iEvent.luminosityBlock() < 70 || iEvent.luminosityBlock() > 257)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 148953) {
   if (iEvent.luminosityBlock() > 100)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149003) {
   if (iEvent.luminosityBlock() < 84 || iEvent.luminosityBlock() > 238)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149011) {
   if (iEvent.luminosityBlock() == 342 || iEvent.luminosityBlock() > 706)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149058) {
   if (iEvent.luminosityBlock() > 65)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149063) {
   if (iEvent.luminosityBlock() > 102)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149181) {
   if (iEvent.luminosityBlock() < 229 || (iEvent.luminosityBlock() > 1840 && iEvent.luminosityBlock() < 1844) || iEvent.luminosityBlock() > 1920)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149291) {
   if (iEvent.luminosityBlock() < 79 || (iEvent.luminosityBlock() > 79 && iEvent.luminosityBlock() < 82) || iEvent.luminosityBlock() == 787 || iEvent.luminosityBlock() == 789 || (iEvent.luminosityBlock() > 790 && iEvent.luminosityBlock() < 794) || iEvent.luminosityBlock() > 794)
    badJSON = iEvent.run(); 
 }
 else if (iEvent.run() == 149294) {
  if (iEvent.luminosityBlock() > 171)
    badJSON = iEvent.run(); 
 }
 else {
   badJSON = iEvent.run(); 
 }

// signal presence of bad JSON event
if (badJSON > 0) {
  LogInfo("Demo")<<"bad JSON Event id"<<iEvent.id();
  histset[201]->Fill(iEvent.run()); 
  // find out how to exit here ...
 }
else {
  histset[204]->Fill(iEvent.run());
 }
}
   // LogInfo("Demo")<<"Event number"<<(iEvent.id()).event()<<" Run number"<<iEvent.run()<<"  Lumi:"<<iEvent.luminosityBlock();


 //                 event is to be kept                      //
 //                 load relevant event information          //

 iEvent.getByLabel("muons", muons);
 iEvent.getByLabel("globalMuons", gmuons);
 iEvent.getByLabel("generalTracks", tracks); 
 iEvent.getByLabel("offlineBeamSpot", beamSpotHandle);
 iEvent.getByLabel("gsfElectrons",electrons);
 iEvent.getByLabel("pfMet",pfmets);
 iEvent.getByLabel("met",calomets);
 iEvent.getByLabel("corMetGlobalMuons",muCorrmets);

  histset[133]-> Fill((pfmets->front()).et());
 histset[134]-> Fill((calomets->front()).et());
 histset[135]-> Fill((muCorrmets->front()).et());
 reco::BeamSpot beamSpot;
 if ( beamSpotHandle.isValid() )
{
    beamSpot = *beamSpotHandle;

} else
{
    edm::LogInfo("Demo")
      << "No beam spot available from EventSetup \n";
}

 // choose primary verices with/without beam spot
 
 iEvent.getByLabel("offlinePrimaryVerticesWithBS",Primvertex);
 //iEvent.getByLabel("offlinePrimaryVertices",Primvertex);
 
 // fill basic track information (all tracks in event)

 histset[6]->Fill(tracks->size());
 if ( (tracks->size()) != 0 ) {  histset[240]->Fill(tracks->size()); }
 histset[26]->Fill(Primvertex->size());

    
    Handle<PFJetCollection>   pfjets;
    iEvent.getByLabel("ak7PFJets",pfjets);
    
    
    for(PFJetCollection::const_iterator i_pfjet = pfjets->begin(); i_pfjet != pfjets->end(); i_pfjet++)
    {
        
        histset[261]->Fill(i_pfjet->pt());
        histset[262]->Fill(i_pfjet->eta());
        
    }
    
    
    
 // loop over tracks

  for( reco::TrackCollection::const_iterator it = tracks->begin(); it !=
 tracks->end(); it++) {
    // LogInfo("Demo")<<"track p"<<it->p()<< "  track reference position"<<it->referencePoint()<< "   track vertex position"<<it->vertex();
    histset[34]->Fill(it->p());
    histset[35]->Fill(it->pt());
    histset[38]->Fill(it->eta());
    histset[81]->Fill(it->phi());

      

  //  if (it->eta() < 0) {hxhy[0]->Fill((-1)*(it->eta()), it->pt());} TEST
//	else {hxhy[0]->Fill(it->eta(), it->pt());}

  
   // histset[23]->Fill(it->vx());
   //histset[24]->Fill(it->vy());
   // histset[25]->Fill(it->vz());

   // fill histograms for QCD-10-006

   if(fabs(it->eta())<=0.200){
     
     histset[9]->Fill(it->pt());}

if(fabs(it->eta())>0.200 && fabs(it->eta())<0.400){
   
     histset[10]->Fill(it->pt());}
 if(fabs(it->eta())>0.400 && fabs(it->eta())<=0.600){
     
     histset[11]->Fill(it->pt());}
if(fabs(it->eta())<0.600 && fabs(it->eta())<=0.800){
 
     histset[12]->Fill(it->pt());}
if(fabs(it->eta())>0.800 && fabs(it->eta())<=1.00){
  
     histset[13]->Fill(it->pt());}
if(fabs(it->eta())>1.00 && fabs(it->eta())<=1.20){
   
     histset[14]->Fill(it->pt());}
if(fabs(it->eta())>1.200 && fabs(it->eta())<=1.40){
                                      
     histset[15]->Fill(it->pt());}
if(fabs(it->eta())>1.400 && fabs(it->eta())<=1.60){
    
     histset[16]->Fill(it->pt());}
if(fabs(it->eta())>1.600 && fabs(it->eta())<=1.80){
  
     histset[17]->Fill(it->pt());}
if(fabs(it->eta())>1.800 && fabs(it->eta())<=2.00){
  
     histset[18]->Fill(it->pt());}
if(fabs(it->eta())>2.000 && fabs(it->eta())<=2.20){

     histset[19]->Fill(it->pt());}
if(fabs(it->eta())>2.200 && fabs(it->eta())<=2.40){
    
     histset[20]->Fill(it->pt());}
if(fabs(it->eta())>2.400 && fabs(it->eta())<=2.60){

     histset[21]->Fill(it->pt());}

  }//end of track collection loop
    
    
    /// **************************************************************************************************   ///
    /// New adds for Vertex information: ///
    
    /// Declare objects: Track, Vertex builder, BeamSpot, Transient Track collection for the PVcies.
    /// Should be moved into Declare variables section!?
    
    /// Declaration:
    
/// Load the tools to work with vertices: 
    //      declare new track builder for my new Transient track collection  ;
    ESHandle<TransientTrackBuilder> theB;
    iSetup.get<TransientTrackRecord>().get("TransientTrackBuilder",theB);
    
    //      to get BeamSpot information:
    Handle<reco::BeamSpot> recoBeamSpotHandle;
    iEvent.getByLabel("offlineBeamSpot", recoBeamSpotHandle);
    reco::BeamSpot vertexBeamSpot= *recoBeamSpotHandle;
    
    //      will contain all tracks from PVcies:
    	    vector<TransientTrack> mytracksPV;
    
   
    //      vector<TransientTrack> mytracksTEST;
    	    vector<reco::TransientTrack> genralTracksTEST = (*theB).build(tracks);
    
	    vector<reco::TransientTrack> AllgenralTracks = (*theB).build(tracks);


/// Set magnetic field here: 
	ESHandle<MagneticField> BField;
	iSetup.get<IdealMagneticFieldRecord>().get(BField);

/// Set Beam Spot Information:	
	Handle<reco::BeamSpot> beamSpotHandle_I;
	iEvent.getByLabel("offlineBeamSpot", beamSpotHandle_I);


    /// ************************************************************************************************** ///


  // fill basic vertex information

  int size; // variable to store the size of vertices in an event
  size=Primvertex->size();

  // loop over primary vertices

// if (iEvent.id().event() == 445173766 )	{


/// ********************
/*
        for( vector<TransientTrack>::iterator gt_trans_test = genralTracksTEST.begin(); gt_trans_test !=genralTracksTEST.end(); gt_trans_test++)
        {
		const reco::TrackRef trackRefT = (gt_trans_test->trackBaseRef()).castTo<reco::TrackRef>();
    
		enum index { i_transverseCurvature = 0 , i_theta, i_phi0, i_d0, i_dz };



cout<<trackRefT->parameter(i_transverseCurvature)<<"	"<<trackRefT->parameter(i_theta)<<"	"<<trackRefT->parameter(i_phi0)<<"	"<<-1*trackRefT->parameter(i_d0)<<"	"<<trackRefT->parameter(i_dz)<<endl;;



	}

*/
/// ********************

bool output = false;

if (output) {cout<<" ##############################################  New event start here ########################################################"<<endl;}


if (Primvertex->size() > 0)	{

  for(reco::VertexCollection::const_iterator ite = Primvertex->begin(); ite !=Primvertex->end(); ite++) {
    
  //  flag indicating whether a muon candidate is associated to this vertex
  // int Muflag=0;

  // store z position of first vertex 
  if(ite== Primvertex->begin())firstz=ite->z();
  
// if (ite->tracksSize() == 2)	{

// cout<<" Vtx XYZ from data = "<<ite->x()<<"	"<<ite->y()<<"	"<<ite->z()<<endl;

if (output) {
cout<<"new vertex start here: #######################################################################################################"<<endl;
}
// if (ite->tracksSize() == 2) cout<<"HERE is EVENT for the CHECK!!! "<<endl;


  // loop over muon collection to check for muon tracks associated to this vertex, i.e. track refernce position close to the vertex
  for (MuonCollection::const_iterator itMuon = muons->begin(); itMuon != muons->end(); ++itMuon) {
  //  if((itMuon->track()).isNonnull()){
 // SL6:  
 // if(fabs(ite->x()-(itMuon->track())->vx())<=0.1 && fabs(ite->y()-(itMuon->track())->vy())<=0.1 && fabs(ite->z()-(itMuon->track())->vz())<=1.0)
 // Muflag=1; // The vertex has a muon associated to it

 //   }
  }  // end of loop over muon collection

    if(ite->tracksSize()==0){ //This is done so that there are no vertices with zero tracks stored in the histogram.
      size=size-1; }

    /// store distance of vertex to first vertex
 if(ite->z()!=firstz)
    {
      deltaz=fabs(firstz-(ite->z()));
      histset[22]->Fill(deltaz);
      }
      
      //  loop over all tracks from this vertex, usefull variable
      vector<TransientTrack> mytracks;
//     if(ite->tracksSize()!=0 && Muflag==0)

// only store the coordinates of those vertices which are valid and have tracks && have no muons (= "next-to-miminum bias")
// very first attempt in context of FWD-11-001

 //     { 


if (output)	{
	cout<<"X data = "<<ite->x()<<endl;
	cout<<"Y data = "<<ite->y()<<endl;
	cout<<"Z data = "<<ite->z()<<endl;
	}
// 	cout<<" Vtx XYZ from data = "<<ite->x()<<"	"<<ite->y()<<"	"<<ite->z()<<endl;



              //-----to get track details for valid vertices-------------//

    //  LogInfo("Demo")<<"Vertex position"<<ite->position()<<endl;

    //  loop over all tracks from this vertex
    int counter=0;  

double PxPV = 0.; 
// double PyPV = 0.; 
//double PzPV = 0.; 

 for(reco::Vertex::trackRef_iterator iTrack  =ite->tracks_begin(); iTrack != ite->tracks_end();++iTrack) { 
// for dealing with tracks associated with a particular vertex


   // why *iTrack ??
      histset[27]->Fill((*iTrack)->pt()); // vertex.track pt
      histset[28]->Fill((*iTrack)->p()); // vertex.track p
      histset[85]->Fill((*iTrack)->eta());
      histset[82]->Fill((*iTrack)->phi());

      // LogInfo("Demo")<<"Vertex track p"<<(*iTrack)->p()<<"  Vertex trackposition"<<(*iTrack)->referencePoint();

      PxPV = PxPV + (*iTrack)->px();
  //    PyPV = PxPV + (*iTrack)->py();
  //    PzPV = PxPV + (*iTrack)->pz();

	
      counter++;

// 	cout<<"track Pt, eta, phi = "<<(*iTrack)->pt()<<"	"<<(*iTrack)->eta()<<"	"<<(*iTrack)->phi()<<endl;

// cout<<"Track #"<<counter<<" P = "<<(*iTrack)->p()<<" Pt = "<<(*iTrack)->pt()<<"	Eta = "<<(*iTrack)->eta()<<" Phi = "<<(*iTrack)->phi()<<endl;

/// tests with vertices

     // NEW:
     // create a new track collection:
     const reco::TrackRef trackRef = iTrack->castTo<reco::TrackRef>();
     TransientTrack  transientTrack = theB->build(trackRef);
     transientTrack.setBeamSpot(vertexBeamSpot);
     mytracks.push_back(transientTrack);
     mytracksPV.push_back(transientTrack);   // this collection will be used as PVcies track collection;

     
 }

	// double Pt_PV = sqrt(PxPV*PxPV+PyPV*PyPV);	
	// double P_PV = sqrt(Pt_PV*Pt_PV+PzPV*PzPV);

	//cout<<"Vtx P, Pt = "<<P_PV<<"	"<<Pt_PV<<endl;



// cout<<"has refited tracks : "<<ite->hasRefittedTracks()<<endl;


 // fill number of tracks associated to this vertex (is it Ok to fill int?)
 histset[86]->Fill(counter);
    


 //     }// end of if(ite->tracksSize()!=0 && Muflag==0)
      
      ///---------------------------------------- Refit PV again to compare it with one from dataBase----------------------------------------  ///
      
//       cout<<"N tracks per vertex = "<< ite->tracksSize()<<"  ";
//       if (ite->ndof() > 0)    { cout<<"Chi2/ndof = "<<(ite->chi2()/ite->ndof())<<endl; }
      	AdaptiveVertexFitter  theFitter;
	TransientVertex myVertexBS;

      /// REFit tracks from new collection, for ONE vertex:
      if ( mytracks.size()>1 /*&& mytracks.size()< 200*/)
      {
          
          myVertexBS = theFitter.vertex(mytracks/*, vertexBeamSpot*/);                        	// if you want the beam constraint
//           myVertexBS = theFitter.vertex(mytracks);                                          			// if you don't want the beam constraint
//           cout << " "<< myVertexBS.position().z() <<" size = "<<(myVertexBS.originalTracks()).size()<< endl;

if (output /*&& iEvent.id().event() == 289466482*/ ) 	{
	  	cout<<"Vtx no BS : "<<endl;
		cout<<"Ntrack = "<<mytracks.size()<<endl;
		cout<<"X = "<<myVertexBS.position().x()<<" +- "<<sqrt(myVertexBS.positionError().cxx())<<endl;
		cout<<"Y = "<<myVertexBS.position().y()<<" +- "<<sqrt(myVertexBS.positionError().cyy())<<endl;
		cout<<"Z = "<<myVertexBS.position().z()<<" +- "<<sqrt(myVertexBS.positionError().czz())<<endl;
		cout<<"Chi2 = "<<myVertexBS.normalisedChiSquared()*myVertexBS.degreesOfFreedom()<<endl;
							}

			if ( myVertexBS.isValid() )						{
// 		if (Pt_PV > 5.0 /* && ite->tracksSize() == 2*/)		{
			histset[36]->Fill(myVertexBS.position().x());
        		histset[37]->Fill(myVertexBS.position().y());
        		 histset[7]->Fill(myVertexBS.position().z());
			histset[305]->Fill(myVertexBS.normalisedChiSquared());
        		histset[87]->Fill(ite->tracksSize());
// 									}
		
												}
       //else

//       {
//           cout << "not enough tracks left" <<std::endl;
//       }



/// CMS helix parameter format transforms here into ZEUS format
/// 
/// Set transient track collection here: 
HelixTrans ZeusVertexFit(false);
/// Set track Builder here: 
	ZeusVertexFit.SetBuilder(theB);
/// Set magnetic field here: 
	ZeusVertexFit.SetMagneticField(BField);
/// Set Beam Spot Information:	
	ZeusVertexFit.SetBeamSpotInformation(beamSpotHandle_I);

/// Set all tracks from the event:
/// It is used for "GetTracksNotFromPVs" function;
	ZeusVertexFit.SetGeneralTrackCollection(AllgenralTracks);

/// Set tracks here: 
// 	vector<TransientTrack> tracksFromPVcheck =  ZeusVertexFit.GetTracksFromPV(ite);
// 	ZeusVertexFit.SetTrackCollectionForAlgorithm(tracksFromPVcheck);
// 	ZeusVertexFit.SetTrackCollectionToFit(mytracks);
/// Make a fit here: 
	vector <double> VtxParametersZEUScheck;
//  	VtxParametersZEUScheck = ZeusVertexFit.SimpleFitWithFitterCMS(mytracks, ite, false);
 	VtxParametersZEUScheck = ZeusVertexFit.SimpleFitWithVxlite(mytracks, ite, false);
/// Make a Prints here: 
/// does not work after upgrade
// // ZeusVertexFit.PrintFitResults();	
// does not work properly at the moment (created for the track iterator);
// 	ZeusVertexFit.PrintHelixParsZeus();
// 	ZeusVertexFit.PrintCovarianceMatrixZEUS();


        if ( myVertexBS.isValid() )                             {
/// dR vertex form data and refited : 
double dRVertex = ZeusVertexFit.PrintdRtoVertex(VtxParametersZEUScheck, myVertexBS.position().x(), myVertexBS.position().y(), myVertexBS.position().z());
// hxhy[100]->Fill(mytracks.size(), dRVertex);
// cout<<"dR = "<<dRVertex<<endl;

// 	if ( myVertexBS.isValid() )				{	
// if ( Pt_PV > 5.0  /* && ite->tracksSize() == 2*/)	{
histset[300]->Fill(VtxParametersZEUScheck[3]);
histset[301]->Fill(VtxParametersZEUScheck[4]);
histset[302]->Fill(VtxParametersZEUScheck[5]);
histset[303]->Fill(dRVertex);
histset[304]->Fill(VtxParametersZEUScheck[9]);
// 			}	
								}

VtxParametersZEUScheck.clear();
} /// track collection size;


/*
	// TEST to fin out proper transformations for helix parameters ZEUS-> CMS	
      ///------------------------------------------------------------------------------------------------------------------------ ///

// Linearization Point

	/// test with ZEUS vxlite tools: 

	float chi2_cut = 200;
	DAFVertexFinder finder(0.);
	float helix_par[100][5];
	float helix_par_cov[100][15];
        float helix_par_zeus[100][5];
        float helix_par_cov_zeus[100][15];
	float track_P[100] ;

	int trk_counter = 0;

	for( vector<TransientTrack>::iterator  gnr_trk_it = mytracks.begin(); gnr_trk_it !=mytracks.end(); gnr_trk_it++)
        {
		const reco::TrackRef trackRef = (gnr_trk_it->trackBaseRef()).castTo<reco::TrackRef>();
        	TransientTrack  transientTr = theB->build(trackRef);
	        
		enum index { i_transverseCurvature = 0 , i_theta, i_phi0, i_d0, i_dz };

        	helix_par[trk_counter][0] = trackRef->parameter(i_transverseCurvature);
// 		cout<<" P original = "<<1/helix_par[trk_counter][0]<<endl;

        	helix_par[trk_counter][1] = trackRef->parameter(i_theta);
        	helix_par[trk_counter][2] = trackRef->parameter(i_phi0);
        	helix_par[trk_counter][3] = -1*trackRef->parameter(i_d0);
        	helix_par[trk_counter][4] = trackRef->parameter(i_dz);

// 		double theta_calc = M_PI/2. - helix_par[trk_counter][1];
		track_P[trk_counter] = fabs((gnr_trk_it->track()).p());


	        GlobalPoint vert(0., 0., 0.);
// 		GlobalPoint vert(trackRef->vx(),  trackRef->vy(),  trackRef->vz());
        	TrajectoryStateClosestToPoint  traj = transientTr.trajectoryStateClosestToPoint(vert );

	        ESHandle<MagneticField> magfield;
        	iSetup.get<IdealMagneticFieldRecord>().get(magfield);
	        const MagneticField *b = &*magfield;

	        double x_dca = traj.position().x();
        	double y_dca = traj.position().y();
	        double z_dca = traj.position().z();

// 	        GlobalPoint gp(x_dca, y_dca, z_dca);
		GlobalPoint gp( trackRef->vx(),  trackRef->vy(),  trackRef->vz());
	        GlobalVector bvec = b->inTesla( gp );
		double Bz = bvec.z();


		//double rho = sin(theta_calc)/(0.0029979*Bz*helix_par[trk_counter][0]);
	/// this part use point on the helix but not the reference point
        double p1_1 = traj.perigeeParameters().transverseCurvature();
        double p2_1 = M_PI/2.-traj.perigeeParameters().theta();			/// here .theta() return real theta! not lambda
        double p3_1 = traj.perigeeParameters().phi();
        double p4_1 = traj.perigeeParameters().transverseImpactParameter();		/// to fit it with original perigee parameters
        double p5_1 = traj.perigeeParameters().longitudinalImpactParameter();



// 	cout<<"Track pars dca = :"<<p1_1<<"	"<<p2_1<<"	"<<p3_1<<"	"<<p4_1<<"	"<<p5_1<<endl;
// 	if (p2_1 < 0) p2_1 += M_PI;
	/// to use some point on the helix
//         	helix_par[trk_counter][0] = p1_1;
//         	helix_par[trk_counter][1] = p2_1;
//         	helix_par[trk_counter][2] = p3_1;
//         	helix_par[trk_counter][3] = -1*p4_1;
//         	helix_par[trk_counter][4] = p5_1;


// cout<<"Track pars     = :"<<helix_par[trk_counter][0]<<"	"<<helix_par[trk_counter][1]<<"	"<<helix_par[trk_counter][2]<<"	"<<helix_par[trk_counter][3]<<"	"<<helix_par[trk_counter][4]<<endl;
		double rho = cos(helix_par[trk_counter][1])/(0.0029979*Bz*helix_par[trk_counter][0]);

// cout<<"Track pars = :"<<helix_par[trk_counter][0]<<"	"<<helix_par[trk_counter][1]<<"	"<<helix_par[trk_counter][2]<<"	"<<helix_par[trk_counter][3]<<"	"<<helix_par[trk_counter][4]<<endl;
// cout<<"Rho[cm] = "<<rho<<" q/R = "<< 1./rho<<"	"<<endl;

        reco::TrackBase::CovarianceMatrix covma = (gnr_trk_it->track()).covariance();
	ROOT::Math::SMatrix<double,5> helix_cov_M;
	ROOT::Math::SMatrix<double,5> helix_Jacoby;
	ROOT::Math::SMatrix<double,5> helix_cov_M_zeus;

// 		helix_par_zeus[trk_counter][0] = helix_par[trk_counter][2];
// 		helix_par_zeus[trk_counter][1] = (helix_par[trk_counter][0]*helix_par[trk_counter][0]*fabs(track_P[trk_counter])*(0.0029979*Bz))/cos(helix_par[trk_counter][1]); 
// // 		helix_par_zeus[trk_counter][2] = p4_1*helix_par[trk_counter][0]*track_P[trk_counter];
// // 		helix_par_zeus[trk_counter][3] = p5_1;
// 		helix_par_zeus[trk_counter][2] = fabs(helix_par[trk_counter][3])*helix_par[trk_counter][0]*fabs(track_P[trk_counter]);
// 		helix_par_zeus[trk_counter][3] = helix_par[trk_counter][4];
// 		helix_par_zeus[trk_counter][4] = tan(helix_par[trk_counter][1]);

		helix_par_zeus[trk_counter][0] = helix_par[trk_counter][2];									/// phi
		helix_par_zeus[trk_counter][1] = 1./rho; //(0.0029979*Bz)/(cos(helix_par[trk_counter][1])*track_P[trk_counter]); 		/// q/rho
		helix_par_zeus[trk_counter][2] = helix_par[trk_counter][3]*helix_par[trk_counter][0]/fabs(helix_par[trk_counter][0]);		/// q*Dh	
		helix_par_zeus[trk_counter][3] = helix_par[trk_counter][4]/cos(helix_par[trk_counter][1]);									/// zh
		helix_par_zeus[trk_counter][4] = tan(helix_par[trk_counter][1]);								/// cotan(theta)

// cout<<"Zeus pars : "<<helix_par_zeus[trk_counter][0]<<"	"<<helix_par_zeus[trk_counter][1]<<"	"<<helix_par_zeus[trk_counter][2]<<"	"<<helix_par_zeus[trk_counter][3]<<"	"<<helix_par_zeus[trk_counter][4]<<endl;

// cout<<p4_1<<"	"<<trackRef->parameter(i_d0)<<endl;
// cout<<"Tr curvature = "<<1/p1_1<<"	"<<track_P[trk_counter]<<" 	charge  = "<<(gnr_trk_it->track()).charge()<<endl;

/// Track parameters example;
// -0.169563       0.00658682      -0.0222098      -5.97455        4.67188
// -3.13956        0.00398055      -0.00321931     -5.28136        3.97193

					
// cout<<helix_par_zeus[trk_counter][0]<<"	"<<helix_par_zeus[trk_counter][1]<<"	"<<helix_par_zeus[trk_counter][2]<<"	"<<helix_par_zeus[trk_counter][3]<<"	"<<helix_par_zeus[trk_counter][4]<<endl;

// 		cout<<"Dh compare : "<<	p4_1 <<"	"<<helix_par[trk_counter][3]<<endl;
// 		cout<<"Z0 compare : "<<	p5_1 <<"	"<<helix_par[trk_counter][4]/cos(p2_1)<<endl;
		

//		cout<<"Fast check = "<<p4_1<<"	"<<helix_par[trk_counter][3]<<endl;
//		cout<<"Fast check = "<<p5_1<<"  "<<helix_par[trk_counter][4]<<endl;

	//	cout<<" Covariance Matrix for tracks: "<<endl;

// 		helix_par_cov[trk_counter][0]  = covma(0,0); helix_par_cov[trk_counter][1]  = covma(0,1); helix_par_cov[trk_counter][2]  = covma(0,2);
// 		helix_par_cov[trk_counter][3]  = covma(0,3); helix_par_cov[trk_counter][4]  = covma(0,4); helix_par_cov[trk_counter][5]  = covma(1,1);
// 		helix_par_cov[trk_counter][6]  = covma(1,2); helix_par_cov[trk_counter][7]  = covma(1,3); helix_par_cov[trk_counter][8]  = covma(1,4);
// 		helix_par_cov[trk_counter][9]  = covma(2,2); helix_par_cov[trk_counter][10] = covma(2,3); helix_par_cov[trk_counter][11] = covma(2,4);
// 		helix_par_cov[trk_counter][12] = covma(3,3); helix_par_cov[trk_counter][13] = covma(3,4); helix_par_cov[trk_counter][14] = covma(4,4);


// 		theta_c = atan(1./helix_par_zeus[trk_counter][4]) ;
// 		if (theta_c < 0) theta_c += M_PI;


		for (int iM = 0; iM< 5; iM++)	{
			for (int jM = 0; jM<5; jM++)	{
				helix_cov_M[iM][jM] = covma(iM,jM);
				helix_Jacoby[iM][jM] = 0.;
							}
						}

		//helix_cov_M.Print(std::cout);



helix_Jacoby[0][2] = 1.;
helix_Jacoby[1][0] = helix_par_zeus[trk_counter][1]/helix_par[trk_counter][0]; 
helix_Jacoby[1][1]=  helix_par_zeus[trk_counter][1]*helix_par_zeus[trk_counter][4];
helix_Jacoby[2][3] = helix_par[trk_counter][0]/fabs(helix_par[trk_counter][0]);
helix_Jacoby[3][1] = helix_par_zeus[trk_counter][3]*helix_par_zeus[trk_counter][4];
helix_Jacoby[3][4] = 1./cos(helix_par[trk_counter][1]);
helix_Jacoby[4][1] = 1./(cos(helix_par[trk_counter][1])*cos(helix_par[trk_counter][1]));


                //helix_cov_M_zeus = helix_cov_M->Similarity(helix_Jacoby);
		
		helix_cov_M_zeus = helix_Jacoby* helix_cov_M * ROOT::Math::Transpose(helix_Jacoby);	
// 		helix_cov_M_zeus.Print(std::cout); cout<<endl;


                helix_par_cov[trk_counter][0]  = helix_cov_M_zeus[0][0]; helix_par_cov[trk_counter][1]  = helix_cov_M_zeus[0][1]; helix_par_cov[trk_counter][2]  = helix_cov_M_zeus[0][2];
                helix_par_cov[trk_counter][3]  = helix_cov_M_zeus[0][3]; helix_par_cov[trk_counter][4]  = helix_cov_M_zeus[0][4]; helix_par_cov[trk_counter][5]  = helix_cov_M_zeus[1][1];
                helix_par_cov[trk_counter][6]  = helix_cov_M_zeus[1][2]; helix_par_cov[trk_counter][7]  = helix_cov_M_zeus[1][3]; helix_par_cov[trk_counter][8]  = helix_cov_M_zeus[1][4];
                helix_par_cov[trk_counter][9]  = helix_cov_M_zeus[2][2]; helix_par_cov[trk_counter][10] = helix_cov_M_zeus[2][3]; helix_par_cov[trk_counter][11] = helix_cov_M_zeus[2][4];
                helix_par_cov[trk_counter][12] = helix_cov_M_zeus[3][3]; helix_par_cov[trk_counter][13] = helix_cov_M_zeus[3][4]; helix_par_cov[trk_counter][14] = helix_cov_M_zeus[4][4];


//		cout<<"Px = "<<(gnr_trk_it->track()).px()<<"	"<<cos(helix_par_zeus[trk_counter][0])*sin(theta_c)*track_P[trk_counter]<<endl;
//		cout<<"Transverce curv = "<<helix_par[trk_counter][0]<<"	"<<(gnr_trk_it->track()).charge()/track_P[trk_counter]<<endl;

		finder.addTrack(new LinearizedTrack(trk_counter+1, helix_par_zeus[trk_counter], helix_par_cov[trk_counter]));
		//finder.addTrack(new LinearizedTrack(trk_counter+1, helix_par_zeus[trk_counter], helix_cov_M_zeus[trk_counter]));	

		trk_counter++;

	}	/// end of the transient track loop



 			double  sumofweights = 0;
 			sumofweights = finder.findVertex();
// 			cout<<"Weight = "<<sumofweights<<endl;
 
// 			cout<<"CHeck1"<<endl;
 			const VxLite::VertexFitter* fitter = finder.fitter();
//			cout<<"CHeck2"<<endl;
// 			cout<<"Refited cordinates   : "<<fitter->vertex()[0]<<"	"<<fitter->vertex()[1]<<"	"<<fitter->vertex()[2]<<"	"<<fitter->chi2()<<endl;
// // 			cout<<"From data cordinates : "<<orange.Vtxsec_x[vtx]<<"	"<<vtxsec_y[vtx]<<"	"<<vtxsec_z[vtx]<<endl;

    			CLHEP::HepSymMatrix cov_mat = fitter->covariance();

		cout<<"Refitted : "<<endl;
		cout<<fitter->vertex()[0]<<" +- "<<sqrt(cov_mat[0][0])<<endl;
		cout<<fitter->vertex()[1]<<" +- "<<sqrt(cov_mat[1][1])<<endl;
		cout<<fitter->vertex()[2]<<" +- "<<sqrt(cov_mat[2][2])<<endl;
		cout<<"Chi2 = "<<fitter->chi2()<<endl;



			float dR= 0.;
			dR = dR + (ite->x()-fitter->vertex()[0])*(ite->x()-fitter->vertex()[0]);
			dR = dR + (ite->y()-fitter->vertex()[1])*(ite->y()-fitter->vertex()[1]);
			dR = dR + (ite->z()-fitter->vertex()[2])*(ite->z()-fitter->vertex()[2]);
			dR = sqrt( dR );


			float dRShow = 0.;
			dRShow = dRShow + (myVertexBS.position().x()-fitter->vertex()[0])*(myVertexBS.position().x()-fitter->vertex()[0]);
			dRShow = dRShow + (myVertexBS.position().y()-fitter->vertex()[1])*(myVertexBS.position().y()-fitter->vertex()[1]);
			dRShow = dRShow + (myVertexBS.position().z()-fitter->vertex()[2])*(myVertexBS.position().z()-fitter->vertex()[2]);
			dRShow = sqrt( dRShow );
			cout<<"dR no BS constraint = "<<dRShow<<endl;

 			finder.reset();
			

//} /// end of my loop
//} /// end of my loop 2

//	}	/// ite->tracksSize() == 2 end of the if

*/
      
// } // end of vertex collection loop


// if (output)	{cout<<"Event Nr "<<iEvent.id().event()<<endl;}

// if ( iEvent.id().event() == 445173766 ) 	{

/// + algorithm: 
/// Set HelixTrans object and setups: 
if (output)	
{
cout<<"********************* ALGORITHM + REFIT HERE: ************************************** "<<endl;
cout<<"N all tracks = "<<genralTracksTEST.size()<<endl;
}

if (VxliteProc /*&& ite->chi2()/ite->ndof() < 5 && ite->chi2()/ite->ndof() > 0.3*/ && Primvertex->size() > 0 )	
{

/// *********************************************************************************
/// check HelixTrans class step by step, 1-5 events; 

/// *************************************
	HelixTrans ExtractClusters(false);
/// *************************************
/// Set the track builder:
/// It is used almost at the each step; Should be initialized!  
	ExtractClusters.SetBuilder(theB);

/// Set magnetic field here:
/// It is used almost at the each step; Should be initialized!  

	ExtractClusters.SetMagneticField(BField);

/// Set Beam Spot Information:	
	Handle<reco::BeamSpot> beamSpotHandle_I;
	iEvent.getByLabel("offlineBeamSpot", beamSpotHandle_I);
	ExtractClusters.SetBeamSpotInformation(beamSpotHandle_I);

/// Set all tracks from the event:
/// It is used for "GetTracksNotFromPVs" function;
	ExtractClusters.SetGeneralTrackCollection(AllgenralTracks);

/// *************************************
/// Set tracks which are from the PVs;
//      ExtractClusters.SetTrackCollectionForAlgorithm(mytracksPV);
// 	and need this after all functions called: mytracksPV.clear();	
// or : 
	vector<TransientTrack> tracksFromPV =  ExtractClusters.GetTracksFromPV(ite);
	ExtractClusters.SetTrackCollectionForAlgorithm(tracksFromPV);


/// CMS part : 

/// works well
/// *************************************
// 	vector <int> TrackIds = ExtractClusters.GetIdTracks(mytracksPV);
// 			//
// 			for(unsigned i=0; i<TrackIds.size();i++)	
// 			{
// 				cout<<"ID = "<<TrackIds[i]<<endl;
// 			}
// 			//
/// *************************************
/// *************************************
// 	vector<TransientTrack> HighPTtracks = ExtractClusters.FindSortedHighPtTracks();
/// *************************************
		ExtractClusters.SetNhighPtTracks(1);
// 	vector<TransientTrack> HighPTtracksSorted = ExtractClusters.FindSortedHighPtTracksSeparated();	
// 			//
// 			for( vector<TransientTrack>::iterator  itt = HighPTtracksSorted.begin(); itt != HighPTtracksSorted.end(); itt++)
//         		{
// 				cout<<"High Pt Track P, Pt = "<<(itt->track()).p()<<"	"<<(itt->track()).pt()<<endl;
// 			}
// 			//
/// *************************************

	ExtractClusters.CreateTrackClusters();
	vector<TransientTrack> *TracksCollectionCluster = ExtractClusters.GetClusterTracks();

	vector <double>	VtxParameters;
	vector <double>	VtxParametersBS;
	vector <double>	VtxParametersZEUS;
	vector <double>	VtxParametersZEUSBS;

	int NgoodClusters = 0;
	int NgoodClustersZEUS = 0;

	for (int j=0; j<ExtractClusters.GetNclusters();j++)	
	{

		
		if (TracksCollectionCluster[j].size() <= 1)	{continue;}

	/// ********************************************************************************************************
	/// ZEUS staff:
		VtxParametersZEUS = ExtractClusters.SimpleFitWithVxlite(TracksCollectionCluster[j], ite, false);
		VtxParametersZEUSBS = ExtractClusters.SimpleFitWithVxlite(TracksCollectionCluster[j], ite, true);

		if (VtxParametersZEUS[9] < 2. /*&& VtxParametersZEUS[9] > 0.5*/)			{

		if (VtxParametersZEUS.size() > 9)	{
		histset[932]->Fill(VtxParametersZEUS[0]*10);						// Fill Cluster DL
		histset[933]->Fill(VtxParametersZEUS[2]);						// Fill Cluster DLsign
		histset[934]->Fill(VtxParametersZEUS[9]);						// Fill Cluster Chi2/ndof
		histset[938]->Fill(VtxParametersZEUS[11]);
		hxhy[300]->Fill(VtxParametersZEUS[11], VtxParametersZEUS[0]*10 );
		hxhy[301]->Fill(VtxParametersZEUS[11], VtxParametersZEUS[2]);

							}

		if (VtxParametersZEUSBS.size() > 9 )	{
		histset[935]->Fill(VtxParametersZEUSBS[0]*10);						// Fill Cluster DL
		histset[936]->Fill(VtxParametersZEUSBS[2]);						// Fill Cluster DLsign
		histset[937]->Fill(VtxParametersZEUSBS[9]);						// Fill Cluster Chi2/ndof
		hxhy[302]->Fill(VtxParametersZEUSBS[11], VtxParametersZEUSBS[0]*10 );
		hxhy[303]->Fill(VtxParametersZEUSBS[11], VtxParametersZEUSBS[2]);
							}
		NgoodClustersZEUS++;

												}
		VtxParametersZEUS.clear();
		VtxParametersZEUSBS.clear();
	/// ********************************************************************************************************
	///  CMS staff:

		VtxParameters = ExtractClusters.SimpleFitWithFitterCMS(TracksCollectionCluster[j], ite, false);
		VtxParametersBS = ExtractClusters.SimpleFitWithFitterCMS(TracksCollectionCluster[j], ite, true);


		histset[901]->Fill(TracksCollectionCluster[j].size());				// Fill Cluster track size

		if (VtxParameters[9] < 2. /*&& VtxParameters[9] > 0.5*/)		{

		if (VtxParameters.size() > 9)	{
		histset[902]->Fill(VtxParameters[0]*10);					// Fill Cluster DL
		histset[903]->Fill(VtxParameters[2]);						// Fill Cluster DLsign
		histset[904]->Fill(VtxParameters[9]);						// Fill Cluster Chi2/ndof
		hxhy[304]->Fill(VtxParametersZEUS[11], VtxParameters[0]*10 );
		hxhy[305]->Fill(VtxParametersZEUS[11], VtxParameters[2]);
						}

		if (VtxParametersBS.size() > 9)	{
		histset[905]->Fill(VtxParametersBS[0]*10);					// Fill Cluster DL
		histset[906]->Fill(VtxParametersBS[2]);						// Fill Cluster DLsign
		histset[907]->Fill(VtxParametersBS[9]);						// Fill Cluster Chi2/ndof
		hxhy[306]->Fill(VtxParametersZEUSBS[11], VtxParametersBS[0]*10 );
		hxhy[307]->Fill(VtxParametersZEUSBS[11], VtxParametersBS[2]);
						}
		NgoodClusters++;	
	
										}

		VtxParameters.clear();
		VtxParametersBS.clear();
	/// ********************************************************************************************************

/// good tools: 
// 		cout<<VtxParameters[2]<<"	"<<VtxParametersBS[2]<<endl;
// 
// 		for(unsigned i=0; i<TracksCollectionCluster[j].size();i++)	
// 		{
// 			cout<<"track hp "<<j<<" has tracks, i = "<<i<<"	"<<(TracksCollectionCluster[j].at(i)).track().pt()<<endl;	 
// 		}
								
													// Fill Number of Clusters per vtx
	}

		if (NgoodClusters != 0)	{ histset[900]->Fill(NgoodClusters); }	
		if (NgoodClustersZEUS != 0) {histset[930]->Fill(NgoodClustersZEUS);}
/// *************************************
// 	vector<double> *vectorDL = ExtractClusters.FitWithFitterCMS(ite);
/// *************************************


/// extrack track by id from the trackCollection: 
// 	int id1 = TrackIds[0];
// 	cout<<(AllgenralTracks.at(id1)).track().pt()<<"	"<<(AllgenralTracks.at(id1)).track().eta()<<"	"<<(AllgenralTracks.at(id1)).track().phi()<<endl;
/// 



/// *********************************************************************************

/// *********************************************************************************


// reco::VertexCollection::const_iterator ite = Primvertex->begin();
/*
HelixTrans ZeusAlgorithm(false);

/// Set the track builder:
/// It is used almost at the each step; Should be initialized!  
	ZeusAlgorithm.SetBuilder(theB);

/// Set magnetic field here:
/// It is used almost at the each step; Should be initialized!  
	ESHandle<MagneticField> BField;
	iSetup.get<IdealMagneticFieldRecord>().get(BField);
	ZeusAlgorithm.SetMagneticField(BField);

/// Set Beam Spot Information:	
	Handle<reco::BeamSpot> beamSpotHandle_I;
	iEvent.getByLabel("offlineBeamSpot", beamSpotHandle_I);
	ZeusAlgorithm.SetBeamSpotInformation(beamSpotHandle_I);

/// Set all tracks from the event:
/// It is used for "GetTracksNotFromPVs" function;
	ZeusAlgorithm.SetGeneralTrackCollection(genralTracksTEST);


// 	cout<<"Outside:  PVposX = "<<ite->x()<<"   PVposY = "<<ite->y()<<endl;
 	vector<TransientTrack> tracksFromPV =  ZeusAlgorithm.GetTracksFromPV(ite);
// 	if (output)	{cout<<"Primary Vtx size = "<<mytracks.size()<<endl;}
/// Set tracks which are not from the PVs;
//	ZeusAlgorithm.SetTrackCollectionFromPV(mytracks);
        ZeusAlgorithm.SetTrackCollectionForAlgorithm(tracksFromPV);



/// with CMS fitter: 
	vector<double> *vectorDL = ZeusAlgorithm.FitWithFitterCMS(ite);

// 	cout<<vectorDL[0].size()<<endl;

	if (vectorDL[0].size() > 0)	{
	for(unsigned i=0; i<vectorDL[0].size();i++)	
		{
// 		cout<<vectorDL[0][i]<<endl;
	  
// 		cout<<"DL out  "<<vectorDL[0][i]<<"  DLsign out = "<<vectorDL[0][i]/vectorDL[1][i]<<endl;
		histset[900]->Fill(vectorDL[0][i]);
		histset[902]->Fill(vectorDL[0][i]/vectorDL[1][i]);
		
	if (vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8)	{ histset[904]->Fill(vectorDL[0][i]/vectorDL[1][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[905]->Fill(vectorDL[0][i]/vectorDL[1][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[906]->Fill(vectorDL[0][i]/vectorDL[1][i]);}

	if (vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8)	{ histset[910]->Fill(vectorDL[0][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[911]->Fill(vectorDL[0][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[912]->Fill(vectorDL[0][i]);}
		
// 		histset[903]->Fill(vectorDL[2][i]);
	
		}
					}
*/
/*
/// Work with ZEUS fitter: 
/// This method include tracks not prom PVs. It find track clusters from; 
/// Make a fit of the cluster and extract XYZ vertex position; 
/// Calculate DL;

	vector<double> *vectorDL = ZeusAlgorithm.MakeAFitwithVxlite(ite);
	for(unsigned i=0; i<vectorDL[0].size();i++)	{
// 		cout<<vectorDL[0][i]<<endl;
		histset[900]->Fill(vectorDL[0][i]);
		histset[902]->Fill(vectorDL[0][i]/vectorDL[1][i]);
		
	if (vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8 )	{ histset[904]->Fill(vectorDL[0][i]/vectorDL[1][i]);}
	if (vectorDL[2][i] > 2)	{ histset[905]->Fill(vectorDL[0][i]/vectorDL[1][i]);}
	if (vectorDL[2][i] > 2 && vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8)	{ histset[906]->Fill(vectorDL[0][i]/vectorDL[1][i]);}

	if (vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8 )	{ histset[910]->Fill(vectorDL[0][i]);}
	if (vectorDL[2][i] > 2)	{ histset[911]->Fill(vectorDL[0][i]);}
	if (vectorDL[2][i] > 2 && vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8)	{ histset[912]->Fill(vectorDL[0][i]);}
		
		histset[903]->Fill(vectorDL[2][i]);
	
		}
*/

// 	cout<<DLvalues[0]<<"	"<<DLvalues[1]<<endl;
	

} // VxliteProc bool

// } // event ID








/*
	vector<double> vectorDL = ZeusAlgorithm.ExtractDLCov(ite);
	cout<<"Vector DL size = "<<vectorDL.size()<<endl;
	for(unsigned i=0; i<vectorDL.size();i++)	{
		histset[900]->Fill(vectorDL[i]);
		if (vectorDL[i]<0)	{histset[901]->Fill(vectorDL[i]);}
							}

*/
/// extract tracks which are not from the PVs:
// 	Handle<reco::VertexCollection> PrimvertexTmp;
// 	iEvent.getByLabel("offlinePrimaryVerticesWithBS", PrimvertexTmp);
// 	ZeusAlgorithm.SetPVcollection(PrimvertexTmp);


/// Internal functions, may be useful;
// 	vector<TransientTrack> myTmp = ZeusAlgorithm.FindSortedHighPtTracksIsolated();
// 	ZeusAlgorithm.CreateTrackClusters();
// 	ZeusAlgorithm.TrackSortPrintResults();
// 	ZeusAlgorithm.SetTrackCollectionToFit(mytracks);		/// if you want to run vertex Fit without algorithm 


// 	ZeusAlgorithm.ExtractDL();




} // end of vertex collection loop


}	/// end for Primvertex.size > 0 check;

// 	cout<<"Event end here *************************************************"<<endl;

  histset[8]->Fill(size); //only valid vertices get stored.
 






    /// ------------------------------------------------------------------------------------------------------------------------ ///
    ///                             VERTEX STUDY                                                                           ///
    /// ****************************************************************************************************************** ///
/*    
    /// Find PV:
    
    //if( tracks.size() - mytracksPV.size()>1 )
    //{
    //PrimaryVertexProducerAlgorithm finderSV;      /// does not work well
    //KalmanTrimmedVertexFinder finderSV;           /// does not work well
    
    AdaptiveVertexReconstructor finderPV;
    vector<TransientVertex> PVvertices = finderPV.vertices(mytracksPV, vertexBeamSpot );
    
    for(vector<TransientVertex>::iterator ipv = PVvertices.begin(); ipv != PVvertices.end(); ++ipv)
    {
        //if ( isv->isValid() ) {histset[400]->Fill( isv->normalisedChiSquared() );}
        //histset[401]->Fill( isv->normalisedChiSquared() );
        if (ipv->normalisedChiSquared() < 2. && ipv->normalisedChiSquared() > 0.3)      {
            
            cout<<" N tracks per PV = "<<(ipv->originalTracks()).size()<<"  XYZ pos = "<<(ipv->position()).x()<<"   "<<(ipv->position()).y()<<"     "<<(ipv->position()).z()<<"     ";
            cout<<" Chi2/ndof = "<< ipv->normalisedChiSquared()<<endl;
        }
    }
    //} else { cout << "not enough tracks left for SV reconstruction" <<std::endl; }
    
    /// ****************************************************************************************************************** ///
    
    /// ****************************************************************************************************************** ///
    /// Check if there is an access to TransientTracks via TransientVertex vector:
    /// This is just an example how to access Transient Track Collection inside of the Transient Vertex Collection:
    
    vector<TransientTrack> mytracks_tst;
    for(vector<TransientVertex>::iterator ipvtst = PVvertices.begin(); ipvtst != PVvertices.end(); ++ipvtst)
    {
        if (ipvtst->normalisedChiSquared() < 2. && ipvtst->normalisedChiSquared() > 0.3) {} else  { continue; }
        mytracks_tst = ipvtst->originalTracks();
        for(vector<TransientTrack>::iterator trk_tst = mytracks_tst.begin(); trk_tst != mytracks_tst.end(); ++trk_tst)
        {
            
            cout<<"TEST Transient Track P() = "<<(trk_tst->track()).p()<<endl;
            
        }
        
    }
*/
    
    /// ****************************************************************************************************************** ///
    
    

   //------------------analysing global muons with the track collection-------------------------//
/// DEFINE GLOBAL jpsi VARS HERE: 
vector <double> VectBplus[20];

   histset[4]->Fill(gmuons->size());
   

  //cout<<"Evnet ID = "<<iEvent.id().event()<<endl;
  



  for( reco::TrackCollection::const_iterator it= gmuons->begin(); it !=gmuons->end(); it++) {
   
   histset[1]->Fill(it->p());
   histset[2]->Fill(it->pt());
   histset[3]->Fill(it->eta());
   histset[53]->Fill(it->chi2());
   histset[54]->Fill(it->ndof());
   histset[55]->Fill(it->normalizedChi2());
   histset[83]->Fill(it->phi());
 // LogInfo("Demo")  <<"global  muon track pointer "<<it;
   // LogInfo("Demo")<<"global muon track p"<<it->p()<<"  global muon track pos"<<it->referencePoint()<<" global muon track vertex"<<it->vertex();

       //-----------------now prepare quality cuts---------------------//
   
   int size1=0;
   int ValidHits=0, PixelHits=0;
       const reco::HitPattern& p = it->hitPattern();
      
       // loop over the hits of the track
       for (int i=0; i<p.numberOfHits(); i++) {
	 uint32_t hit = p.getHitPattern(i);
	 
	 // if the hit is valid and in pixel 
	 if (p.validHitFilter(hit) && p.pixelHitFilter(hit)) PixelHits++;
	 
	 if (p.validHitFilter(hit))ValidHits++;
	 
       }
       if(ValidHits>=10 && PixelHits>=1) size1++; // For Mu sample
	 
	   
       if(size1)histset[59]->Fill(size1);// Fill hitsOK histo
       histset[60]->Fill(ValidHits);
       histset[61]->Fill(PixelHits);

      
       // loop over muons satisfying quality cuts //
       // as applied for plots used in presentation at CMS physics meetring //

       if(gmuons->size()>=2 && ValidHits>=12 && PixelHits>=2 && it->normalizedChi2()<4.0)
	 //       if(gmuons->size()>=2)
     {

       reco::TrackCollection::const_iterator i=it;
       i++;
       for(;i!=gmuons->end();i++){
	 
	 int ValidHits1=0, PixelHits1=0;
	 const reco::HitPattern& p1 = i->hitPattern();
	
       // loop over the hits of the track
	 for (int n=0; n<p1.numberOfHits(); n++) {
	 uint32_t hit = p1.getHitPattern(n);

	 // if the hit is valid and in pixel 
	 if (p1.validHitFilter(hit) && p1.pixelHitFilter(hit)) PixelHits1++;
	 
	 if (p1.validHitFilter(hit))ValidHits1++;
	 
	 }
	 

	 if(it->charge()==-(i->charge())) // unlike charges
	 {
	   //----------to calculate invariant mass-----------------//

	   s1=sqrt(((it->p())*(it->p())+sqm1)*((i->p())*(i->p())+sqm1));
	   s2=it->px()*i->px()+it->py()*i->py()+it->pz()*i->pz();
	   s=sqrt(2.0*(sqm1+(s1-s2)));
	   histset[5]->Fill(s);
	   histset[44]->Fill(s);
	   histset[80]->Fill(s);
	   // apply weight 200/(ln10*m/GeV) to convert to events/GeV (see sheet)
	   w=200/log(10)/s;
	   histset[100]->Fill(log10(s),w);
	    
           // scorr needs to be fixed ... use average pseudorapidity for approximate correction, should use rapidity

	   scorr=(1.0+0.00038+0.0003*(i->eta()+it->eta())*(i->eta()+it->eta())/4)*s;
		  histset[66]->Fill(scorr);
		  histset[67]->Fill(scorr);

	   //----------to calculate rapidity---------------------//

	     s3=(it->p())*(it->p())+(i->p())*(i->p());
		  s4= sqrt(s3+2*s2+s*s);
		  pz=it->pz()+i->pz();
		  rap=0.5*log((s4+pz)/(s4-pz));
		  if(fabs(rap)<1.2) {histset[47]->Fill(s);histset[68]->Fill(scorr);}
		  else if(fabs(rap)<1.6){ histset[48]->Fill(s);histset[69]->Fill(scorr);}
		  else if(fabs(rap)<2.4){ histset[49]->Fill(s);histset[70]->Fill(scorr);}

		   //--------------------------upsilon ranges ----------------------------------------------------------//
		  
		  if(fabs(it->eta())<2.4 && fabs(i->eta())<2.4){ histset[77]->Fill(s);histset[79]->Fill(scorr);}
		  if(fabs(it->eta())<1. && fabs(i->eta())<1.) {  histset[76]->Fill(s);histset[78]->Fill(scorr);}
	 }

	 if(it->charge()==(i->charge()))   // like charges invariant mass
	 {
	   s1=sqrt(((it->p())*(it->p())+sqm1)*((i->p())*(i->p())+sqm1));
	   s2=it->px()*i->px()+it->py()*i->py()+it->pz()*i->pz();
	   s=sqrt(2.0*(sqm1+(s1-s2)));
	   histset[46]->Fill(s);
	   w=200/log(10)/s;
	   histset[102]->Fill(log10(s),w);
	  
	 }


       }//end of for(;i!=gmuons....)

     }//end of if(gmuons>=2.....)
  }//end of reco ::TrackCollection
  


  //--------------------------analysing muons with MuonCollection----------------------------------------//
  //                          for J/psi (BPH-10-002) and Z (EWK-10-002)                                  //
 
 
    histset[33]->Fill(muons->size()); // only the total number of muons




/// Variable declaration for J/Psi DL study: 

// double LXY = 0.;
// double x0 = 0.;
// double y0 = 0.;
// double z0 = 0.;
// double LXYx = 0.;
// double LXYy = 0.;
double JPsiPx = 0.;
double JPsiPy = 0.;
double JPsiPz = 0.;

double JPsiP = 0.; 
double JPsiPt = 0.;
double JPsiE = 0.; 
double JPsiRap = 0.;

// double PJpsi = 0.;
// double PtoverP = 0.;
// double EJpsi = 0.;
// double Et = 0.;
// double mJpsiPDG = 3.096916;  // GeV/c^2;
double LXYcorr = 0.;
// double JpsiP[4] = {0.}; 

// vars for the DL calculation with Covariance Matrix
// double McovX[3]= {0.};
// double McovY[3]= {0.};
// double McovZ[3]= {0.};
// double **MatrixCov = new double *[3];
// double detA = 0.;
// double McovX_wrap[2] = {0.};
// double McovY_wrap[2] = {0.};
// double T1[2] = {0.};
// double dL1 = 0.;
// double T2[2] = {0.};
// double dL2 = 0.;
// double dLxy = 0.;
// double Jpsi_PT = 0.;
// double dLxy_corr = 0.;


// int JPsiVtxCounter = 0;
// int JPsiVtxCounter2 = 0;
// bool JPsiVtxFound = false;
// bool JPsiVtxFound2 = false;


double BplusM = 0.;
int ValidHitsK = 0;
int PixelHitsK = 0;
double BplusPt = 0.;
double BplusPx = 0.; 
double BplusPy = 0.; 
double BplusPz = 0.; 
double BplusE = 0; 
double BplusRap = 0.; 
double BplusP = 0.;
// double BplusLx = 0.; 
// double BplusLy = 0.; 
double DLxyBplus = 0.;
double DLxyBplusCt = 0.;
int counterBplus = 0.;
int counterJPsi = 0.;

vector<reco::TransientTrack> genralTracks_forBplus = (*theB).build(tracks);


vector <double> AllFitPars;
vector <double> AllFitParsBS;
vector <double> AllFitParsZEUS;
vector <double> AllFitParsZEUSBS;
vector <double> AllFitPars2;
vector <double> AllFitPars2BS;
 
AdaptiveVertexFitter  theFitter;
AdaptiveVertexFitter  theFitterBplus;



vector<reco::TransientTrack> genralMTracks = (*theB).build(gmuons);             /// create new transient track collection form Global Muons collection.  

if (JpsiProduction)
{

for (MuonCollection::const_iterator itMuon = muons->begin(); itMuon != muons->end(); ++itMuon) {

    // double Mt;
    int  ValidHits=0; int PixelHits=0;//TM_J/Psi
    int  GM_ValidHits=0; int GM_PixelHits=0;//GM_Z
    int size2=0;
    int   jpsi_flag1=0;
    int   jpsi_flag2=0;

    // int Zflag1=0;
    // int Zflag2=0;

    // int Wflag1=0;
    // int Wflag2=1;
    int goodhit=0;//GM_Z Muon Chamber hits
    double relIso=1.;// relative Isolation for muons(Z paper);
 
    vector<TransientTrack> mytracksforJPSI;
    vector<TransientTrack> mytracksforBplus;	    
    vector<TransientTrack> mytrackKaon;


 // int Yflag=0;

 math::XYZPoint point(beamSpot.position());

  // LogInfo("Demo")  <<" muon p "<<itMuon->momentum()<<" p "<<itMuon->p()<<" pt "<<itMuon->pt();
  // LogInfo("Demo") <<" global "<<itMuon->isGlobalMuon()<<" tracker "<<itMuon->isTrackerMuon();

  histset[29]->Fill(itMuon->p());histset[30]->Fill(itMuon->pt());histset[31]->Fill(itMuon->eta());  histset[84]->Fill(itMuon->phi());
  
 
  if((itMuon->track()).isNonnull()){// some muons might not have valid track references

      histset[56]->Fill(((itMuon->track()))->chi2());
      histset[57]->Fill(((itMuon->track()))->ndof());
      histset[58]->Fill(((itMuon->track()))->normalizedChi2());
    
// LogInfo("Demo")  <<" muon track p "<<(itMuon->track())->p()<<"  muon track position"<<(itMuon->track())->referencePoint()<<"  Muon Vertex Position"<<itMuon->vertex();


	  //-----------------------------------------------------------------//
       //-----------------now putting the cuts for j/psi---------------------//
	  //--------------------------------------------------------------//

	  const reco::HitPattern& p = (itMuon->track())->hitPattern();
	  

       // loop over the hits of the track
       for (int i=0; i<p.numberOfHits(); i++) {
	 uint32_t hit = p.getHitPattern(i);
	  
	
	 // if the hit is valid and in pixel
	 if (p.validHitFilter(hit) && p.pixelHitFilter(hit)){
	   PixelHits++;
           }
	 if (p.validHitFilter(hit)){
	   ValidHits++;
	 }
       }
       if(ValidHits>=12 && PixelHits>=2){
	 size2++; }
       histset[63]->Fill(ValidHits);
       histset[64]->Fill(PixelHits);
       if(size2)histset[62]->Fill(size2);// Fill hitsOK histo


	if (ValidHits>=12 && PixelHits>=2 && (itMuon->track())->normalizedChi2()<4.0 && muon::isGoodMuon(*itMuon,muon::TMLastStationAngTight) && muon::isGoodMuon(*itMuon,muon::TrackerMuonArbitrated) && itMuon->isTrackerMuon())
   {
     if(fabs(itMuon->eta())<1.3 && itMuon->pt()>3.3)jpsi_flag1=1;
     else if(fabs(itMuon->eta())>1.3 && fabs(itMuon->eta())<2.2 && itMuon->p()>2.9)jpsi_flag1=1;
     else if(fabs(itMuon->eta())>2.2  && fabs(itMuon->eta())<2.4 && itMuon->pt()>0.8)jpsi_flag1=1;
   }
 

		//--------------------------------------------------------------------------------//
		//----------------------------Z & W cuts----------------------------------------------//
		//--------------------------------------------------------------------------------//

       if(itMuon->isGlobalMuon() && (itMuon->globalTrack()).isNonnull())
	 {
	   //relative isolation
	  relIso=((itMuon->isolationR03()).sumPt+(itMuon->isolationR03()).emEt+(itMuon->isolationR03()).hadEt)/itMuon->pt();



	  // checking hit pattern info
	  const reco::HitPattern& GM_p = (itMuon->globalTrack())->hitPattern();
	  goodhit=GM_p.numberOfValidMuonHits();
	  for (int i=0; i<GM_p.numberOfHits(); i++) {
	  uint32_t hit = GM_p.getHitPattern(i); 
	 // if the hit is valid and in pixel
	 if (GM_p.validHitFilter(hit) && GM_p.pixelHitFilter(hit)){
	   GM_PixelHits++;
           }
	 if (GM_p.validHitFilter(hit)){
	   GM_ValidHits++; 
	  }
	  }// for (int i=0; i<GM_p.numberOfHits(); i++) ends
           histset[92]->Fill(goodhit);


	   bool result= muon::isGoodMuon(*itMuon, muon::TMLastStationTight);
           histset[93]->Fill(result);
	   histset[91]->Fill((itMuon->globalTrack())->dxy(point)); // Transverse impact parameter w.r.t. BeamSpot


	   if(GM_ValidHits>=10 && GM_PixelHits>=1 && goodhit>=1 && (itMuon->globalTrack())->normalizedChi2()<10.0 && fabs((itMuon->globalTrack())->dxy(point))<0.2 && result && relIso<0.15)
	     {
	       if(itMuon->pt()>20 && fabs(itMuon->eta())<2.1)
		 {
	//	   Zflag1=1;
	//	   Wflag1=1;
		 }
	      
	     }
	 }//if(itMuon->isGlobalMuon()..........) ends

      }//isNonnull() ends
 
     

 
  //--------------------------look for dimuons----------------------------------------------------------------------------//
  //------------------------------------------------------------------------------------------------------//
  if(muons->size()>=2)
    {
      
      if(itMuon->isTrackerMuon())
	{
	  //---------------only for tracker muons--------------//
          //   fill for first muon of multimuon candidate      //
          //   *** logic to be reconsidered ***  //        

  histset[50]->Fill(((itMuon->track()))->chi2());
  histset[51]->Fill(((itMuon->track()))->ndof());
  histset[52]->Fill(((itMuon->track()))->normalizedChi2());
	}

  //----------------------------------2nd tracker muon loop ---------------------------------------------//

//-------------------------------------------------------------------//
	  MuonCollection::const_iterator itM=itMuon;
	  itM++;

	  for(;itM!=muons->end();itM++)
	    {
	     jpsi_flag2=0;
	     // Zflag2=0;
	     // Wflag2=1;// to reject events with 2 muons
	     int goodhit1=0;//GM_Z Muon Chamber hits
	     double relIso1=1.0;// relative Isolation for muons(Z paper);
	      if((itM->track()).isNonnull() && (itMuon->track()).isNonnull()){ 
		
 
		histset[88]->Fill(fabs((itMuon->track())->vx()-(itM->track())->vx()));// for j_psi
		histset[89]->Fill(fabs((itMuon->track())->vy()-(itM->track())->vy()));//for j_psi
		histset[90]->Fill(fabs((itMuon->track())->vz()-(itM->track())->vz()));//for_j/psi
		int ValidHits1=0, PixelHits1=0;
		int GM_ValidHits1=0, GM_PixelHits1=0;
		double dx,dy,dz;
		dx=(itMuon->track())->vx()-(itM->track())->vx();// for j_psi
		dy=(itMuon->track())->vy()-(itM->track())->vy();// for j_psi
		dz=(itMuon->track())->vz()-(itM->track())->vz();// for j_psi
    
        //Upisilon Varriables
            double dref[3]={abs((itMuon->track())->vx()-(itM->track())->vx()),abs((itMuon->track())->vy()-(itM->track())->vy()),abs((itMuon->track())->vz()-(itM->track())->vz())};
              double d1[3]={abs((itMuon->track())->vx()),abs((itMuon->track())->vy()),abs((itMuon->track())->vz())};
              double d2[3]={abs((itM->track())->vx()),abs((itM->track())->vy()),abs((itM->track())->vz())};
              
		const reco::HitPattern& p1 = (itM->track())->hitPattern();
	 
		// loop over the hits of the track
		for (int n=0; n<p1.numberOfHits(); n++) {
		  uint32_t hit = p1.getHitPattern(n);

		  // if the hit is valid and in pixel 
            if (p1.validHitFilter(hit) && p1.pixelHitFilter(hit)) PixelHits1++;
            if (p1.validHitFilter(hit))ValidHits1++;
		  
		}


		// for W 
        
		if(itM->isGlobalMuon() &&(itM->globalTrack()).isNonnull()){
		  // SL6
		  //if(itM->pt()>10.0) Wflag2=0;// to reject events for W mass


		  //for  Z
		  relIso1=((itM->isolationR03()).sumPt+(itM->isolationR03()).emEt+(itM->isolationR03()).hadEt)/itM->pt();
		  bool result1= muon::isGoodMuon(*itMuon, muon::TMLastStationTight);
		  const reco::HitPattern& GM_p1 = (itM->globalTrack())->hitPattern();
		  goodhit1=GM_p1.numberOfValidMuonHits();
		  for (int n=0; n<GM_p1.numberOfHits(); n++) {
		    uint32_t hit = GM_p1.getHitPattern(n);
		     
		    // if the hit is valid and in pixel 
		    if (GM_p1.validHitFilter(hit) && GM_p1.pixelHitFilter(hit)) GM_PixelHits1++;
	 
		    if (GM_p1.validHitFilter(hit))GM_ValidHits1++;
	 
		  }


		  if( GM_ValidHits1>=10 && GM_PixelHits1>=1 && goodhit1>=1 && (itM->globalTrack())->normalizedChi2()<10.0 && fabs((itM->globalTrack())->dxy(point))<0.2 && result1 && relIso1<0.15)
		    {
			// SL6
		      	//if(itM->pt()>20 && fabs(itM->eta())<2.1) Zflag2=1;
		      
		    }


		}// if(itM->isGlobalMuon().....) ends





     // for j_psi
       if (ValidHits1>=12 && PixelHits1>=2 && (itM->track())->normalizedChi2()<4.0&& (itMuon->track())->normalizedChi2()<4.0 && dx<=0.1 && dy<=0.1 && dz<=0.3 && muon::isGoodMuon(*itM,muon::TMLastStationAngTight) && muon::isGoodMuon(*itM,muon::TrackerMuonArbitrated) && itM->isTrackerMuon())
	 {
	    if(fabs(itM->eta())<1.3 && itM->pt()>3.3)jpsi_flag2=1;
	    else if(fabs(itM->eta())>1.3 && fabs(itM->eta())<2.2 && itM->p()>2.9)jpsi_flag2=1;
	    else if(fabs(itM->eta())>2.2 && fabs(itM->eta())<2.4 && itM->pt()>0.8)jpsi_flag2=1;
	 }
       
    //Cuts for Upsilon [arXiv 1012.5545 §3.3]
              if (ValidHits1>=12 && PixelHits1>=1 && (itM->track())->normalizedChi2()<5 && (itMuon->track())->normalizedChi2()<5 && sqrt(d1[0]*d1[0] + d1[1]*d1[1])<=0.2 && d1[2]<=25 && sqrt(d2[0]*d2[0] + d2[1]*d2[1])<=0.2 && d2[2]<=25 && dref[2]<2  && itM->isTrackerMuon() && itMuon->isTrackerMuon() && muon::isGoodMuon(*itM,muon::TMOneStationTight) && muon::isGoodMuon(*itMuon,muon::TMOneStationTight) ){
        
		// SL6
                  //if ( ( (abs (itM->eta()) < 1.6 && itM->pt()>3.5) || ( abs(abs(itM->eta())-2) < 0.4 && itM->pt()>2.5 ) ) && ( (abs (itMuon->eta()) < 1.6 && itMuon->pt()>3.5) || ( abs(abs(itMuon->eta())-2) < 0.4 && itMuon->pt()>2.5 ) ) ) Yflag=1;
              
              }//if valid hits ends
              
	      }//isNonnull() ends
       if(itM->charge()==-itMuon->charge() )// unlike charges
		{
		  

if (JPsiDL)	{
/// NEW (from Nazar Stefaniuk): 
/// Find the accordance btw tracks and MuonCollection. 
/// Have found very accurate method to check accordance btw Muons and Global Muons which are also from TrackCollection and fit to transient procedure.       

if(jpsi_flag2==1 && jpsi_flag1==1)      /// defined above, find proper Muon candidantes  
{


	mytracksforJPSI.clear();
        /// loop over the transient tracks and finding the accordance with the Muon collection;
        for( vector<TransientTrack>::iterator gm_trans = genralTracks_forBplus.begin(); gm_trans !=genralTracks_forBplus.end(); gm_trans++)
        {

                        const reco::TrackRef trackRefabc = (gm_trans->trackBaseRef()).castTo<reco::TrackRef>();

				if ( fabs(itM->p() - (gm_trans->track()).p()) < 1e-5 && fabs(itM->px() - (gm_trans->track()).px()) < 1e-5)	
				{
                                        TransientTrack  transientTrack1 = theB->build(trackRefabc);
                                        mytracksforJPSI.push_back(transientTrack1);
                                }

				if ( fabs(itMuon->p() - (gm_trans->track()).p()) < 1e-5 && fabs(itMuon->px() - (gm_trans->track()).px()) < 1e-5)	
				{
                                        TransientTrack  transientTrack2 = theB->build(trackRefabc);
                                        mytracksforJPSI.push_back(transientTrack2);
					//cout<<"Vtx x = "<<(itMuon->vertex()).x()<<"	"<<transientTrack2.track().vertex().x()<<endl;
                                }

        }


	histset[308]->Fill(mytracksforJPSI.size());	

//// ***********************
	HelixTrans JPsiReconstruction(false);
		/// Set Beam Spot Information:	
	Handle<reco::BeamSpot> beamSpotHandle_I;
	iEvent.getByLabel("offlineBeamSpot", beamSpotHandle_I);
	JPsiReconstruction.SetBeamSpotInformation(beamSpotHandle_I);

		/// Set magnetic field here:
		/// It is used almost at the each step; Should be initialized!  
	ESHandle<MagneticField> BField;
	iSetup.get<IdealMagneticFieldRecord>().get(BField);
	JPsiReconstruction.SetMagneticField(BField);



	reco::VertexCollection::const_iterator JpsiVtxIte;

	if ( mytracksforJPSI.size() > 1 )	{

		JPsiReconstruction.FindPVfor2Tracks(Primvertex->begin(), Primvertex->end(), mytracksforJPSI);

		// cout<<" Vertex # "<<JPsiReconstruction.FindPVfor2TracksGetNvertex()<<"  has tracks : "<<JPsiReconstruction.FindPVfor2TracksGetNvertexTracks()<<endl;

		// cout<<"Track parameters here: "<<endl;
		// cout<<"Track 1 : "<<(mytracksforJPSI[0].track()).px()<<"	"<<(mytracksforJPSI[0].track()).py()<<"	"<<(mytracksforJPSI[0].track()).pz()<<endl;
		// cout<<"Track 2 : "<<(mytracksforJPSI[1].track()).px()<<"        "<<(mytracksforJPSI[1].track()).py()<<" "<<(mytracksforJPSI[1].track()).pz()<<endl;	

		if (JPsiReconstruction.FindPVfor2TracksGetNvertexTracks() != 0 ) 
		{
			JpsiVtxIte = JPsiReconstruction.FindPVfor2TracksGetVertexIte();
			// cout<<"FF: "<<JpsiVtxIte->x()<<"	"<<JpsiVtxIte->y()<<"	"<<JpsiVtxIte->z()<<endl;
			// cout<<"Vertex data valid? "<<JpsiVtxIte->isValid()<<endl;	


		/// Set track Builder here: 
		JPsiReconstruction.SetBuilder(theB);
		AllFitPars.clear(); AllFitParsBS.clear();

		AllFitPars = JPsiReconstruction.SimpleFitWithFitterCMS(mytracksforJPSI, JpsiVtxIte, false);
// 		cout<<"DL, err, Sign : "<<AllFitPars[0]<<"	"<<AllFitPars[1]<<"	"<<AllFitPars[2]<<endl;
		AllFitParsBS = JPsiReconstruction.SimpleFitWithFitterCMS(mytracksforJPSI, JpsiVtxIte, true);
// 		cout<<"DL, err, Sign BS : "<<AllFitParsBS[0]<<"	"<<AllFitParsBS[1]<<"	"<<AllFitParsBS[2]<<endl;		

		AllFitParsZEUS = JPsiReconstruction.SimpleFitWithVxlite(mytracksforJPSI, JpsiVtxIte, false);

		/// Fill histos: 
		histset[309]->Fill(mytracksforJPSI.size());
		if (AllFitPars.size()>10 && JpsiVtxIte->isValid())	// vertex valid: if not size of par vector is 1 with false entry;
		{ 
			

			histset[307]->Fill(mytracksforJPSI.size());  
	        //        histset[313]->Fill(cosJPSI_dL);
        	//        histset[310]->Fill((myVertex.originalTracks()).size());
	                histset[311]->Fill(AllFitPars[9]);
                	histset[312]->Fill(AllFitPars[0]*10);                                     /// Fill decay length histogram with LXY im mm. 
			histset[342]->Fill(AllFitParsBS[0]*10);
			
			M=invMass(itM->p(), itM->px(), itM->py(), itM->pz(), mumass, itMuon->p(), itMuon->px(), itMuon->py(), itMuon->pz(), mumass);	

			JPsiPx = 0.; JPsiPy = 0.; JPsiPz = 0.; JPsiP = 0.; JPsiPt = 0.;
 
			JPsiPx  = itM->px() + itMuon->px();
			JPsiPy  = itM->py() + itMuon->py();
			JPsiPz  = itM->pz() + itMuon->pz(); 
			JPsiP   = sqrt(JPsiPx*JPsiPx + JPsiPy*JPsiPy + JPsiPz*JPsiPz); 	
			JPsiPt  = sqrt(JPsiPx*JPsiPx + JPsiPy*JPsiPy);
		

	                // checks : identical with rap       
			JPsiE = 0.; JPsiRap = 0.; 
                   	JPsiE = sqrt(M*M + JPsiP*JPsiP );
                   	JPsiRap = 0.5*log((JPsiE + JPsiPz)/(JPsiE - JPsiPz)); 

// 			cout<<"JPsi rap new = "<<JPsiRap<<endl;

			histset[343]->Fill(10*AllFitParsBS[0]*M/JPsiPt);
			
			LXYcorr = (AllFitPars[0]*M)/JPsiPt;
		
			histset[314]->Fill(LXYcorr*10);
			/// calculated with cov Ms
		        histset[315]->Fill(AllFitPars[0]*10);
		        histset[316]->Fill(LXYcorr*10);	

			histset[333]->Fill(AllFitPars[2]);
			histset[349]->Fill(AllFitParsBS[2]);  

	                if (M > 2.6 && M < 3.5 )        
			{
                        histset[329]->Fill(LXYcorr*10);                 /// fill DL in mm       
                        histset[327]->Fill(M);                          /// fill mass
			histset[334]->Fill(AllFitPars[2]);
			histset[346]->Fill(AllFitParsBS[2]);

// 			cout<<"Standart mass = "<<M<<"  and from Vtx = "<<AllFitParsZEUS[11]<<endl;	
			
			/// fill histos for 3 eta bins; 
			if ( fabs(JPsiRap) <= 1.2 ) 				{ histset[339]->Fill(M); }
			if ( fabs(JPsiRap) > 1.2 && fabs(JPsiRap)<=1.6) 	{ histset[340]->Fill(M); }
			if ( fabs(JPsiRap) > 1.6 && fabs(JPsiRap)<=2.4) 	{ histset[341]->Fill(M); }


// 			cout<<"JPsi mass = "<<M<<endl;
	                                                
                	/// to bins of rapidity
                	if (fabs(JPsiRap) < 1.6 && fabs(JPsiRap) > 1.2 && JPsiPt > 2.  && JPsiPt < 4.5 )  
				{histset[319]->Fill(AllFitPars[0]*10); histset[317]->Fill(LXYcorr*10); histset[335]->Fill(AllFitPars[2]); histset[337]->Fill(M); 
				      histset[344]->Fill(AllFitParsBS[0]*10); histset[347]->Fill(AllFitParsBS[2]);}

                	if (fabs(JPsiRap) < 2.4 && fabs(JPsiRap) > 1.6 && JPsiPt > 6.5 && JPsiPt < 10. )  
				{histset[320]->Fill(AllFitPars[0]*10); histset[318]->Fill(LXYcorr*10); histset[336]->Fill(AllFitPars[2]); histset[338]->Fill(M);
				      histset[345]->Fill(AllFitParsBS[0]*10); histset[348]->Fill(AllFitParsBS[2]);
				}

			/// should be calculated via cov matrices here: (will do this in future, at the moment - same)
			histset[330]->Fill(AllFitPars[0]*10);
			histset[331]->Fill(LXYcorr*10);
                        if (fabs(JPsiRap) < 1.6 && fabs(JPsiRap) > 1.2 && JPsiPt > 2.  && JPsiPt < 4.5 )  {histset[321]->Fill(AllFitPars[0]*10); histset[323]->Fill(LXYcorr*10); }
                        if (fabs(JPsiRap) < 2.4 && fabs(JPsiRap) > 1.6 && JPsiPt > 6.5 && JPsiPt < 10. )  {histset[322]->Fill(AllFitPars[0]*10); histset[324]->Fill(LXYcorr*10); }
			
			if (LXYcorr*10 > 0.2) {histset[332]->Fill(M);}

			counterJPsi++;
			}
			
                	histset[325]->Fill(JPsiPt);
                	histset[326]->Fill(JPsiRap);
                	histset[328]->Fill(M);

          	// new part , B+

		mytracksforBplus.clear(); mytracksforBplus = mytracksforJPSI;

                for( reco::TrackCollection::const_iterator itK = tracks->begin(); itK !=tracks->end(); itK++)
                {	
			BplusM = 0.; PixelHitsK = 0; ValidHitsK = 0; BplusPt = 0.;	 

			if (&*itK != (itM->globalTrack()).get()  &&  &*itK != (itMuon->globalTrack()).get() )	
			{

			//		const reco::TrackRef trackRefabc = (itK->trackBaseRef()).castTo<reco::TrackRef>();
			//		if (&*itK == (itM->globalTrack()).get()  ||  &*itK == (itMuon->globalTrack()).get() ) {cout<<"Here problem"<<endl;}
			//		cout<<&*itK<<"	"<<(itM->globalTrack()).get()<<"	"<<(itMuon->globalTrack()).get()<<endl;

			if (itK->pt() > 0.9 && itK->normalizedChi2() < 5 /*&& itK->charge() == 1*/)	
			{

				const reco::HitPattern& Kpat = itK->hitPattern();

       					// loop over the hits of the track
			   	for (int i=0; i<Kpat.numberOfHits(); i++) 
				{
         				uint32_t hitK = Kpat.getHitPattern(i);

		         		// if the hit is valid and in pixel 
	         			if (Kpat.validHitFilter(hitK) && Kpat.pixelHitFilter(hitK)) PixelHitsK++;

         				if (Kpat.validHitFilter(hitK)) ValidHitsK++;

       				}
	
       				if (ValidHitsK >= 4 && PixelHitsK >= 1) 
				{
                        		BplusM = invMass( JPsiP, JPsiPx, JPsiPy, JPsiPz, M, itK->p(), itK->px(), itK->py(), itK->pz(), Kmass);

					/// mass constraint
// 					cout<<"Bplus origonal = "<<BplusM<<endl;
					BplusM = BplusM - M + 3.096916;

// 					cout<<"Bplus fixed = "<<BplusM<<endl;
					if ( BplusM > 4.8 && BplusM < 5.7 && M < 3.25 && M > 2.95)
					{

						//
						mytracksforBplus.clear(); mytracksforBplus = mytracksforJPSI; mytrackKaon.clear();

                                		for( vector<TransientTrack>::iterator Bpgt_trans = genralTracks_forBplus.begin(); Bpgt_trans !=genralTracks_forBplus.end(); Bpgt_trans++)
                                		{
	                                        	const reco::TrackRef trkRf = (Bpgt_trans->trackBaseRef()).castTo<reco::TrackRef>();
							if ( &*itK == trkRf.get() )
							{							
								//cout<<(Bpgt_trans->track()).pt()<<endl;
	                                       			TransientTrack  BptransientTrack = theB->build(trkRf);
                                        			mytracksforBplus.push_back(BptransientTrack);
								mytrackKaon.push_back(BptransientTrack);
							}
                                        	}

						bool checkKaonVtx = false;
						for(reco::Vertex::trackRef_iterator iTrackK  = JpsiVtxIte->tracks_begin(); iTrackK != JpsiVtxIte->tracks_end();++iTrackK)
                        			{
							const reco::TrackRef trackRefK = iTrackK->castTo<reco::TrackRef>();		
							if ( &*itK == trackRefK.get() )	{checkKaonVtx = true;}	
							
						}

						HelixTrans BReconstruction(false);
						BReconstruction.SetBuilder(theB);
						AllFitPars2.clear();
						
						AllFitPars2 = BReconstruction.SimpleFitWithFitterCMS(mytracksforBplus, JpsiVtxIte, false);
						AllFitPars2BS = BReconstruction.SimpleFitWithFitterCMS(mytracksforBplus, JpsiVtxIte, true);

						// cout<<AllFitPars2[0]<<"	"<<AllFitPars2BS[0]<<endl;
						// cout<<"Evnet ID = "<<iEvent.id().event()<<endl;
						BReconstruction.FindPVfor2Tracks(Primvertex->begin(), Primvertex->end(), mytrackKaon);

						// cout<<"B size = "<<AllFitPars2.size()<<"  J size = "<<AllFitPars.size()<<endl;	
						// cout<<"B vtx = "<<AllFitPars2[3]<<"	"<<AllFitPars2[4]<<"	"<<AllFitPars2[5]<<"	DL = "<<AllFitPars2[0]<<"   dDL  = "<<AllFitPars2[1]<<endl;
						// cout<<"J vtx = "<<AllFitPars[3]<<"	"<<AllFitPars[4]<<"	"<<AllFitPars[5]<<"	DL = "<<AllFitPars[0]<<"   dDL  = "<<AllFitPars[1]<<endl;

						/// check here is vertex fit for B is valid and check if Kaon is coming from same vtx or not from vtx at all. Then - true;
						if (AllFitPars2.size() > 10 /*&& AllFitPars2[9] > 0.1*/ && ( checkKaonVtx || (BReconstruction.FindPVfor2TracksGetNvertex() < 0 )) )
        					{
						// cout<<"Vtx B old "<<myVertexBplus.position().x()<<"	"<<myVertexBplus.position().y()<<"	"<<myVertexBplus.position().z()<<endl;
						
						BplusPx = 0.; BplusPy = 0.; BplusPz = 0.; BplusPt = 0.; BplusE = 0; BplusRap = 0.; BplusP = 0.;

						BplusPx = JPsiPx + itK->px();
                                                BplusPy = JPsiPy + itK->py();
                                                BplusPz = JPsiPz + itK->pz();
						BplusP  = sqrt(BplusPx*BplusPx+BplusPy*BplusPy+BplusPz*BplusPz);
						BplusPt = sqrt(BplusPx*BplusPx+BplusPy*BplusPy);

						// rapidity calculations: 
						BplusE  = sqrt(BplusM*BplusM +  BplusP*BplusP);
						BplusRap = 0.5*log( (BplusE+BplusPz)/(BplusE-BplusPz) );


						// ct calculations: 
						// BplusLx = 0.; BplusLy = 0.; 
						DLxyBplus = 0.; DLxyBplusCt = 0.;
				
						// DLxyBplus = (BplusPx*BplusLx + BplusPy*BplusLy)/BplusPt;
						DLxyBplus   = AllFitPars2[0];
						DLxyBplusCt = (BplusM*AllFitPars2[0])/BplusPt;
		
						// cout<<"DL old = "<<DLxyBplus<<endl;
						// cout<<"DL Jpsi corr, mm = "<<dLxy_corr*10<<"   DL Bplus corr, mm = "<<DLxyBplusCt*10<<endl;


						
						if (BplusPt > 5. && fabs(BplusRap) < 2.4 )
						{
							
							histset[410]->Fill(AllFitPars2[9]);

							if (AllFitPars2[9] < 2)			/// chi2/ndof vertex of a B-hadron 
							{

							hxhy[200]->Fill(DLxyBplusCt*10, BplusM);
							hxhy[201]->Fill(AllFitPars2[2], BplusM);
						
							VectBplus[counterBplus].push_back(BplusM);			// 0
							VectBplus[counterBplus].push_back(BplusP);			// 1
							VectBplus[counterBplus].push_back(BplusPt);			// 2
                                                        VectBplus[counterBplus].push_back(BplusPx);			// 3	
                                                        VectBplus[counterBplus].push_back(BplusPy);			// 4
                                                        VectBplus[counterBplus].push_back(BplusPz);			// 5
                                                        VectBplus[counterBplus].push_back(BplusRap);			// 6
                                                        VectBplus[counterBplus].push_back(DLxyBplus*10);		// 7	
                                                        VectBplus[counterBplus].push_back(DLxyBplusCt*10);		// 8	
							VectBplus[counterBplus].push_back(AllFitPars2[2]); 		// 9
							
							VectBplus[counterBplus].push_back(AllFitPars2BS[0]*10); 				// 10
							VectBplus[counterBplus].push_back(10*BplusM*AllFitPars2BS[0]/BplusPt); 			// 11
							VectBplus[counterBplus].push_back(AllFitPars2BS[2]); 					// 12
							
							

							histset[400]->Fill(BplusM);
							histset[401]->Fill(BplusP);
							histset[402]->Fill(BplusPt);
	                                                histset[403]->Fill(BplusPx);
        	                                        histset[404]->Fill(BplusPy);
                	                                histset[405]->Fill(BplusPz);
							histset[406]->Fill(BplusRap);
							histset[407]->Fill(DLxyBplus*10);
							histset[408]->Fill(DLxyBplusCt*10);	
							histset[412]->Fill(AllFitPars2[2]);							// sign
	
							counterBplus ++;

							if (BplusM > 5.2 && BplusM < 5.36)	
								{

								
								histset[414]->Fill(DLxyBplus*10);
								histset[415]->Fill(DLxyBplusCt*10);
								histset[416]->Fill(AllFitPars2[2]);						// sign

								if (DLxyBplusCt*10 > 0.1) { histset[475]->Fill(BplusM); }
								if (10*BplusM*AllFitPars2BS[0]/BplusPt > 0.1) { histset[476]->Fill(BplusM); }
								
								if (DLxyBplusCt*10 < 0) {histset[418]->Fill(-1*DLxyBplusCt*10); histset[418]->Fill(DLxyBplusCt*10);}
								if (AllFitPars2[2] < 0) {histset[419]->Fill(-1*AllFitPars2[2]); histset[419]->Fill(AllFitPars2[2]);}
	
								}
								if (DLxyBplusCt*10 > 0.1) {histset[409]->Fill(BplusM); }

							}  /// end if : chi2/ndof

						}  /// end if : BplusPt > 5. && fabs(BplusRap) < 2.4
						//cout<<"B+ mass = "<<BplusM<<endl;

						} /// vertex Bplus is valid and Kaon from JPsi vtx;

					} /// mass B cut + JPsi mass cut for peak region only

				} /// if : (ValidHitsK >= 4 && PixelHitsK >= 1) 

			}  /// end if : K pt, Kaon CHi2/ndof < 5

			}  /// check if Kaon is not one from the JPsi muons;

                } /// end Kaon loop


	if (counterBplus > 0) { histset[411]->Fill(counterBplus); }	


/// **************************************************************************************************** ///
/// old part from Bridget (artificial at the moment) 

/*
		  //------------invariant mass------------------------------//

		  s1=sqrt(((itMuon->p())*(itMuon->p())+sqm1)*((itM->p())*(itM->p())+sqm1));
		  s2=itMuon->px()*itM->px()+itMuon->py()*itM->py()+itMuon->pz()*itM->pz();
		  s=sqrt(2.0*(sqm1+(s1-s2)));
		 
		  scorr=(1.0+0.00038+0.0003*(itM->eta()+itMuon->eta())*(itM->eta()+itMuon->eta())/4)*s;
		  w=200/log(10)/s;
		  histset[101]->Fill(log10(s),w);
		  if(jpsi_flag2==1 && jpsi_flag1==1){//fill the jpsi hists only if these criteria are fulfilled
		  histset[32]->Fill(s);
		  histset[65]->Fill(scorr);
          	  M=invMass(itM->p(),itM->px(),itM->py(),itM->pz(),mumass,itMuon->p(),itMuon->px(),itMuon->py(),itMuon->pz(),mumass);
          	  histset[207]->Fill(M);



		  }//end of if(jpsi_flag2)
		  if(Zflag1==1 && Zflag2==1)// fill only if  z flags are fine
		    {
		      histset[94]->Fill(s);
		//	cout<<"s = "<<s<<"  M  = "<<M<<endl;
		      
		    }


            
		  //------------------rapidity------------------------------//

		  s3=(itMuon->p())*(itMuon->p())+(itM->p())*(itM->p());
		  s4= sqrt(s3+2*s2+s*s);
		  pz=itM->pz()+itMuon->pz();
		  rap=0.5*log((s4+pz)/(s4-pz));

		   if(jpsi_flag2 && jpsi_flag1){//fill the jpsi hists only if these criteria are fulfilled
		  if(fabs(rap)<1.2){ histset[39]->Fill(s); histset[73]->Fill(scorr);}
		  else if(fabs(rap)<1.6){ histset[40]->Fill(s);histset[74]->Fill(scorr);}
		  else if(fabs(rap)<2.4){ histset[41]->Fill(s);histset[75]->Fill(scorr);}
		   }
            


// 		cout<<"JPsi rap old = "<<rap<<endl;	

            
            //-------------------------------Acceptance histogram----------------------------------------------//
            
            	if (abs(s-jpsim)<.1 && jpsi_flag2==1 && jpsi_flag1==1 )
		{
                	pt_jpsi=sqrt( pow( itM->px() + itMuon->px(), 2 ) + pow( itM->py() + itMuon->py(), 2 ) );
                	histset[205]->Fill(pt_jpsi);
                	hxhy[1]->Fill(  abs(rap), pt_jpsi );
                	hxhy[2]->Fill(  abs(rap), pt_jpsi );
            	}
*/

/// **************************************************************************************************** ///
                                                }  /// end of JPsi.isValid()
					} /// end of muon vertex match
				} /// end of mytracksforJPSI.size() > 1
			} /// end of "if (jpsi_flag2==1 && jpsi_flag1==1)"
        	}  /// end of "if (JPsiDL)"
	} /// end of "if(itM->charge()==-itMuon->charge() )"
/// **************************************************************************************************** ///


/*
/// **************************************************************************************************** ///
/// Upsilon + W part : 
{
            //--------------------------upsilon range--------------------------------------------------------//
            
            
            	if (Yflag==1 && (abs(rap) < 2 )&& (abs(M-11)<3 )) 
		{
                histset[250]->Fill(M);
                histset[252]->Fill(scorr);
                if (abs(itM->eta())<1 && abs(itMuon->eta())<1) {histset[251]->Fill(M); histset[253]->Fill(scorr); }
            	}
            
		  if(fabs(itM->eta())<2.4 && fabs(itMuon->eta())<2.4){ histset[43]->Fill(s); histset[72]->Fill(scorr);}
		  if(fabs(itM->eta())<1. && fabs(itMuon->eta())<1.) {  histset[42]->Fill(s);histset[71]->Fill(scorr);}
		

       		if(itM->charge()==itMuon->charge() )// like charges invariant mass
		{
		  s1=sqrt(((itMuon->p())*(itMuon->p())+sqm1)*((itM->p())*(itM->p())+sqm1));
		  s2=itMuon->px()*itM->px()+itMuon->py()*itM->py()+itMuon->pz()*itM->pz();
		  s=sqrt(2.0*(sqm1+(s1-s2)));
		  
		  w=200/log(10)/s;
		  histset[103]->Fill(log10(s),w);
		  if(jpsi_flag2 && jpsi_flag1){// only if the jpsi cuts are fulfilled
		    histset[45]->Fill(s);
		    histset[82]->Fill(s);
		  }
		  if(Zflag1==1 && Zflag2==1)//only if Z cuts are satisfied
		  {
		      
		      histset[95]->Fill(s);
		      
		  }
		}


  	  //-------------------------------------------W Block--------------------------------------------------------------------//
    Mt=sqrt(2.0*(itMuon->pt())*((pfmets->front()).pt())*(1.0-cos((itMuon->phi())-((pfmets->front()).phi()))));
    histset[129]->Fill(Mt);
	  if(Wflag1==1 && Wflag2==1)
	    {
	      histset[130]->Fill(Mt);
	      histset[137]->Fill((pfmets->front()).pt());
	    }


/// **************************************************************************************************** ///
}
*/


		}  /// for(;itM!=muons;...) 
    	}  /// (muons->size()>=2) ends
} /// Muon Collection for loop ends

if (counterJPsi > 0 ) { histset[417]->Fill(counterJPsi); } 

} /// JpsiProduction = true;



/// /// ***********************************************************************************************************************************************
/// ***************************************************************************************************************************************************
/// B hadrons one per event with highest Pt: 
/// ***************************************************************************************************************************************************
	if (counterBplus > 0 && VectBplus[0].size() > 0 /*&& (iEvent.id().event() == 222139613)*/ )	
	{	
		double Pttmp = -999;
		int goodIter = 0;		
		
		for(int i=0; i<counterBplus;i++)     
		{
// 			cout<<"iter = "<<i<<VectBplus[i][0]<<endl;	
			if (VectBplus[i][2] > Pttmp)
			{
				Pttmp = VectBplus[i][2];
				goodIter = i;

			}
		}
			// cout<<"Evnet ID = "<<iEvent.id().event()<<endl;
			// cout<<"goodIter = "<<goodIter<<endl;
			histset[450]->Fill(VectBplus[goodIter][0]);
			histset[451]->Fill(VectBplus[goodIter][1]);
			histset[452]->Fill(VectBplus[goodIter][2]);
	                histset[453]->Fill(VectBplus[goodIter][3]);
        	        histset[454]->Fill(VectBplus[goodIter][4]);
                	histset[455]->Fill(VectBplus[goodIter][5]);
			histset[456]->Fill(VectBplus[goodIter][6]);
			histset[457]->Fill(VectBplus[goodIter][7]);
			histset[458]->Fill(VectBplus[goodIter][8]);	
			histset[462]->Fill(VectBplus[goodIter][9]);					/// sign
			
			histset[467]->Fill(VectBplus[goodIter][10]);					
			histset[468]->Fill(VectBplus[goodIter][11]);					
			histset[469]->Fill(VectBplus[goodIter][12]);					/// sign

			// cout<<VectBplus[goodIter][0]<<"	"<<VectBplus[goodIter][8]<<endl;

			if (VectBplus[goodIter][8] > 0.1)	{ histset[473]->Fill(VectBplus[goodIter][0]); }
			if (VectBplus[goodIter][11] > 0.1)	{ histset[474]->Fill(VectBplus[goodIter][0]); }

			if (VectBplus[goodIter][0] > 5.2 && VectBplus[goodIter][0] < 5.36)	{

			histset[464]->Fill(VectBplus[goodIter][7]);
			histset[465]->Fill(VectBplus[goodIter][8]);
			histset[466]->Fill(VectBplus[goodIter][9]);					/// sign
			
			histset[470]->Fill(VectBplus[goodIter][10]);					
			histset[471]->Fill(VectBplus[goodIter][11]);					
			histset[472]->Fill(VectBplus[goodIter][12]);					/// sign

	  					
												}

	}

/// ***************************************************************************************************************************************************
/// ***************************************************************************************************************************************************

/*------------------------------------------------------------------------------------------------------------------------------------------------
  -----------------------------------------------ELECTRON COLLECTION--------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------------------------------------------------*/


/*




histset[105]->Fill(electrons->size());
 for( reco::GsfElectronCollection::const_iterator it = electrons->begin(); it !=
 electrons->end(); it++) {
   int Z_ElecFlag1=0;
   int W_ElecFlag1=0;
    int Z_ElecFlag2=0;
    int W_ElecFlag2=1;
   
   double Mt;
   int misshits, misshits1;
   histset[96]->Fill(it->p());
    histset[97]->Fill(it->pt());
    histset[98]->Fill(it->eta());
    histset[99]->Fill(it->phi());
    histset[106]->Fill(fabs((it->superCluster())->eta()));
    histset[118]->Fill((it->et()));
    histset[107]->Fill(fabs((it->superCluster())->rawEnergy()));
    if(it->isEB()){
    
      histset[108]->Fill(it->dr03TkSumPt()/(it->pt()));//for electron, pt and et are nearly the same.
      histset[109]->Fill(it->dr03EcalRecHitSumEt()/(it->pt()));
      histset[110]->Fill(it->dr03HcalTowerSumEt()/(it->pt()));
    }
    if(it->isEE()){
   
      histset[120]->Fill(it->dr03TkSumPt()/(it->pt()));
      histset[121]->Fill(it->dr03EcalRecHitSumEt()/(it->pt()));
      histset[122]->Fill(it->dr03HcalTowerSumEt()/(it->pt()));
    }
    misshits=((it->gsfTrack())->trackerExpectedHitsInner()).numberOfHits();
    histset[111]->Fill(misshits); // number of missing hits
    histset[113]->Fill(it->convDist());
    histset[112]->Fill(it->convDcot());

    if(it->isEB()){
    histset[114]->Fill(it->sigmaIetaIeta());
    histset[115]->Fill(it->deltaPhiSuperClusterTrackAtVtx());
    histset[116]->Fill(it->deltaEtaSuperClusterTrackAtVtx());
    histset[117]->Fill(it->hcalOverEcal());
    }
    if(it->isEE()){
    histset[123]->Fill(it->sigmaIetaIeta());
    histset[124]->Fill(it->deltaPhiSuperClusterTrackAtVtx());
    histset[125]->Fill(it->deltaEtaSuperClusterTrackAtVtx());
    histset[126]->Fill(it->hcalOverEcal());
    }
    
    //checking if the electron superCluster is within ECAL acceptance
   
    if(((fabs((it->superCluster())->eta()))<1.4442) ||( (fabs((it->superCluster())->eta()))<2.5 && (fabs((it->superCluster())->eta()))>1.5666))
 {
       
	if(it->et()>20.)

	  {
	    //starting with WP80 cuts!!!

	    if(it->isEB())//for barrel
	      {
		if((it->dr03TkSumPt()/(it->pt()))<0.09 && (it->dr03EcalRecHitSumEt()/(it->pt()))<0.07 && (it->dr03HcalTowerSumEt()/(it->pt()))<0.10 && misshits<1 && it->convDist()<0.02 && it->convDcot()<0.02)
		  {
		    if(it->sigmaIetaIeta()<0.01 && fabs(it->deltaPhiSuperClusterTrackAtVtx())<0.06 && fabs(it->deltaEtaSuperClusterTrackAtVtx())<0.004 && it->hcalOverEcal()<0.04)
		      { Z_ElecFlag1=1;
			W_ElecFlag1=1;
			
		      }
		    
		  }
	      }
	    else if(it->isEE())//for endcap
	      {
		if((it->dr03TkSumPt()/(it->pt()))<0.04 && (it->dr03EcalRecHitSumEt()/(it->pt()))<0.05 && (it->dr03HcalTowerSumEt()/(it->pt()))<0.025 && misshits<1 && it->convDist()<0.02 && it->convDcot()<0.02)
		  {
		    if(it->sigmaIetaIeta()<0.03 && fabs(it->deltaPhiSuperClusterTrackAtVtx())<0.03 && it->hcalOverEcal()<0.025)
		      { Z_ElecFlag1=1;
			W_ElecFlag1=1;
			
		      }
		  }	
	      }
	  }//	if(it->et()>20) ends

	  
      }//if(((fabs(it->superCluster())->eta())<1.4442) ||( (fabs(it->superCluster())->eta())<2.5 && (fabs(it->superCluster())->eta())>1.5666)) ends

    if(electrons->size()>=2){
    GsfElectronCollection::const_iterator ite=it;
     ite++;
    
    
      for(;ite!=electrons->end();ite++)
	{
	   Z_ElecFlag2=0;
	   W_ElecFlag2=1;// to reject events with a second electron satisfying some loose criteria
	  misshits1=((ite->gsfTrack())->trackerExpectedHitsInner()).numberOfHits();
	  if((fabs((ite->superCluster())->eta())<1.4442) ||( fabs((ite->superCluster())->eta())<2.5 && fabs((ite->superCluster())->eta())>1.5666))
	 
      {
	
	if(ite->et()>20)
	  { 
	   
	  //--------------------------------------------------------Z block------------------------------------------------------------------------------//
	  //starting with WP80 cuts!!!

	    if( Z_ElecFlag1==1)
	      {// to check for the 2nd electron only if the 1st flag is true
		
	    if(ite->isEB() )
	      {
		if((ite->dr03TkSumPt()/(ite->pt()))<0.09 && (ite->dr03EcalRecHitSumEt()/(ite->pt()))<0.07 && (ite->dr03HcalTowerSumEt()/(ite->pt()))<0.10 && misshits1<1 && ite->convDist()<0.02 && ite->convDcot()<0.02)
		  {
		    
		    if(ite->sigmaIetaIeta()<0.01 && fabs(ite->deltaPhiSuperClusterTrackAtVtx())<0.06 && fabs(ite->deltaEtaSuperClusterTrackAtVtx())<0.004 && ite->hcalOverEcal()<0.04)
		      {  
			Z_ElecFlag2=1;
			
		      }
		  }
	      }
	    else if(ite->isEE())//for endcap
	      {
		if((ite->dr03TkSumPt()/(ite->pt()))<0.04 && (ite->dr03EcalRecHitSumEt()/(ite->pt()))<0.05 && (ite->dr03HcalTowerSumEt()/(ite->pt()))<0.025 && misshits1<1 && ite->convDist()<0.02 && ite->convDcot()<0.02)
		  {
		   
		    if(ite->sigmaIetaIeta()<0.03 && fabs(ite->deltaPhiSuperClusterTrackAtVtx())<0.03 && ite->hcalOverEcal()<0.025)
		      {
			Z_ElecFlag2=1;
		
		      }
		  }	
	      }
	    } //if( Z_ElecFlag1==1) ends

	    //----------------------------------------------------W block---------------------------------------------------------------------------------//

	    //starting with WP95 cuts
	    
	    //for rejecting events with a second electron, for calculating the W peak
	    if(W_ElecFlag1==1)
	      {// to check for the 2nd electron only if the 1st flag is true

		
	     if(ite->isEB() )
	      {
		if((ite->dr03TkSumPt()/(ite->pt()))<0.15 && (ite->dr03EcalRecHitSumEt()/(ite->pt()))<2.0 && (ite->dr03HcalTowerSumEt()/(ite->pt()))<0.12 && misshits1<2 )
		  {
		    if(ite->sigmaIetaIeta()<0.01  && fabs(ite->deltaEtaSuperClusterTrackAtVtx())<0.007 && ite->hcalOverEcal()<0.15)
		      { W_ElecFlag2=0;
		      }
		  }
	      }
	    else if(ite->isEE())//for endcap
	      {
		if((ite->dr03TkSumPt()/(ite->pt()))<0.08 && (ite->dr03EcalRecHitSumEt()/(ite->pt()))<0.06 && (ite->dr03HcalTowerSumEt()/(ite->pt()))<0.05 && misshits1<2)
		  {
		    if(ite->sigmaIetaIeta()<0.03 && ite->hcalOverEcal()<0.07)
		      { W_ElecFlag2=0;}
		  }	
	      }

	      }//if( W_ElecFlag1==1) ends


	  }//if(ite->et()>20) ends

	  
      }//if(((fabs(ite->superCluster())->eta())<1.4442) ||( (fabs(ite->superCluster())->eta())<2.5 && (fabs(ite->superCluster())->eta())>1.5666))  ends


	  //---------------------------------------------Z  Block----------------------------------------------------------------//
	  if(it->charge()==-ite->charge() )// unlike charges
		{
		  
		  //------------invariant mass------------------------------//

		  s1=sqrt(((ite->p())*(ite->p())+sqm1)*((it->p())*(it->p())+sqm1));
		  s2=it->px()*ite->px()+it->py()*ite->py()+it->pz()*ite->pz();
		  s=sqrt(2.0*(sqm1+(s1-s2)));
		  histset[104]->Fill(s);
		  if(Z_ElecFlag1==1 && Z_ElecFlag2==1){
		    histset[119]->Fill(s);
		    if(s>=85. && s<=95.)
		      {
			histset[138]->Fill(it->convDcot());
			histset[139]->Fill(it->convDist());
		      }
		  }
		  
		}//if((it->charge()==-ite->charge() ) ends


	  if(it->charge()==ite->charge() )// like charges
		{
		  
		  //------------invariant mass------------------------------//

		  s1=sqrt(((ite->p())*(ite->p())+sqm1)*((it->p())*(it->p())+sqm1));
		  s2=it->px()*ite->px()+it->py()*ite->py()+it->pz()*ite->pz();
		  s=sqrt(2.0*(sqm1+(s1-s2)));
		  histset[127]->Fill(s);
		  if(Z_ElecFlag1==1 && Z_ElecFlag2==1)histset[128]->Fill(s);
		}//if((it->charge()==-ite->charge() ) ends
	  

	  
	}//for(;ite!=electrons....)ends
    }//if(electrons->size()>=2) ends


	  //-------------------------------------------W Block--------------------------------------------------------------------//
    Mt=sqrt(2.0*(it->pt())*((pfmets->front()).pt())*(1.0-cos((it->phi())-((pfmets->front()).phi()))));
    histset[131]->Fill(Mt);
	  if(W_ElecFlag1==1 && W_ElecFlag2==1)
	    {
	      histset[132]->Fill(Mt);
	      histset[136]->Fill((pfmets->front()).pt());
	    }

 }//for(reco::GsfElectronCollection........) ends
 */

//////////////// ----------------------------- D* Meson Analysis ------------------------------ ////////////////

// cout<<"Evnet ID = "<<iEvent.id().event()<<endl;

    double MDstar;
    double deltaM;

    double vc[3] = {0.};
    int cf = 0;
    double MD0 = 0.;
    double paxisD0[3] = {0.};
    double pD0 = 0.;
    double ptD0 = 0.;
    double vcD0[3] = {0.};
    double vc2[3] = {0.};
    double paxisDstar[3] = {0.};
    double ptDstar = 0.;
    double sumpt = 0.;
    int n = 0;
    double vc3[3] = {0.};
    double z = 0.;

/// new vars: 
    // double distance = 0.;
    // double xBS = 0.;
    // double yBS = 0.;
    // double DLx = 0.;
    // double DLy = 0.;
    // double DLmod = 0.;
    // double cosDstar_DL = 0.;
    // double DLt = 0.;
    double DLxD0 = 0.;
    double DLyD0 = 0.;
    // double DLmodD0 = 0.;
    // double cosD0_DL = 0.;
    double DLt_D0 = 0.;

    // bool goodEvent = false;
    // bool goodEvent2 = false;
    vector<TransientTrack> mytracksforD0;
    vector<TransientTrack> mytracksforDstar;
    TransientVertex myVertex;
	
	bool VtxFound = false;
	int  VtxCounter = 0;

	bool VtxFound2 = false;
	int  VtxCounter2 = 0;
	reco::VertexCollection::const_iterator iteForD0;


vector<TransientTrack>::iterator d1;
vector<TransientTrack>::iterator d2;

if (DmesonProduction)
{


if (tracks->size()>=3)		//	check for track collection with more than 3 tracks 
{

	vector<reco::TransientTrack> genralTracks_forD = (*theB).build(tracks);


        //Now loop over tracks assuming they are kaons
        for( reco::TrackCollection::const_iterator itK1 = tracks->begin(); itK1 !=tracks->end(); itK1++) 
	{
		if ( itK1->pt() > 0.5) 
		{

		for (reco::TrackCollection::const_iterator itP2 = tracks->begin(); itP2 !=tracks->end() ; itP2 ++)
		{

// 		ptD0 = 0.; pD0 = 0.; MD0 = 0.;

                        //check P2 is not also K1 and apply Pt cut
                        if ( itP2 !=itK1 && itP2->pt() > 0.5 )  
			{

                            	// check distance of track origins,
                            	//Calculate tracks origin seperations in x, y and z
                            	vc[0] = abs(itK1->vx()-itP2->vx()); vc[1] = abs(itK1->vy()- itP2->vy()); vc[2] = abs(itK1->vz()-itP2->vz());

				//	Check they are seperated by a radius of 1mm in x and y and a distance of 0.1 in z
				if ( sqrt (vc[0]*vc[0] + vc[1]*vc[1])<0.1 && vc[2] < 0.1)	
				{
                                	//Assign flags to right and wrong charge
                                	cf=0; // 1 if right charge, -1 if wrong charge
                                    	if(itP2->charge()!= itK1->charge() )      cf = 1; //right charge
                                        else if (itP2->charge() == itK1->charge() ) cf =-1; //wrong charge
                                    	//cout << "Kaon charge: " << itK1->charge() << "| Pion Charge:  " << itP2->charge() <<endl;

                                        //Calculate D0 invariant mass, px, py, pz, p and pt
                                    	MD0 = invMass( itK1->p(),itK1->px(),itK1->py(),itK1->pz(),Kmass, itP2->p(),itP2->px(),itP2->py(),itP2->pz(), Pimass );
                                    	paxisD0[0]=itK1->px()+itP2->px(); paxisD0[1] = itK1->py() +itP2->py(); paxisD0[2]= itK1->pz() + itP2->pz() ;
                                    	pD0 = sqrt(paxisD0[0]*paxisD0[0] +paxisD0[1]*paxisD0[1] +paxisD0[2]*paxisD0[2]);
                                    	ptD0= sqrt(paxisD0[0]*paxisD0[0] +paxisD0[1]*paxisD0[1]);

                                    	//----Begin a loop over a third track to find D*
                                    	//First check D0 mass is within 600 MeV of the 1.9GeV
                                    	if (abs(MD0-1.9) < 0.3) 	// check it is a 'reasonable' D0 candidate with a loose cut
					{ 

			/// only use when need DL calculation;
			/// create D0 track collection;
			if (DmesonsDL)	
			{

				mytracksforD0.clear();

        			for( vector<TransientTrack>::iterator gt_trans = genralTracks_forD.begin(); gt_trans !=genralTracks_forD.end(); gt_trans++)
        			{
					const reco::TrackRef trackRef1 = (gt_trans->trackBaseRef()).castTo<reco::TrackRef>();
					if ( &*itK1 == trackRef1.get() || &*itP2 == trackRef1.get() )	
					{
					
                                        TransientTrack  transientTrack1 = theB->build(trackRef1);
                                        mytracksforD0.push_back(transientTrack1);
					}

				}

			}


                                        //locate D0 'vertex' using average coordinate of tracks
                                        vcD0[0] = 0.5*(itK1->vx()+itP2->vx()); vcD0[1] = 0.5*(itK1->vy()+itP2->vy()); vcD0[2] = 0.5*(itK1->vz()+itP2->vz());

                                        //Now start a third loop for the slow pion
                                        for (reco::TrackCollection::const_iterator itPS3 = tracks->begin(); itPS3 !=tracks->end() ; itPS3 ++)
					{
// 					ptDstar = 0.; MDstar = 0.; deltaM = 0.;

                                        	if (itPS3->charge()!=itK1->charge() && itPS3!=itP2 && itPS3!=itK1 ) 	//	check charge and that it not K1 or P2
						{
                                                	vc2[0] = abs(vcD0[0]-itPS3->vx()); vc2[1]= abs(vcD0[1]- itPS3->vy()) ;vc2[2] = abs(vcD0[2]-itPS3->vz());
                                                        if (sqrt(vc2[0]*vc2[0] + vc2[1]*vc2[1])<0.1 && vc2[2] <0.1)	//  Check the slow pion originates from the same region as the D0
							{ 
                                                        	//Now Calculate D* mass
                                                            	MDstar= invMass(pD0,paxisD0[0],paxisD0[1],paxisD0[2],MD0, itPS3->p(), itPS3->px(), itPS3->py(), itPS3->pz(),Pimass);
                                                            	paxisDstar[0]=paxisD0[0]+itPS3->px(); paxisDstar[1] = paxisD0[1]+itPS3->py(); paxisDstar[2]=paxisD0[2]+itPS3->pz();
                                                            	ptDstar = sqrt(paxisDstar[0]*paxisDstar[0] +paxisDstar[1]*paxisDstar[1]);

                                                            	deltaM=MDstar-MD0;
                                                            	//D* mass diff cut <0.17 to reduce overflow of histogram
                                                            	if (deltaM < 0.17)
								{

                                                                	//Start of z cut
                                                                	sumpt=0;
                                                                	n=0;     //declare varriable
                                                                	//Loop over all tracks
                                                                	for( reco::TrackCollection::const_iterator itSum = tracks->begin(); itSum!=tracks->end(); itSum++) 
									{
                                                                    	//Check track origins
                                                                    	vc3[0] = abs(vcD0[0]-itSum->vx()); vc3[1] = abs(vcD0[1]- itSum->vy()); vc3[2] = abs(vcD0[2]-itSum->vz());
                                                                    		if (sqrt(vc3[0]*vc3[0] + vc3[1]*vc3[1])<0.1 && vc3[2] <0.1)
										{
                                                                        		sumpt += fabs(itSum->pt()); // sum pt for all tracks
                                                                        		n++; //Fill a counter histogram to see how many tracks are present
                                                                    		}	// end of Sumpt vertex check
                                                                	}	//end of sum loop


                                                                	z=ptDstar/sumpt; // calculate z after loop
                                                                	histset[210]->Fill(z);
                                                                	histset[211]->Fill(n);

									 // z cut
                                                                	if (z > 0.05) {

                                                                	histset[214]->Fill(ptD0);
                                                                	histset[215]->Fill(ptDstar);
                                                                	histset[216]->Fill(itPS3->pt());
                                                                	histset[218]->Fill(itK1->pt());
                                                                	histset[219]->Fill(itP2->pt());
                                                                	histset[220]->Fill(itK1->eta());
                                                                	histset[221]->Fill(itP2->eta());
                                                                	histset[222]->Fill(itPS3->eta());

		

	// ***********************************************************************************************									
	/// only use when need DL calculation;
	/// find out closest PV to this D0 tracks 
        if ( mytracksforD0.size()>1 && DmesonsDL /*&& !VtxFound2*/)
        {
	VtxFound = false;
	VtxFound2 = false;

// 		if (!(VtxFound2 && (d1 == mytracksforD0.begin() || d2 == mytracksforD0.begin()) ) )	
// 			{

                AdaptiveVertexFitter  theFitter1;
                myVertex = theFitter1.vertex(mytracksforD0/*, vertexBeamSpot*/);    // if you don't/do want the beam constraint

		VtxCounter2 = 0;
		for(reco::VertexCollection::const_iterator ite = Primvertex->begin(); ite != Primvertex->end(); ite++)
		{

// 			if (VtxFound2 && (d1 == mytracksforD0.begin() || d2 == mytracksforD0.begin()) ) {continue;}
		
			VtxCounter = 0;
			for(reco::Vertex::trackRef_iterator iTrack  =ite->tracks_begin(); iTrack != ite->tracks_end();++iTrack) 
			{
				const reco::TrackRef trackRef = iTrack->castTo<reco::TrackRef>();

					VtxFound = false;
				        for( vector<TransientTrack>::iterator gt1 = mytracksforD0.begin(); gt1 !=mytracksforD0.end(); gt1++)
        				{
// 						cout<<"in  "<<(gt1->track()).pt()<<endl;
						const reco::TrackRef trackRef2 = (gt1->trackBaseRef()).castTo<reco::TrackRef>();
						if (trackRef.get() == trackRef2.get())	{VtxFound = true; }
					}
					if (VtxFound) {VtxCounter++;}	

			}
// if (DmesonsDL && ptDstar>3.5 && itK1->pt()>1 && itP2->pt()>1 && itPS3->pt()>0.25 && abs(MD0-MD0Actual)<0.025 && myVertex.isValid() )	
// 			{
// 			cout<<"Evnet ID = "<<iEvent.id().event()<<endl;
// 			cout<<"Vtx Nr "<<VtxCounter2<<"  has "<< VtxCounter<<"  tracks from D0"<<endl;
// 			}
			VtxCounter2++;
			if (VtxCounter > 0)	{iteForD0 = ite;VtxFound2 = true;}	
		}

// 			}


	}



	// ***********************************************************************************************
	/// this part will reduce number of the loops in "find out closest PV to this D0 tracks" part:
	if (VtxFound2)	
	{  
		d1 = mytracksforD0.begin();  
		d2 = d1++; 
	// 	cout<<"out  "<<(d1->track()).pt()<<"	"<<(d2->track()).pt()<<endl;
	}
	// ***********************************************************************************************
	
	DLxD0 = 0; DLyD0 = 0; DLt_D0 = 0; 
	// DLmodD0 = 0; cosD0_DL = 0;
		if (myVertex.isValid() && VtxFound2)  		{

			DLxD0 = 0; DLyD0 = 0; DLt_D0 = 0;
			// DLmodD0 = 0; cosD0_DL = 0;
	
			DLxD0 = (myVertex.position()).x()- iteForD0->x();
			DLyD0 = (myVertex.position()).y()- iteForD0->y();
			// DLmodD0 = sqrt(DLxD0*DLxD0 + DLyD0*DLyD0);	
			
			DLt_D0 = (paxisD0[0]*DLxD0 + DLyD0*paxisD0[1])/(ptD0);

		}
/// good!!! 

/// DL D-mesons calculations: 

// goodEvent = false;
// goodEvent2 = false;
/// ATLAS cuts
if (DmesonsDL && ptDstar>3.5 && itK1->pt()>1 && itP2->pt()>1 && itPS3->pt()>0.25 && abs(deltaM-0.1454)<0.001 )	
			{

// DLxD0 = 0; DLyD0 = 0; DLt_D0 = 0; DLmodD0 = 0; cosD0_DL = 0;

// cout<<"VtxFound2 ="<<VtxFound2<<endl; 
// cout<<"D0 mass = "<<MD0<<"  M D* = "<<MDstar<<endl;

/// fill D0 candidates, but no vertex requirements
if (cf==1) {histset[732]->Fill(1);}
if (cf==-1) {histset[1732]->Fill(1);}
	

		
		/// For D0 vertex: 
		if (myVertex.isValid() && VtxFound2)  		{

			if (cf==1) 	{
			  
	histset[500]->Fill((myVertex.originalTracks()).size());
	histset[501]->Fill((myVertex.position()).x());
	histset[502]->Fill((myVertex.position()).y());
	histset[503]->Fill((myVertex.position()).z());
	histset[504]->Fill( myVertex.normalisedChiSquared()); 



			histset[730]->Fill(1);

// 			DLxD0 = (myVertex.position()).x()- iteForD0->x();
// 			DLyD0 = (myVertex.position()).y()- iteForD0->y();
// 			DLmodD0 = sqrt(DLxD0*DLxD0 + DLyD0*DLyD0);	
// 			
// 			DLt_D0 = (paxisD0[0]*DLxD0 + DLyD0*paxisD0[1])/(ptD0);

// 			cout<<"DL s+ = "<<DLt_D0<<endl;
// 			goodEvent = true;
// 			goodEvent2 = true;

			/// peak region
			if (abs(MD0-MD0Actual)<0.025)  			{
				histset[527]->Fill( myVertex.normalisedChiSquared()); 
				histset[580]->Fill(DLt_D0*10);	// in mm now. 
				histset[581]->Fill(DLt_D0*10*MD0/ptD0);	// in mm now. 
				if (DLt_D0 < 0.) {histset[582]->Fill(DLt_D0*10); histset[582]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[583]->Fill(DLt_D0*10.); } else { histset[584]->Fill(DLt_D0*10.); }
			
				histset[703]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[704]->Fill(ptD0); } else { histset[705]->Fill(ptD0); }

				histset[731]->Fill(1);				// Vertex Multi	
		
									}
			/// left side
			if (MD0<1.8 && MD0 > 1.75)  			{
				histset[525]->Fill( myVertex.normalisedChiSquared()); 
				histset[510]->Fill(DLt_D0*10); 
				histset[511]->Fill(DLt_D0*10*MD0/ptD0); 
				if (DLt_D0 < 0.) {histset[512]->Fill(DLt_D0*10); histset[512]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[513]->Fill(DLt_D0*10.); } else { histset[514]->Fill(DLt_D0*10.); }

				histset[706]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[708]->Fill(ptD0); } else { histset[710]->Fill(ptD0); }	

									}
			/// right side
			if (MD0>1.93 && MD0 < 1.98)  			{
				histset[526]->Fill( myVertex.normalisedChiSquared()); 
				histset[520]->Fill(DLt_D0*10); 
				histset[521]->Fill(DLt_D0*10*MD0/ptD0); 
				if (DLt_D0 < 0.) {histset[522]->Fill(DLt_D0*10); histset[522]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[523]->Fill(DLt_D0*10.); } else { histset[524]->Fill(DLt_D0*10.); }

				histset[707]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[709]->Fill(ptD0); } else { histset[711]->Fill(ptD0); }	

									}
			/// full range D0 mass
			histset[700]->Fill(ptD0);
// 			histset[212]->Fill(deltaM);
			histset[224]->Fill(MD0); 
// 			hxhy[3]->Fill(MD0,deltaM);
			
			histset[952]->Fill(DLt_D0*10);				
			histset[953]->Fill(DLt_D0*10*MD0/ptD0);
			if (DLt_D0 < 0.) { histset[954]->Fill(DLt_D0*10); histset[954]->Fill(-1*DLt_D0*10); }				
			
			if (DLt_D0*10. < 0.2)	{ histset[236]->Fill(MD0); histset[701]->Fill(ptD0); histset[955]->Fill(DLt_D0*10);} 
				else { histset[232]->Fill(MD0); histset[702]->Fill(ptD0); histset[956]->Fill(DLt_D0*10);}
	
// 			DLt_D0 = 0.; DLxD0 = 0.; DLyD0 = 0.; DLmodD0 = 0.;
					   } /// end if c ==1
			


/// Wrong Sign combination start here: 
		        if (cf==-1) 	{
			
			
	histset[1500]->Fill((myVertex.originalTracks()).size());
	histset[1501]->Fill((myVertex.position()).x());
	histset[1502]->Fill((myVertex.position()).y());
	histset[1503]->Fill((myVertex.position()).z());
	histset[1504]->Fill( myVertex.normalisedChiSquared()); 			

			histset[1730]->Fill(1);

// 			DLxD0 = (myVertex.position()).x() - iteForD0->x();
// 			DLyD0 = (myVertex.position()).y() - iteForD0->y();
// 			DLmodD0 = sqrt(DLxD0*DLxD0 + DLyD0*DLyD0);
// 
// 			DLt_D0 = (paxisD0[0]*DLxD0 + DLyD0*paxisD0[1])/(ptD0);

// 			cout<<"DL s- = "<<DLt_D0<<endl;
			/// peak region
			if (abs(MD0-MD0Actual)<0.025)  			{
				histset[1527]->Fill( myVertex.normalisedChiSquared()); 
				histset[1580]->Fill(DLt_D0*10);	// in mm now. 
				histset[1581]->Fill(DLt_D0*10*MD0/ptD0);	// in mm now. 
				if (DLt_D0 < 0.) {histset[1582]->Fill(DLt_D0*10); histset[1582]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[1583]->Fill(DLt_D0*10.); } else { histset[1584]->Fill(DLt_D0*10.); }
			
				histset[1703]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[1704]->Fill(ptD0); } else { histset[1705]->Fill(ptD0); }

				histset[1731]->Fill(1);				// Vertex Multi	
		
									}
			/// left side
			if (MD0<1.8 && MD0 > 1.75)  			{
				histset[1525]->Fill( myVertex.normalisedChiSquared()); 
				histset[1510]->Fill(DLt_D0*10); 
				histset[1511]->Fill(DLt_D0*10*MD0/ptD0); 
				if (DLt_D0 < 0.) {histset[1512]->Fill(DLt_D0*10); histset[1512]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[1513]->Fill(DLt_D0*10.); } else { histset[1514]->Fill(DLt_D0*10.); }

				histset[1706]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[1708]->Fill(ptD0); } else { histset[1710]->Fill(ptD0); }	

									}
			/// right side
			if (MD0>1.93 && MD0 < 1.98)  			{
				histset[1526]->Fill( myVertex.normalisedChiSquared()); 
				histset[1520]->Fill(DLt_D0*10); 
				histset[1521]->Fill(DLt_D0*10*MD0/ptD0); 
				if (DLt_D0 < 0.) {histset[1522]->Fill(DLt_D0*10); histset[1522]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[1523]->Fill(DLt_D0*10.); } else { histset[1524]->Fill(DLt_D0*10.); }

				histset[1707]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[1709]->Fill(ptD0); } else { histset[1711]->Fill(ptD0); }	

									}

			/// full range D0 mass
			histset[1700]->Fill(ptD0);
// 			histset[1212]->Fill(deltaM);
			histset[1224]->Fill(MD0); 
// 			hxhy[4]->Fill(MD0,deltaM);

			histset[1952]->Fill(DLt_D0*10);				
			histset[1953]->Fill(DLt_D0*10*MD0/ptD0);
			if (DLt_D0 < 0.) { histset[1954]->Fill(DLt_D0*10); histset[1954]->Fill(-1*DLt_D0*10); }				
			
			if (DLt_D0*10. < 0.2)	{ histset[1236]->Fill(MD0); histset[1701]->Fill(ptD0); histset[1955]->Fill(DLt_D0*10);} 
				else { histset[1232]->Fill(MD0); histset[1702]->Fill(ptD0); histset[1956]->Fill(DLt_D0*10);}


// 			DLt_D0 = 0.; DLxD0 = 0.; DLyD0 = 0.; DLmodD0 = 0.;

					}	/// end if cf == -1

								}	// if myVertex is valid

// cout<<"Evnet ID = "<<iEvent.id().event()<<endl;
// cout<<"MDstar = "<<MDstar<<"	MD0 = "<<MD0<<"	DL, mm = "<<DLt_D0*10<<endl;


			}	/// end ATLAS cuts check

/*
/// BEGIN of my new Fit addons **************************************************************
// 	if (goodEvent) 	{cout<<endl<<"*****************************************************"<<endl;
// 			 cout<<"Evnet ID = "<<iEvent.id().event()<<",	DL = "<<DLt_D0<<endl;
// 			 cout<<"X vtx = "<<(myVertex.position()).x()<<"	Y = "<<(myVertex.position()).y()<<"	Z = "<<(myVertex.position()).z()<<endl;		
// 			}


// goodEvent = false;
goodEvent2 = false;


/// check D0 DL with my algorithm using only 2 tracks from the D0 selection;
if (Primvertex->size() > 0 && goodEvent)	{

// for(reco::VertexCollection::const_iterator ite = Primvertex->begin(); ite !=Primvertex->end(); ite++) {
/// add new vertex fit from vxlite: 
	HelixTrans ZeusAlgorithmD0(false);

/// Set the track builder:
/// It is used almost at the each step; Should be initialized!  
	ZeusAlgorithmD0.SetBuilder(theB);

/// Set magnetic field here:
/// It is used almost at the each step; Should be initialized!  
	ESHandle<MagneticField> BField;
	iSetup.get<IdealMagneticFieldRecord>().get(BField);
	ZeusAlgorithmD0.SetMagneticField(BField);

/// Set Beam Spot Information:	
	Handle<reco::BeamSpot> beamSpotHandle_I;
	iEvent.getByLabel("offlineBeamSpot", beamSpotHandle_I);
	ZeusAlgorithmD0.SetBeamSpotInformation(beamSpotHandle_I);

/// Set all tracks from the event:
/// It is used for "GetTracksNotFromPVs" function;
	ZeusAlgorithmD0.SetGeneralTrackCollection(genralTracksTEST);

/// Set tracks which are not from the PVs;
//	ZeusAlgorithm.SetTrackCollectionFromPV(mytracks);
        ZeusAlgorithmD0.SetTrackCollectionForAlgorithm(mytracksforD0);

/// Work with ZEUS fitter: 
/// This method include tracks not prom PVs. It find track clusters from; 
/// Make a fit of the cluster and extract XYZ vertex position; 
/// Calculate DL;

// 	vector<double> *vectorDL = ZeusAlgorithmD0.MakeAFitwithVxlite(ite);
	vector<double> *vectorDL = ZeusAlgorithmD0.FitWithFitterCMS(iteForD0);
// }

	for(unsigned i=0; i<vectorDL[0].size();i++)	{
// 		cout<<vectorDL[0][i]<<endl;
	  
// 		cout<<"DL out  "<<vectorDL[0][i]<<"  DLsign out = "<<vectorDL[0][i]/vectorDL[1][i]<<endl;
		histset[900]->Fill(vectorDL[0][i]);
		histset[902]->Fill(vectorDL[0][i]/vectorDL[1][i]);
		
	if (vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8)	{ histset[904]->Fill(vectorDL[0][i]/vectorDL[1][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[905]->Fill(vectorDL[0][i]/vectorDL[1][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[906]->Fill(vectorDL[0][i]/vectorDL[1][i]);}

	if (vectorDL[3][i] < 1.2 &&  vectorDL[3][i] > 0.8)	{ histset[910]->Fill(vectorDL[0][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[911]->Fill(vectorDL[0][i]);}
// 	if (vectorDL[2][i] > 2)	{ histset[912]->Fill(vectorDL[0][i]);}
		
// 		histset[903]->Fill(vectorDL[2][i]);
	
		}



}



if (goodEvent2) 	{


	int ccounter = 0;	
        for( vector<TransientTrack>::iterator gt_transTmp = genralTracks_forD.begin(); gt_transTmp !=genralTracks_forD.end(); gt_transTmp++)
        {
		const reco::TrackRef ref111 = (gt_transTmp->trackBaseRef()).castTo<reco::TrackRef>();
	        for( vector<TransientTrack>::iterator gt1 = mytracksforD0.begin(); gt1 !=mytracksforD0.end(); gt1++)
        	{
		const reco::TrackRef ref222 = (gt1->trackBaseRef()).castTo<reco::TrackRef>();
		if (ref111.get() != ref222.get())	{continue;}	
		else {cout<<"Nr = "<<ccounter<<"	"<<(gt_transTmp->track()).pt()<<"	"<<(gt_transTmp->track()).eta()<<"	"<<(gt_transTmp->track()).phi()<<endl;}

		}
		ccounter++;

	}

}

*/

/*
/// not strong cuts from Bridget
if (DmesonsDL && abs(deltaM-0.1454)<0.001 )
			{
/// fill D0 candidates, but no vertex requirements
if (cf==1) {histset[836]->Fill(1);}
	
DLxD0 = 0; DLyD0 = 0; DLt_D0 = 0; DLmodD0 = 0; cosD0_DL = 0;

/// For D0 vertex: 
		if (myVertex.isValid() && VtxFound2 )  		{
			if (cf==1) 	{

	histset[800]->Fill((myVertex.originalTracks()).size());
	histset[801]->Fill((myVertex.position()).x());
	histset[802]->Fill((myVertex.position()).y());
	histset[803]->Fill((myVertex.position()).z());
	histset[804]->Fill( myVertex.normalisedChiSquared()); 


			histset[834]->Fill(1);


			DLxD0 = (myVertex.position()).x()- iteForD0->x();
			DLyD0 = (myVertex.position()).y()- iteForD0->y();
// 			DLxD0 = (myVertex.position()).x()- xBS;
// 			DLyD0 = (myVertex.position()).y()- yBS;
			DLmodD0 = sqrt(DLxD0*DLxD0 + DLyD0*DLyD0);	

			cosD0_DL = (paxisD0[0]*DLxD0 + DLyD0*paxisD0[1])/(DLmodD0*ptD0);
			DLt_D0 =  DLmodD0 * cosD0_DL;

			/// peak region
			if (abs(MD0-MD0Actual)<0.025)  			{
				histset[837]->Fill( myVertex.normalisedChiSquared());
				histset[817]->Fill(DLt_D0*10);	// in mm now. 
				histset[818]->Fill(DLt_D0*10*MD0/ptD0);	// in mm now. 
				if (DLt_D0 < 0.) {histset[819]->Fill(DLt_D0*10); histset[819]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[820]->Fill(DLt_D0*10.); } else { histset[821]->Fill(DLt_D0*10.); }
			
				histset[825]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[826]->Fill(ptD0); } else { histset[827]->Fill(ptD0); }

				histset[835]->Fill(1);				// Vertex Multi	
		
									}
			/// left side
			if (MD0<1.8 && MD0 > 1.75)  			{
				histset[815]->Fill( myVertex.normalisedChiSquared());
				histset[805]->Fill(DLt_D0*10); 
				histset[806]->Fill(DLt_D0*10*MD0/ptD0); 
				if (DLt_D0 < 0.) {histset[807]->Fill(DLt_D0*10); histset[807]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[808]->Fill(DLt_D0*10.); } else { histset[809]->Fill(DLt_D0*10.); }

				histset[828]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[830]->Fill(ptD0); } else { histset[832]->Fill(ptD0); }	

									}
			/// right side
			if (MD0>1.93 && MD0 < 1.98)  			{
				histset[816]->Fill( myVertex.normalisedChiSquared());
				histset[810]->Fill(DLt_D0*10); 
				histset[811]->Fill(DLt_D0*10*MD0/ptD0); 
				if (DLt_D0 < 0.) {histset[812]->Fill(DLt_D0*10); histset[812]->Fill(-1*DLt_D0*10);}
				if (DLt_D0*10. < 0.2)	{ histset[813]->Fill(DLt_D0*10.); } else { histset[814]->Fill(DLt_D0*10.); }

				histset[829]->Fill(ptD0);
				if (DLt_D0*10. < 0.2)	{ histset[831]->Fill(ptD0); } else { histset[833]->Fill(ptD0); }	

									}
			/// full range D0 mass
			histset[822]->Fill(ptD0);

					}

			if (DLt_D0*10. < 0.2)	
			{
				if (cf == 1)	{ histset[234]->Fill(MD0); histset[823]->Fill(ptD0);} else if (cf==-1) {histset[235]->Fill(MD0);}

			} else 	{ 
				if (cf == 1)	{ histset[230]->Fill(MD0); histset[824]->Fill(ptD0); } else if (cf==-1) {histset[231]->Fill(MD0);}
				}
			

							

							}

			}

*/		
								
							    /// common part +-			
					if (ptDstar>3.5 && itK1->pt()>1 && itP2->pt()>1 && itPS3->pt()>0.25 && abs(MD0-MD0Actual)<0.025 && myVertex.isValid() && VtxFound2) 	// with cut on D0 mass
							{

								// cout<<"Evnet ID = "<<iEvent.id().event()<<endl;
// 								cout<<"MDstar = "<<MDstar<<"	MD0 = "<<MD0<<"	dM = "<<MDstar-MD0<<"	DL, mm = "<<DLt_D0*10<<endl;

								if (cf == 1) 
								{
									if (DLt_D0 < 0.02)	{ histset[950]->Fill(deltaM); } else { histset[951]->Fill(deltaM); }
									histset[212]->Fill(deltaM);
									// cout<<"S+ MDstar = "<<MDstar<<"	MD0 = "<<MD0<<"	dM = "<<MDstar-MD0<<"	DL, mm = "<<DLt_D0*10<<endl;

								}

								if (cf == -1) 
								{
									if (DLt_D0 < 0.02)	{ histset[1950]->Fill(deltaM); } else { histset[1951]->Fill(deltaM); }
									histset[1212]->Fill(deltaM);
									// cout<<"S- MDstar = "<<MDstar<<"	MD0 = "<<MD0<<"	dM = "<<MDstar-MD0<<"	DL, mm = "<<DLt_D0*10<<endl;
								}
							}

                                                            if (abs(MD0-MD0Actual)<0.030 ) {//hard D0 cut of 60 MeV around the central mass

                                                                //Fill deltaM histograms depending on Charge flag cf
                                                                if      (cf==1)  histset[208]->Fill(deltaM);

                                                            } //hard cut on D0 mass ends

                                                            /// loose cuts
                                                            if (abs(deltaM-0.1454)<0.001 && (myVertex.isValid() ) )	{
                                                                if      (cf==1)  histset[217]->Fill(MD0);
                                                                else if (cf==-1) histset[223]->Fill(MD0);

                                                            }

 							if (ptDstar>3.5 && itK1->pt()>1 && itP2->pt()>1 && itPS3->pt()>0.25 && (myVertex.isValid() ) ) 
							{

                                                                if      (cf==1)  hxhy[3]->Fill(MD0,deltaM);
                                                                else if (cf==-1) hxhy[4]->Fill(MD0,deltaM);
                                                        }

			DLt_D0 = 0.; DLxD0 = 0.; DLyD0 = 0.; 
			// DLmodD0 = 0.;



/// end of the loops and cuts here: 
											} // z cut
										} // if (deltaM < 0.17)
									} // if (sqrt(vc2[0]*vc2[0] + vc2[1]*vc2[1])<0.1 && vc2[2] <0.1)
								} // if (itPS3->charge()!=itK1->charge() && itPS3!=itP2 && itPS3!=itK1 )
							} // end of PS3 loop
						} // if (abs(MD0-1.9)<0.3)
					} // if ( sqrt (vc[0]*vc[0] + vc[1]*vc[1])<0.1 && vc[2] < 0.1)
				} // if ( itP2 !=itK1 && itP2->pt() > 0.5 )
                    	} // end of P2 loop
		} // if ( itK1->pt() > 0.5) 
        }//end of K1 Pt cut
} // end of track size cut


// if (VtxFound2)	{cout<<"Outer: MDstar = "<<MDstar<<"	MD0 = "<<MD0<<endl;}

} /// DmesonProduction = true;


}//DemoAnalyzer ends


inline double invMass(double p1,double p1x, double p1y, double p1z, double m1 , double p2, double p2x, double p2y, double p2z, double m2)
{
    s= sqrt(   m1*m1 + m2*m2 + 2.0*( sqrt( ( m1*m1 + p1 * p1 ) * ( m2*m2 + p2 * p2 ) ) - ( p1x * p2x + p1y * p2y + p1z * p2z ) ) ) ;
    return s;
}

// ------------ method called once each job just before starting event loop  ------------
void 
DemoAnalyzer::beginJob()
{

}

// ------------ method called once each job just after ending the event loop  ------------
void 
DemoAnalyzer::endJob() 
{
}

//define this as a plug-in
DEFINE_FWK_MODULE(DemoAnalyzer);

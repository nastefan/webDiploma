g++ -o main.exe VertexFitterNew.C libCLHEP.a libtLite.a `root-config --glibs --cflags` -g
./main.exe


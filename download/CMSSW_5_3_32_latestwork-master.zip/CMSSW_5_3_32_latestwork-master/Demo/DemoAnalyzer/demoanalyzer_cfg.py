import FWCore.ParameterSet.Config as cms
from RecoMuon.TrackingTools.MuonServiceProxy_cff import *
import FWCore.ParameterSet.Types as CfgTypes
import FWCore.PythonUtilities.LumiList as LumiList
import FWCore.Utilities.FileUtils as FileUtils
#import PhysicsTools.PythonAnalysis.LumiList as LumiList
import FWCore.PythonUtilities.LumiList as LumiList

process = cms.Process("Demo")
process.load("TrackingTools/TransientTrack/TransientTrackBuilder_cfi")
process.load('Configuration.Geometry.GeometryIdeal_cff')
process.load("Configuration.StandardSequences.MagneticField_cff")
process.load('Configuration.StandardSequences.FrontierConditions_GlobalTag_cff')
process.GlobalTag.connect = cms.string('sqlite_file:/cvmfs/cms-opendata-conddb.cern.ch/FT_53_LV5_AN1_RUNA.db')
process.GlobalTag.globaltag = 'FT_53_LV5_AN1::All'

# intialize MessageLogger and output report

process.load("FWCore.MessageLogger.MessageLogger_cfi")
#process.MessageLogger.cerr.threshold = 'INFO'
process.MessageLogger.cerr.suppressWarning = cms.untracked.vstring('DemoAnalyzer')
#process.MessageLogger.categories.append('Demo')
process.MessageLogger.cerr.FwkReport.reportEvery = 1000

  
#process.options   = cms.untracked.PSet( wantSummary = cms.untracked.bool(False) )
                                        
# set the maximum number of events to be processed here
process.maxEvents = cms.untracked.PSet( input = cms.untracked.int32(100000))

#goodJSON = '/afs/desy.de/user/s/stefan/CMSPhysic/FromIrene/data_files/Cert_136033-149442_7TeV_Apr21ReReco_Collisions10_JSON_v2.txt'
goodJSON = '/home/cms-opendata/Dmesons/CMSSW_5_3_32/src/Cert_160404-180252_7TeV_ReRecoNov08_Collisions11_JSON.txt'
#goodJSON = '/afs/desy.de/user/s/stefan/CMSPhysic/FromIrene/data_files/Cert_136033-149442_7TeV_Apr21ReReco_Collisions10_JSON_v2.txt'

myLumis = LumiList.LumiList(filename = goodJSON).getCMSSWString().split(',')


##files2010data = FileUtils.loadListFromFile ('/afs/desy.de/user/s/stefan/CMSPhysic/FromBridget/ForJpsi/CMSSW_4_2_8/src/MC2010_MinBias.txt')
#Good files: 
### for D-mesons analysis: 
#files2010data = FileUtils.loadListFromFile ('/afs/desy.de/user/s/stefan/CMSPhysic/FromBridget/LatestCode/CMSSW_4_2_8/src/MinBsData0000.txt')
#files2010data = FileUtils.loadListFromFile ('/home/cms-opendata/Dmesons/CMSSW_5_3_32/src/MinBsData0000_test.txt');
files2010data = FileUtils.loadListFromFile ('/home/cms-opendata/Dmesons/CMSSW_5_3_32/src/CMS_Run2011A_MuOnia_AOD_12Oct2013-v1_210000_file_index.txt');
#files2010data = FileUtils.loadListFromFile ('/home/cms-opendata/Dmesons/CMSSW_5_3_32/src/CMS_Run2011A_MinimumBias_AOD_12Oct2013-v1_20001_file_index.txt');


### for J/Psi analysis:
#files2010data = FileUtils.loadListFromFile ('/afs/desy.de/user/s/stefan/CMSPhysic/FromBridget/LatestCode/CMSSW_4_2_8/src/MuoniaData0000.txt')


process.source = cms.Source("PoolSource",
    # replace 'myfile.root' with the source file you want to use
    fileNames = cms.untracked.vstring(*files2010data),
    ### file from my normal MC, works only on SL6	
    #fileNames = cms.untracked.vstring('file:/afs/desy.de/group/zeus/pool/stefan/tests/mc/00F4B9E9-D678-DF11-83F4-001A4BA92974.root') 
    # file from DESY tier2 : dataset=/MinBias_TuneZ2star_HFshowerLibrary_7TeV_pythia6/Summer12-LowPU2010_DR42_NoPileUp_START42_V17C-v1/GEN-SIM-RECO	
    ##fileNames = cms.untracked.vstring('file:/afs/desy.de/group/zeus/pool/stefan/tests/mc/F011D31C-EA12-E211-A1C0-003048678F8A.root')		
    #,
    #skipEvents=cms.untracked.uint32(21000)	
)
'''
process.source = cms.Source("PoolSource",
    # replace 'myfile.root' with the source file you want to use
    #fileNames = cms.untracked.vstring('root://eospublic.cern.ch//eos/opendata/cms/Run2010B/Mu/AOD/Apr21ReReco-v1/0000/00459D48-EB70-E011-AF09-90E6BA19A252.root'
    fileNames = cms.untracked.vstring('file:/pnfs/desy.de/cms/tier2/store/mc/Summer10/MinBias_TuneD6T_7TeV-pythia6/GEN-SIM-RECODEBUG/START36_V10_SP10-v1/0003/00F4B9E9-D678-DF11-83F4-001A4BA92974.root'
    )
)
'''

    
#process.source.lumisToProcess=cms.untracked.VLuminosityBlockRange()
#process.source.lumisToProcess.extend(myLumis)

# this would be the "unofficial" way, which works and is an alternative
#please un-comment the import CfgTypes and PhysicsTools.PythonAnalysis.LumiList
#to use it.Also comment out the FWCore.PythonUtilities.Lumilist
#   (needs to be placed *after* the process.source input file definition!)

#SL6
process.source.lumisToProcess = CfgTypes.untracked(CfgTypes.VLuminosityBlockRange())
process.source.lumisToProcess.extend(myLumis)





process.demo = cms.EDAnalyzer('DemoAnalyzer'
)

# change this output file name according to input file
process.TFileService = cms.Service("TFileService",
                                       fileName = cms.string('OutputMERGERS.root')
                                   )

process.p = cms.Path(process.demo)

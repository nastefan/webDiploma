#include "TCanvas.h"
#include "TMath.h"
#include "TFile.h"
#include "TDirectory.h"
#include "TKey.h"
#include "TROOT.h"
//#include "TIter.h"
#include <iostream>	// changed by N.Stefaniuk
#include <iomanip>	// changed by N.Stefaniuk
// #include </data/zenith223a/dbot/Gut_Code_PhD/anadir/analysis_macros/inc/own_histos_danny_dimuon_Xsection_total.h>	// changed by N.Stefaniuk
// #include </data/zenith234d/stefan/GutCode/anadir/analysis_macros/inc/own_histos_danny_dimuon_Xsection_total.h>	// changed by N.Stefaniuk
#include </nfs/dust/zeus/group/stefan/test2/GoodCodeGit/anadir/analysis_macros/inc/own_histos_danny_dimuon_Xsection_total.h>

using namespace std;

void oli_to_danny_Xsection2_total(Bool_t slowme = false){
  cout<<"slowme is: "<<1*slowme<<endl;
  
  // Int_t obj_size_v          = 10000;
  // Int_t obj_size_h          = 1;
  Int_t DIMuon_folder_size  = 0;
 
  TH1D *obj[10000][1];
  
  // initialise histogram array:
  for(Int_t vorne = 0; vorne<10000; vorne++){
    for(Int_t hinten = 0; hinten<1; hinten++) obj[vorne][hinten] = 0;
  }
  //test histos reset start:

  h_etex2ir_all                                      = 0;
  h_dimuxsecpt_all                                   = 0;
  h_dimuxseceta_all                                  = 0;
  h_dimuxsecfinders_all                              = 0;
  h_dimuxsecdr_all                                   = 0;
  h_dimuxsecdphi_all                                 = 0;
  h_mcdimumass1bin_true_hfl_mu_all                   = 0;
  h_mcdimuxsecPt_true_hfl_mu_all                     = 0;
  h_mcdimuxsecEta_true_hfl_mu_all                    = 0;
  h_mcdimuxsecFinders_true_hfl_mu_all                = 0;
  h_mcdimuxsecDR_true_hfl_mu_all                     = 0;
  h_mcdimuxsecDphi_true_hfl_mu_all                   = 0;

  h_etex2ir_lm_us                                    = 0;
  h_dimuxsecpt_lm_us                                 = 0;
  h_dimuxseceta_lm_us                                = 0;
  h_dimuxsecfinders_lm_us                            = 0;
  h_dimuxsecdr_lm_us                                 = 0;
  h_dimuxsecdphi_lm_us                               = 0;
  h_mcdimumass1bin_true_hfl_mu_lm_us                 = 0;
  h_mcdimuxsecPt_true_hfl_mu_lm_us                   = 0;
  h_mcdimuxsecEta_true_hfl_mu_lm_us                  = 0;
  h_mcdimuxsecFinders_true_hfl_mu_lm_us              = 0;
  h_mcdimuxsecDR_true_hfl_mu_lm_us                   = 0;
  h_mcdimuxsecDphi_true_hfl_mu_lm_us                 = 0;

  h_etex2ir_lm_ls                                    = 0;
  h_dimuxsecpt_lm_ls                                 = 0;
  h_dimuxseceta_lm_ls                                = 0;
  h_dimuxsecfinders_lm_ls                            = 0;
  h_dimuxsecdr_lm_ls                                 = 0;
  h_dimuxsecdphi_lm_ls                               = 0;
  h_mcdimumass1bin_true_hfl_mu_lm_us                 = 0;
  h_mcdimuxsecPt_true_hfl_mu_lm_ls                   = 0;
  h_mcdimuxsecEta_true_hfl_mu_lm_ls                  = 0;
  h_mcdimuxsecFinders_true_hfl_mu_lm_ls              = 0;
  h_mcdimuxsecDR_true_hfl_mu_lm_ls                   = 0;
  h_mcdimuxsecDphi_true_hfl_mu_lm_ls                 = 0;

  h_etex2ir_hm_us                                    = 0;
  h_dimuxsecpt_hm_us                                 = 0;
  h_dimuxseceta_hm_us                                = 0;
  h_dimuxsecfinders_hm_us                            = 0;
  h_dimuxsecdr_hm_us                                 = 0;
  h_dimuxsecdphi_hm_us                               = 0;
  h_mcdimumass1bin_true_hfl_mu_hm_us                 = 0;
  h_mcdimuxsecPt_true_hfl_mu_hm_us                   = 0;
  h_mcdimuxsecEta_true_hfl_mu_hm_us                  = 0;
  h_mcdimuxsecFinders_true_hfl_mu_hm_us              = 0;
  h_mcdimuxsecDR_true_hfl_mu_hm_us                   = 0;
  h_mcdimuxsecDphi_true_hfl_mu_hm_us                 = 0;

  h_etex2ir_hm_ls                                    = 0;
  h_dimuxsecpt_hm_ls                                 = 0;
  h_dimuxseceta_hm_ls                                = 0;
  h_dimuxsecfinders_hm_ls                            = 0;
  h_dimuxsecdr_hm_ls                                 = 0;
  h_dimuxsecdphi_hm_ls                               = 0;
  h_mcdimumass1bin_true_hfl_mu_hm_ls                 = 0;
  h_mcdimuxsecPt_true_hfl_mu_hm_ls                   = 0;
  h_mcdimuxsecEta_true_hfl_mu_hm_ls                  = 0;
  h_mcdimuxsecFinders_true_hfl_mu_hm_ls              = 0;
  h_mcdimuxsecDR_true_hfl_mu_hm_ls                   = 0;
  h_mcdimuxsecDphi_true_hfl_mu_hm_ls                 = 0;

  h_etex2ir_lm_us_is                                 = 0;
  h_dimuxsecpt_lm_us_is                              = 0;
  h_dimuxseceta_lm_us_is                             = 0;
  h_dimuxsecfinders_lm_us_is                         = 0;
  h_dimuxsecdr_lm_us_is                              = 0;
  h_dimuxsecdphi_lm_us_is                            = 0;
  h_mcdimumass1bin_true_hfl_mu_lm_us_is              = 0;
  h_mcdimuxsecPt_true_hfl_mu_lm_us_is                = 0;
  h_mcdimuxsecEta_true_hfl_mu_lm_us_is               = 0;
  h_mcdimuxsecFinders_true_hfl_mu_lm_us_is           = 0;
  h_mcdimuxsecDR_true_hfl_mu_lm_us_is                = 0;
  h_mcdimuxsecDphi_true_hfl_mu_lm_us_is              = 0;

  h_etex2ir_lm_ls_is                                 = 0;
  h_dimuxsecpt_lm_ls_is                              = 0;
  h_dimuxseceta_lm_ls_is                             = 0;
  h_dimuxsecfinders_lm_ls_is                         = 0;
  h_dimuxsecdr_lm_ls_is                              = 0;
  h_dimuxsecdphi_lm_ls_is                            = 0;
  h_mcdimumass1bin_true_hfl_mu_lm_ls_is              = 0;
  h_mcdimuxsecPt_true_hfl_mu_lm_ls_is                = 0;
  h_mcdimuxsecEta_true_hfl_mu_lm_ls_is               = 0;
  h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is           = 0;
  h_mcdimuxsecDR_true_hfl_mu_lm_ls_is                = 0;
  h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is              = 0;

  h_etex2ir_hm_us_is                                 = 0;
  h_dimuxsecpt_hm_us_is                              = 0;
  h_dimuxseceta_hm_us_is                             = 0;
  h_dimuxsecfinders_hm_us_is                         = 0;
  h_dimuxsecdr_hm_us_is                              = 0;
  h_dimuxsecdphi_hm_us_is                            = 0;
  h_mcdimumass1bin_true_hfl_mu_hm_us_is              = 0;
  h_mcdimuxsecPt_true_hfl_mu_hm_us_is                = 0;
  h_mcdimuxsecEta_true_hfl_mu_hm_us_is               = 0;
  h_mcdimuxsecFinders_true_hfl_mu_hm_us_is           = 0;
  h_mcdimuxsecDR_true_hfl_mu_hm_us_is                = 0;
  h_mcdimuxsecDphi_true_hfl_mu_hm_us_is              = 0;

  h_etex2ir_hm_ls_is                                 = 0;
  h_dimuxsecpt_hm_ls_is                              = 0;
  h_dimuxseceta_hm_ls_is                             = 0;
  h_dimuxsecfinders_hm_ls_is                         = 0;
  h_dimuxsecdr_hm_ls_is                              = 0;
  h_dimuxsecdphi_hm_ls_is                            = 0;
  h_mcdimumass1bin_true_hfl_mu_hm_ls_is              = 0;
  h_mcdimuxsecPt_true_hfl_mu_hm_ls_is                = 0;
  h_mcdimuxsecEta_true_hfl_mu_hm_ls_is               = 0;
  h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is           = 0;
  h_mcdimuxsecDR_true_hfl_mu_hm_ls_is                = 0;
  h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is              = 0;

  h_etex2ir_lm_us_nis                                = 0;
  h_dimuxsecpt_lm_us_nis                             = 0;
  h_dimuxseceta_lm_us_nis                            = 0;
  h_dimuxsecfinders_lm_us_nis                        = 0;
  h_dimuxsecdr_lm_us_nis                             = 0;
  h_dimuxsecdphi_lm_us_nis                           = 0;
  h_mcdimumass1bin_true_hfl_mu_lm_us_nis             = 0;
  h_mcdimuxsecPt_true_hfl_mu_lm_us_nis               = 0;
  h_mcdimuxsecEta_true_hfl_mu_lm_us_nis              = 0;
  h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis          = 0;
  h_mcdimuxsecDR_true_hfl_mu_lm_us_nis               = 0;
  h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis             = 0;
 
  h_etex2ir_lm_ls_nis                                = 0;
  h_dimuxsecpt_lm_ls_nis                             = 0;
  h_dimuxseceta_lm_ls_nis                            = 0;
  h_dimuxsecfinders_lm_ls_nis                        = 0;
  h_dimuxsecdr_lm_ls_nis                             = 0;
  h_dimuxsecdphi_lm_ls_nis                           = 0;
  h_mcdimumass1bin_true_hfl_mu_lm_ls_nis             = 0;
  h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis               = 0;
  h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis              = 0;
  h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis          = 0;
  h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis               = 0;
  h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis             = 0;

  h_etex2ir_hm_us_nis                                = 0;
  h_dimuxsecpt_hm_us_nis                             = 0;
  h_dimuxseceta_hm_us_nis                            = 0;
  h_dimuxsecfinders_hm_us_nis                        = 0;
  h_dimuxsecdr_hm_us_nis                             = 0;
  h_dimuxsecdphi_hm_us_nis                           = 0;
  h_mcdimumass1bin_true_hfl_mu_hm_us_nis             = 0;
  h_mcdimuxsecPt_true_hfl_mu_hm_us_nis               = 0;
  h_mcdimuxsecEta_true_hfl_mu_hm_us_nis              = 0;
  h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis          = 0;
  h_mcdimuxsecDR_true_hfl_mu_hm_us_nis               = 0;
  h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis             = 0;

  h_etex2ir_hm_ls_nis                                = 0;
  h_dimuxsecpt_hm_ls_nis                             = 0;
  h_dimuxseceta_hm_ls_nis                            = 0;
  h_dimuxsecfinders_hm_ls_nis                        = 0;
  h_dimuxsecdr_hm_ls_nis                             = 0;
  h_dimuxsecdphi_hm_ls_nis                           = 0;
  h_mcdimumass1bin_true_hfl_mu_hm_ls_nis             = 0;
  h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis               = 0;
  h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis              = 0;
  h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis          = 0;
  h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis               = 0;
  h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis             = 0;

//test histos reset end.

  Int_t count1 = 0;
  
  TString previous_obj, histonamebuffer;
  TString outfile, infile;
  TKey *key;
  TFile *_file0;
  
  infile = "histos.root";
  
  if( _file0 = new TFile(infile,"READ") ) cout << "file opened "<< infile << endl;

  outfile = "oli2danny_out.root";
  
  _file0->ls();
  _file0->cd("Histograms/DIMuon");
  
  cout<<"getlist is: "<<endl;
  
  TIter next( gDirectory->GetListOfKeys() );
  while ((key = (TKey *) next())) {
    obj[count1][0] = (TH1D*) gDirectory->Get(key->GetName()); // copy object to memory
    obj[count1][0]->SetDirectory(0);
    obj[count1][0]->AddDirectory(kFALSE);
   
 // do something with obj
    if( previous_obj==key->GetName() ) {

      continue;

    } 
    
    previous_obj = key->GetName();
    count1++;
  }
  cout<<"Directory DIMuon left at count1= "<<count1<<endl;
  DIMuon_folder_size = count1;
  cout<<"DIMuon_folder_size = "<<DIMuon_folder_size<<endl;
 
  TFile * file = new TFile(outfile,"RECREATE");
  for( Int_t i=0; i< count1; ++i) {
    histonamebuffer = obj[i][0]->GetName();
    obj[i][0]->AddDirectory(kFALSE);
  
    if( i < DIMuon_folder_size ){

      if(histonamebuffer=="etex2ir")                      h_etex2ir_all        = obj[i][0];   
      if(histonamebuffer=="etex2ir_is_lu")                h_etex2ir_lm_us_is   = obj[i][0];   
      if(histonamebuffer=="etex2ir_is_ll")                h_etex2ir_lm_ls_is   = obj[i][0];   
      if(histonamebuffer=="etex2ir_is_hu")                h_etex2ir_hm_us_is   = obj[i][0];   
      if(histonamebuffer=="etex2ir_is_hl")                h_etex2ir_hm_ls_is   = obj[i][0];   
      if(histonamebuffer=="etex2ir_nis_lu")               h_etex2ir_lm_us_nis  = obj[i][0];   
      if(histonamebuffer=="etex2ir_nis_ll")               h_etex2ir_lm_ls_nis  = obj[i][0];   
      if(histonamebuffer=="etex2ir_nis_hu")               h_etex2ir_hm_us_nis  = obj[i][0];   
      if(histonamebuffer=="etex2ir_nis_hl")               h_etex2ir_hm_ls_nis  = obj[i][0];   
    
      if(histonamebuffer=="dimuxsecpt")                   h_dimuxsecpt_all        = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_is_lu")             h_dimuxsecpt_lm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_is_ll")             h_dimuxsecpt_lm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_is_hu")             h_dimuxsecpt_hm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_is_hl")             h_dimuxsecpt_hm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_nis_lu")            h_dimuxsecpt_lm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_nis_ll")            h_dimuxsecpt_lm_ls_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_nis_hu")            h_dimuxsecpt_hm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecpt_nis_hl")            h_dimuxsecpt_hm_ls_nis  = obj[i][0];   

      if(histonamebuffer=="dimuxseceta")                  h_dimuxseceta_all        = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_is_lu")            h_dimuxseceta_lm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_is_ll")            h_dimuxseceta_lm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_is_hu")            h_dimuxseceta_hm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_is_hl")            h_dimuxseceta_hm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_nis_lu")           h_dimuxseceta_lm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_nis_ll")           h_dimuxseceta_lm_ls_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_nis_hu")           h_dimuxseceta_hm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxseceta_nis_hl")           h_dimuxseceta_hm_ls_nis  = obj[i][0];   

      if(histonamebuffer=="dimuxsecfinders")              h_dimuxsecfinders_all        = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_is_lu")        h_dimuxsecfinders_lm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_is_ll")        h_dimuxsecfinders_lm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_is_hu")        h_dimuxsecfinders_hm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_is_hl")        h_dimuxsecfinders_hm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_nis_lu")       h_dimuxsecfinders_lm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_nis_ll")       h_dimuxsecfinders_lm_ls_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_nis_hu")       h_dimuxsecfinders_hm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecfinders_nis_hl")       h_dimuxsecfinders_hm_ls_nis  = obj[i][0];   

      if(histonamebuffer=="dimuxsecdr")                   h_dimuxsecdr_all        = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_is_lu")             h_dimuxsecdr_lm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_is_ll")             h_dimuxsecdr_lm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_is_hu")             h_dimuxsecdr_hm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_is_hl")             h_dimuxsecdr_hm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_nis_lu")            h_dimuxsecdr_lm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_nis_ll")            h_dimuxsecdr_lm_ls_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_nis_hu")            h_dimuxsecdr_hm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecdr_nis_hl")            h_dimuxsecdr_hm_ls_nis  = obj[i][0];   

      if(histonamebuffer=="dimuxsecdphi")                 h_dimuxsecdphi_all        = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_is_lu")           h_dimuxsecdphi_lm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_is_ll")           h_dimuxsecdphi_lm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_is_hu")           h_dimuxsecdphi_hm_us_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_is_hl")           h_dimuxsecdphi_hm_ls_is   = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_nis_lu")          h_dimuxsecdphi_lm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_nis_ll")          h_dimuxsecdphi_lm_ls_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_nis_hu")          h_dimuxsecdphi_hm_us_nis  = obj[i][0];   
      if(histonamebuffer=="dimuxsecdphi_nis_hl")          h_dimuxsecdphi_hm_ls_nis  = obj[i][0];   

 
     
// special treatment for mc histos - need to fake these in data:

      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_all        = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_all == 0       && h_etex2ir_all       !=0) h_mcdimumass1bin_true_hfl_mu_all =       (TH1D*) h_etex2ir_all -> Clone(      "h_mcdimumass1bin_true_hfl_mu_all"      );
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_lm_us_is   = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_lm_us_is == 0  && h_etex2ir_lm_us_is  !=0) h_mcdimumass1bin_true_hfl_mu_lm_us_is =  (TH1D*) h_etex2ir_lm_us_is -> Clone( "h_mcdimumass1bin_true_hfl_mu_lm_us_is" );
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_lm_ls_is   = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_lm_ls_is == 0  && h_etex2ir_lm_ls_is  !=0) h_mcdimumass1bin_true_hfl_mu_lm_ls_is =  (TH1D*) h_etex2ir_lm_ls_is -> Clone( "h_mcdimumass1bin_true_hfl_mu_lm_ls_is" );
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_hm_us_is   = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_hm_us_is == 0  && h_etex2ir_hm_us_is  !=0) h_mcdimumass1bin_true_hfl_mu_hm_us_is =  (TH1D*) h_etex2ir_hm_us_is -> Clone( "h_mcdimumass1bin_true_hfl_mu_hm_us_is" );
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_hm_ls_is   = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_hm_ls_is == 0  && h_etex2ir_hm_ls_is  !=0) h_mcdimumass1bin_true_hfl_mu_hm_ls_is =  (TH1D*) h_etex2ir_hm_ls_is -> Clone( "h_mcdimumass1bin_true_hfl_mu_hm_ls_is" );
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_lm_us_nis  = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_lm_us_nis == 0 && h_etex2ir_lm_us_nis !=0) h_mcdimumass1bin_true_hfl_mu_lm_us_nis = (TH1D*) h_etex2ir_lm_us_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_us_nis"); 
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_lm_ls_nis  = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_lm_ls_nis == 0 && h_etex2ir_lm_ls_nis !=0) h_mcdimumass1bin_true_hfl_mu_lm_ls_nis = (TH1D*) h_etex2ir_lm_ls_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_ls_nis"); 
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_hm_us_nis  = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_hm_us_nis == 0 && h_etex2ir_hm_us_nis !=0) h_mcdimumass1bin_true_hfl_mu_hm_us_nis = (TH1D*) h_etex2ir_hm_us_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_us_nis"); 
      if(histonamebuffer=="mcdimumass1bin_true_hfl_mu")  h_mcdimumass1bin_true_hfl_mu_hm_ls_nis  = obj[i][0];   
      if(h_mcdimumass1bin_true_hfl_mu_hm_ls_nis == 0 && h_etex2ir_hm_ls_nis !=0) h_mcdimumass1bin_true_hfl_mu_hm_ls_nis = (TH1D*) h_etex2ir_hm_ls_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_ls_nis"); 


      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_all        = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_all == 0       && h_dimuxsecpt_all       !=0) h_mcdimuxsecPt_true_hfl_mu_all =       (TH1D*) h_dimuxsecpt_all -> Clone(      "h_mcdimuxsecPt_true_hfl_mu_all"      );
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_lm_us_is   = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_lm_us_is == 0  && h_dimuxsecpt_lm_us_is  !=0) h_mcdimuxsecPt_true_hfl_mu_lm_us_is =  (TH1D*) h_dimuxsecpt_lm_us_is -> Clone( "h_mcdimuxsecPt_true_hfl_mu_lm_us_is" );
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_lm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_lm_ls_is == 0  && h_dimuxsecpt_lm_ls_is  !=0) h_mcdimuxsecPt_true_hfl_mu_lm_ls_is =  (TH1D*) h_dimuxsecpt_lm_ls_is -> Clone( "h_mcdimuxsecPt_true_hfl_mu_lm_ls_is" );
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_hm_us_is   = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_hm_us_is == 0  && h_dimuxsecpt_hm_us_is  !=0) h_mcdimuxsecPt_true_hfl_mu_hm_us_is =  (TH1D*) h_dimuxsecpt_hm_us_is -> Clone( "h_mcdimuxsecPt_true_hfl_mu_hm_us_is" );
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_hm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_hm_ls_is == 0  && h_dimuxsecpt_hm_ls_is  !=0) h_mcdimuxsecPt_true_hfl_mu_hm_ls_is =  (TH1D*) h_dimuxsecpt_hm_ls_is -> Clone( "h_mcdimuxsecPt_true_hfl_mu_hm_ls_is" );
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_lm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_lm_us_nis == 0 && h_dimuxsecpt_lm_us_nis !=0) h_mcdimuxsecPt_true_hfl_mu_lm_us_nis = (TH1D*) h_dimuxsecpt_lm_us_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis == 0 && h_dimuxsecpt_lm_ls_nis !=0) h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis = (TH1D*) h_dimuxsecpt_lm_ls_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis"); 
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_hm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_hm_us_nis == 0 && h_dimuxsecpt_hm_us_nis !=0) h_mcdimuxsecPt_true_hfl_mu_hm_us_nis = (TH1D*) h_dimuxsecpt_hm_us_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecPt_true_hfl_mu")  h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis == 0 && h_dimuxsecpt_hm_ls_nis !=0) h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis = (TH1D*) h_dimuxsecpt_hm_ls_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis"); 

      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_all        = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_all == 0       && h_dimuxseceta_all       !=0) h_mcdimuxsecEta_true_hfl_mu_all =       (TH1D*) h_dimuxseceta_all -> Clone(      "h_mcdimuxsecEta_true_hfl_mu_all"      );
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_lm_us_is   = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_lm_us_is == 0  && h_dimuxseceta_lm_us_is  !=0) h_mcdimuxsecEta_true_hfl_mu_lm_us_is =  (TH1D*) h_dimuxseceta_lm_us_is -> Clone( "h_mcdimuxsecEta_true_hfl_mu_lm_us_is" );
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_lm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_lm_ls_is == 0  && h_dimuxseceta_lm_ls_is  !=0) h_mcdimuxsecEta_true_hfl_mu_lm_ls_is =  (TH1D*) h_dimuxseceta_lm_ls_is -> Clone( "h_mcdimuxsecEta_true_hfl_mu_lm_ls_is" );
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_hm_us_is   = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_hm_us_is == 0  && h_dimuxseceta_hm_us_is  !=0) h_mcdimuxsecEta_true_hfl_mu_hm_us_is =  (TH1D*) h_dimuxseceta_hm_us_is -> Clone( "h_mcdimuxsecEta_true_hfl_mu_hm_us_is" );
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_hm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_hm_ls_is == 0  && h_dimuxseceta_hm_ls_is  !=0) h_mcdimuxsecEta_true_hfl_mu_hm_ls_is =  (TH1D*) h_dimuxseceta_hm_ls_is -> Clone( "h_mcdimuxsecEta_true_hfl_mu_hm_ls_is" );
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_lm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_lm_us_nis == 0 && h_dimuxseceta_lm_us_nis !=0) h_mcdimuxsecEta_true_hfl_mu_lm_us_nis = (TH1D*) h_dimuxseceta_lm_us_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis == 0 && h_dimuxseceta_lm_ls_nis !=0) h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis = (TH1D*) h_dimuxseceta_lm_ls_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis"); 
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_hm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_hm_us_nis == 0 && h_dimuxseceta_hm_us_nis !=0) h_mcdimuxsecEta_true_hfl_mu_hm_us_nis = (TH1D*) h_dimuxseceta_hm_us_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecEta_true_hfl_mu")  h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis == 0 && h_dimuxseceta_hm_ls_nis !=0) h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis = (TH1D*) h_dimuxseceta_hm_ls_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis"); 

      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_all        = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_all == 0       && h_dimuxsecfinders_all       !=0) h_mcdimuxsecFinders_true_hfl_mu_all =       (TH1D*) h_dimuxsecfinders_all -> Clone(      "h_mcdimuxsecFinders_true_hfl_mu_all"      );
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_lm_us_is   = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_lm_us_is == 0  && h_dimuxsecfinders_lm_us_is  !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_us_is =  (TH1D*) h_dimuxsecfinders_lm_us_is -> Clone( "h_mcdimuxsecFinders_true_hfl_mu_lm_us_is" );
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is == 0  && h_dimuxsecfinders_lm_ls_is  !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is =  (TH1D*) h_dimuxsecfinders_lm_ls_is -> Clone( "h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is" );
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_hm_us_is   = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_hm_us_is == 0  && h_dimuxsecfinders_hm_us_is  !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_us_is =  (TH1D*) h_dimuxsecfinders_hm_us_is -> Clone( "h_mcdimuxsecFinders_true_hfl_mu_hm_us_is" );
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is == 0  && h_dimuxsecfinders_hm_ls_is  !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is =  (TH1D*) h_dimuxsecfinders_hm_ls_is -> Clone( "h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is" );
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis == 0 && h_dimuxsecfinders_lm_us_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis = (TH1D*) h_dimuxsecfinders_lm_us_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis == 0 && h_dimuxsecfinders_lm_ls_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis = (TH1D*) h_dimuxsecfinders_lm_ls_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis"); 
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis == 0 && h_dimuxsecfinders_hm_us_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis = (TH1D*) h_dimuxsecfinders_hm_us_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecFinders_true_hfl_mu")  h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis == 0 && h_dimuxsecfinders_hm_ls_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis = (TH1D*) h_dimuxsecfinders_hm_ls_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis"); 

  
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_all        = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_all == 0       && h_dimuxsecdr_all       !=0) h_mcdimuxsecDR_true_hfl_mu_all =       (TH1D*) h_dimuxsecdr_all -> Clone(      "h_mcdimuxsecDR_true_hfl_mu_all"      );
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_lm_us_is   = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_lm_us_is == 0  && h_dimuxsecdr_lm_us_is  !=0) h_mcdimuxsecDR_true_hfl_mu_lm_us_is =  (TH1D*) h_dimuxsecdr_lm_us_is -> Clone( "h_mcdimuxsecDR_true_hfl_mu_lm_us_is" );
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_lm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_lm_ls_is == 0  && h_dimuxsecdr_lm_ls_is  !=0) h_mcdimuxsecDR_true_hfl_mu_lm_ls_is =  (TH1D*) h_dimuxsecdr_lm_ls_is -> Clone( "h_mcdimuxsecDR_true_hfl_mu_lm_ls_is" );
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_hm_us_is   = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_hm_us_is == 0  && h_dimuxsecdr_hm_us_is  !=0) h_mcdimuxsecDR_true_hfl_mu_hm_us_is =  (TH1D*) h_dimuxsecdr_hm_us_is -> Clone( "h_mcdimuxsecDR_true_hfl_mu_hm_us_is" );
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_hm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_hm_ls_is == 0  && h_dimuxsecdr_hm_ls_is  !=0) h_mcdimuxsecDR_true_hfl_mu_hm_ls_is =  (TH1D*) h_dimuxsecdr_hm_ls_is -> Clone( "h_mcdimuxsecDR_true_hfl_mu_hm_ls_is" );
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_lm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_lm_us_nis == 0 && h_dimuxsecdr_lm_us_nis !=0) h_mcdimuxsecDR_true_hfl_mu_lm_us_nis = (TH1D*) h_dimuxsecdr_lm_us_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis == 0 && h_dimuxsecdr_lm_ls_nis !=0) h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis = (TH1D*) h_dimuxsecdr_lm_ls_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis"); 
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_hm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_hm_us_nis == 0 && h_dimuxsecdr_hm_us_nis !=0) h_mcdimuxsecDR_true_hfl_mu_hm_us_nis = (TH1D*) h_dimuxsecdr_hm_us_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecDR_true_hfl_mu")  h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis == 0 && h_dimuxsecdr_hm_ls_nis !=0) h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis = (TH1D*) h_dimuxsecdr_hm_ls_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis"); 


      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu") h_mcdimuxsecDphi_true_hfl_mu_all        = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_all == 0       && h_dimuxsecdphi_all       !=0) h_mcdimuxsecDphi_true_hfl_mu_all =       (TH1D*) h_dimuxsecdphi_all -> Clone(      "h_mcdimuxsecDphi_true_hfl_mu_all"      );
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_lm_us_is   = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_lm_us_is == 0  && h_dimuxsecdphi_lm_us_is  !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_us_is =  (TH1D*) h_dimuxsecdphi_lm_us_is -> Clone( "h_mcdimuxsecDphi_true_hfl_mu_lm_us_is" );
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is == 0  && h_dimuxsecdphi_lm_ls_is  !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is =  (TH1D*) h_dimuxsecdphi_lm_ls_is -> Clone( "h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is" );
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_hm_us_is   = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_hm_us_is == 0  && h_dimuxsecdphi_hm_us_is  !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_us_is =  (TH1D*) h_dimuxsecdphi_hm_us_is -> Clone( "h_mcdimuxsecDphi_true_hfl_mu_hm_us_is" );
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is   = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is == 0  && h_dimuxsecdphi_hm_ls_is  !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is =  (TH1D*) h_dimuxsecdphi_hm_ls_is -> Clone( "h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is" );
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis == 0 && h_dimuxsecdphi_lm_us_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis = (TH1D*) h_dimuxsecdphi_lm_us_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis == 0 && h_dimuxsecdphi_lm_ls_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis = (TH1D*) h_dimuxsecdphi_lm_ls_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis"); 
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis  = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis == 0 && h_dimuxsecdphi_hm_us_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis = (TH1D*) h_dimuxsecdphi_hm_us_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis"); 
      if(histonamebuffer=="mcdimuxsecDphi_true_hfl_mu")  h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis  = obj[i][0];   
      if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis == 0 && h_dimuxsecdphi_hm_ls_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis = (TH1D*) h_dimuxsecdphi_hm_ls_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis"); 

    }

  }
    

  if(42 == 42) {
 

    if(h_etex2ir_all              !=0) file->Append(h_etex2ir_all         -> Clone("h_etex2ir_all"));
    if(h_dimuxsecpt_all           !=0) file->Append(h_dimuxsecpt_all      -> Clone("h_dimuxsecpt_all"));
    if(h_dimuxseceta_all          !=0) file->Append(h_dimuxseceta_all     -> Clone("h_dimuxseceta_all"));
    if(h_dimuxsecfinders_all      !=0) file->Append(h_dimuxsecfinders_all -> Clone("h_dimuxsecfinders_all"));
    if(h_dimuxsecdr_all           !=0) file->Append(h_dimuxsecdr_all      -> Clone("h_dimuxsecdr_all"));
    if(h_dimuxsecdphi_all         !=0) file->Append(h_dimuxsecdphi_all    -> Clone("h_dimuxsecdphi_all"));

    if(h_mcdimumass1bin_true_hfl_mu_all    !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_all    -> Clone("h_mcdimumass1bin_true_hfl_mu_all"));
    if(h_mcdimuxsecPt_true_hfl_mu_all      !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_all      -> Clone("h_mcdimuxsecPt_true_hfl_mu_all"));
    if(h_mcdimuxsecEta_true_hfl_mu_all     !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_all     -> Clone("h_mcdimuxsecEta_true_hfl_mu_all"));
    if(h_mcdimuxsecFinders_true_hfl_mu_all !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_all -> Clone("h_mcdimuxsecFinders_true_hfl_mu_all"));
    if(h_mcdimuxsecDR_true_hfl_mu_all      !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_all      -> Clone("h_mcdimuxsecDR_true_hfl_mu_all"));
    if(h_mcdimuxsecDphi_true_hfl_mu_all    !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_all    -> Clone("h_mcdimuxsecDphi_true_hfl_mu_all"));


// ***************************************************************************************
// produce and append pre-isolation histos:
// ***************************************************************************************

    if(h_etex2ir_lm_us_nis         !=0) h_etex2ir_lm_us         = (TH1D*) h_etex2ir_lm_us_nis         -> Clone("h_etex2ir_lm_us");
    if(h_dimuxsecpt_lm_us_nis      !=0) h_dimuxsecpt_lm_us      = (TH1D*) h_dimuxsecpt_lm_us_nis      -> Clone("h_dimuxsecpt_lm_us");
    if(h_dimuxseceta_lm_us_nis     !=0) h_dimuxseceta_lm_us     = (TH1D*) h_dimuxseceta_lm_us_nis     -> Clone("h_dimuxseceta_lm_us");
    if(h_dimuxsecfinders_lm_us_nis !=0) h_dimuxsecfinders_lm_us = (TH1D*) h_dimuxsecfinders_lm_us_nis -> Clone("h_dimuxsecfinders_lm_us");
    if(h_dimuxsecdr_lm_us_nis      !=0) h_dimuxsecdr_lm_us      = (TH1D*) h_dimuxsecdr_lm_us_nis      -> Clone("h_dimuxsecdr_lm_us");
    if(h_dimuxsecdphi_lm_us_nis    !=0) h_dimuxsecdphi_lm_us    = (TH1D*) h_dimuxsecdphi_lm_us_nis    -> Clone("h_dimuxsecdphi_lm_us");
 
    if(h_mcdimumass1bin_true_hfl_mu_lm_us_nis !=0) h_mcdimumass1bin_true_hfl_mu_lm_us = (TH1D*) h_mcdimumass1bin_true_hfl_mu_lm_us_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_us");
    if(h_mcdimuxsecPt_true_hfl_mu_lm_us_nis !=0) h_mcdimuxsecPt_true_hfl_mu_lm_us = (TH1D*) h_mcdimuxsecPt_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_us");
    if(h_mcdimuxsecEta_true_hfl_mu_lm_us_nis !=0) h_mcdimuxsecEta_true_hfl_mu_lm_us = (TH1D*) h_mcdimuxsecEta_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_us");
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_us = (TH1D*) h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_us");
    if(h_mcdimuxsecDR_true_hfl_mu_lm_us_nis !=0) h_mcdimuxsecDR_true_hfl_mu_lm_us = (TH1D*) h_mcdimuxsecDR_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_us");
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_us = (TH1D*) h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_us");


    if(h_etex2ir_lm_ls_nis    !=0) h_etex2ir_lm_ls            = (TH1D*) h_etex2ir_lm_ls_nis            -> Clone("h_etex2ir_lm_ls");
    if(h_dimuxsecpt_lm_ls_nis !=0) h_dimuxsecpt_lm_ls = (TH1D*) h_dimuxsecpt_lm_ls_nis -> Clone("h_dimuxsecpt_lm_ls");
    if(h_dimuxseceta_lm_ls_nis !=0) h_dimuxseceta_lm_ls = (TH1D*) h_dimuxseceta_lm_ls_nis -> Clone("h_dimuxseceta_lm_ls");
    if(h_dimuxsecfinders_lm_ls_nis !=0) h_dimuxsecfinders_lm_ls = (TH1D*) h_dimuxsecfinders_lm_ls_nis -> Clone("h_dimuxsecfinders_lm_ls");
    if(h_dimuxsecdr_lm_ls_nis !=0) h_dimuxsecdr_lm_ls = (TH1D*) h_dimuxsecdr_lm_ls_nis -> Clone("h_dimuxsecdr_lm_ls");
    if(h_dimuxsecdphi_lm_ls_nis !=0) h_dimuxsecdphi_lm_ls = (TH1D*) h_dimuxsecdphi_lm_ls_nis -> Clone("h_dimuxsecdphi_lm_ls");
   
    if(h_mcdimumass1bin_true_hfl_mu_lm_ls_nis !=0) h_mcdimumass1bin_true_hfl_mu_lm_ls = (TH1D*) h_mcdimumass1bin_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_ls");
    if(h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecPt_true_hfl_mu_lm_ls = (TH1D*) h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_ls");
    if(h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecEta_true_hfl_mu_lm_ls = (TH1D*) h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_ls");
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_ls = (TH1D*) h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_ls");
    if(h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecDR_true_hfl_mu_lm_ls = (TH1D*) h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_ls");
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_ls = (TH1D*) h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_ls");

    if(h_etex2ir_hm_us_nis         !=0) h_etex2ir_hm_us         = (TH1D*) h_etex2ir_hm_us_nis         -> Clone("h_etex2ir_hm_us");
    if(h_dimuxsecpt_hm_us_nis      !=0) h_dimuxsecpt_hm_us      = (TH1D*) h_dimuxsecpt_hm_us_nis      -> Clone("h_dimuxsecpt_hm_us");
    if(h_dimuxseceta_hm_us_nis     !=0) h_dimuxseceta_hm_us     = (TH1D*) h_dimuxseceta_hm_us_nis     -> Clone("h_dimuxseceta_hm_us");
    if(h_dimuxsecfinders_hm_us_nis !=0) h_dimuxsecfinders_hm_us = (TH1D*) h_dimuxsecfinders_hm_us_nis -> Clone("h_dimuxsecfinders_hm_us");
    if(h_dimuxsecdr_hm_us_nis      !=0) h_dimuxsecdr_hm_us      = (TH1D*) h_dimuxsecdr_hm_us_nis      -> Clone("h_dimuxsecdr_hm_us");
    if(h_dimuxsecdphi_hm_us_nis    !=0) h_dimuxsecdphi_hm_us    = (TH1D*) h_dimuxsecdphi_hm_us_nis    -> Clone("h_dimuxsecdphi_hm_us");

    if(h_mcdimumass1bin_true_hfl_mu_hm_us_nis !=0) h_mcdimumass1bin_true_hfl_mu_hm_us = (TH1D*) h_mcdimumass1bin_true_hfl_mu_hm_us_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_us");
    if(h_mcdimuxsecPt_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecPt_true_hfl_mu_hm_us = (TH1D*) h_mcdimuxsecPt_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_us");
    if(h_mcdimuxsecEta_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecEta_true_hfl_mu_hm_us = (TH1D*) h_mcdimuxsecEta_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_us");
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_us = (TH1D*) h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_us");
    if(h_mcdimuxsecDR_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecDR_true_hfl_mu_hm_us = (TH1D*) h_mcdimuxsecDR_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_us");
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_us = (TH1D*) h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_us");

// high mass like sign

    if(h_etex2ir_hm_ls_nis       !=0) h_etex2ir_hm_ls            = (TH1D*) h_etex2ir_hm_ls_nis            -> Clone("h_etex2ir_hm_ls");
    if(h_dimuxsecpt_hm_ls_nis        !=0) h_dimuxsecpt_hm_ls        = (TH1D*) h_dimuxsecpt_hm_ls_nis      -> Clone("h_dimuxsecpt_hm_ls");
    if(h_dimuxseceta_hm_ls_nis       !=0) h_dimuxseceta_hm_ls       = (TH1D*) h_dimuxseceta_hm_ls_nis     -> Clone("h_dimuxseceta_hm_ls");
    if(h_dimuxsecfinders_hm_ls_nis   !=0) h_dimuxsecfinders_hm_ls   = (TH1D*) h_dimuxsecfinders_hm_ls_nis -> Clone("h_dimuxsecfinders_hm_ls");
    if(h_dimuxsecdr_hm_ls_nis        !=0) h_dimuxsecdr_hm_ls        = (TH1D*) h_dimuxsecdr_hm_ls_nis -> Clone("h_dimuxsecdr_hm_ls");
    if(h_dimuxsecdphi_hm_ls_nis      !=0) h_dimuxsecdphi_hm_ls      = (TH1D*) h_dimuxsecdphi_hm_ls_nis -> Clone("h_dimuxsecdphi_hm_ls");
    if(h_mcdimumass1bin_true_hfl_mu_hm_ls_nis !=0) h_mcdimumass1bin_true_hfl_mu_hm_ls = (TH1D*) h_mcdimumass1bin_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_ls");
    if(h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecPt_true_hfl_mu_hm_ls = (TH1D*) h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_ls");
    if(h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecEta_true_hfl_mu_hm_ls = (TH1D*) h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_ls");
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_ls = (TH1D*) h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_ls");
    if(h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecDR_true_hfl_mu_hm_ls = (TH1D*) h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_ls");
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_ls = (TH1D*) h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_ls");

//Add is + nis to have nisandis:

    if(h_etex2ir_lm_us_nis         !=0) h_etex2ir_lm_us         -> Add(h_etex2ir_lm_us_is,h_etex2ir_lm_us_nis);
    if(h_dimuxsecpt_lm_us_nis      !=0) h_dimuxsecpt_lm_us      -> Add(h_dimuxsecpt_lm_us_is,h_dimuxsecpt_lm_us_nis);
    if(h_dimuxseceta_lm_us_nis     !=0) h_dimuxseceta_lm_us     -> Add(h_dimuxseceta_lm_us_is,h_dimuxseceta_lm_us_nis);
    if(h_dimuxsecfinders_lm_us_nis !=0) h_dimuxsecfinders_lm_us -> Add(h_dimuxsecfinders_lm_us_is,h_dimuxsecfinders_lm_us_nis);
    if(h_dimuxsecdr_lm_us_nis      !=0) h_dimuxsecdr_lm_us      -> Add(h_dimuxsecdr_lm_us_is,h_dimuxsecdr_lm_us_nis);
    if(h_dimuxsecdphi_lm_us_nis    !=0) h_dimuxsecdphi_lm_us    -> Add(h_dimuxsecdphi_lm_us_is,h_dimuxsecdphi_lm_us_nis);

    if(h_mcdimumass1bin_true_hfl_mu_lm_us_nis    !=0) h_mcdimumass1bin_true_hfl_mu_lm_us->Add(h_mcdimumass1bin_true_hfl_mu_lm_us_is,h_mcdimumass1bin_true_hfl_mu_lm_us_nis);
    if(h_mcdimuxsecPt_true_hfl_mu_lm_us_nis      !=0) h_mcdimuxsecPt_true_hfl_mu_lm_us->Add(h_mcdimuxsecPt_true_hfl_mu_lm_us_is,h_mcdimuxsecPt_true_hfl_mu_lm_us_nis);
    if(h_mcdimuxsecEta_true_hfl_mu_lm_us_nis     !=0) h_mcdimuxsecEta_true_hfl_mu_lm_us->Add(h_mcdimuxsecEta_true_hfl_mu_lm_us_is,h_mcdimuxsecEta_true_hfl_mu_lm_us_nis);
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_us->Add(h_mcdimuxsecFinders_true_hfl_mu_lm_us_is,h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis);
    if(h_mcdimuxsecDR_true_hfl_mu_lm_us_nis      !=0) h_mcdimuxsecDR_true_hfl_mu_lm_us->Add(h_mcdimuxsecDR_true_hfl_mu_lm_us_is,h_mcdimuxsecDR_true_hfl_mu_lm_us_nis);
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis    !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_us->Add(h_mcdimuxsecDphi_true_hfl_mu_lm_us_is,h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis);


    if(h_etex2ir_lm_ls_nis !=0) h_etex2ir_lm_ls->Add(h_etex2ir_lm_ls_is,h_etex2ir_lm_ls_nis);
    if(h_dimuxsecpt_lm_ls_nis !=0) h_dimuxsecpt_lm_ls->Add(h_dimuxsecpt_lm_ls_is,h_dimuxsecpt_lm_ls_nis);
    if(h_dimuxseceta_lm_ls_nis !=0) h_dimuxseceta_lm_ls->Add(h_dimuxseceta_lm_ls_is,h_dimuxseceta_lm_ls_nis);
    if(h_dimuxsecfinders_lm_ls_nis !=0) h_dimuxsecfinders_lm_ls->Add(h_dimuxsecfinders_lm_ls_is,h_dimuxsecfinders_lm_ls_nis);
    if(h_dimuxsecdr_lm_ls_nis !=0) h_dimuxsecdr_lm_ls->Add(h_dimuxsecdr_lm_ls_is,h_dimuxsecdr_lm_ls_nis);
    if(h_dimuxsecdphi_lm_ls_nis !=0) h_dimuxsecdphi_lm_ls->Add(h_dimuxsecdphi_lm_ls_is,h_dimuxsecdphi_lm_ls_nis);

    if(h_mcdimumass1bin_true_hfl_mu_lm_ls_nis !=0) h_mcdimumass1bin_true_hfl_mu_lm_ls->Add(h_mcdimumass1bin_true_hfl_mu_lm_ls_is,h_mcdimumass1bin_true_hfl_mu_lm_ls_nis);
    if(h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecPt_true_hfl_mu_lm_ls->Add(h_mcdimuxsecPt_true_hfl_mu_lm_ls_is,h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis);
    if(h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecEta_true_hfl_mu_lm_ls->Add(h_mcdimuxsecEta_true_hfl_mu_lm_ls_is,h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis);
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_lm_ls->Add(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is,h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis);
    if(h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecDR_true_hfl_mu_lm_ls->Add(h_mcdimuxsecDR_true_hfl_mu_lm_ls_is,h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis);
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_lm_ls->Add(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is,h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis);

    if(h_etex2ir_hm_us_nis         !=0) h_etex2ir_hm_us->Add(h_etex2ir_hm_us_is,h_etex2ir_hm_us_nis);
    if(h_dimuxsecpt_hm_us_nis      !=0) h_dimuxsecpt_hm_us->Add(h_dimuxsecpt_hm_us_is,h_dimuxsecpt_hm_us_nis);
    if(h_dimuxseceta_hm_us_nis     !=0) h_dimuxseceta_hm_us->Add(h_dimuxseceta_hm_us_is,h_dimuxseceta_hm_us_nis);
    if(h_dimuxsecfinders_hm_us_nis !=0) h_dimuxsecfinders_hm_us->Add(h_dimuxsecfinders_hm_us_is,h_dimuxsecfinders_hm_us_nis);
    if(h_dimuxsecdr_hm_us_nis      !=0) h_dimuxsecdr_hm_us->Add(h_dimuxsecdr_hm_us_is,h_dimuxsecdr_hm_us_nis);
    if(h_dimuxsecdphi_hm_us_nis    !=0) h_dimuxsecdphi_hm_us->Add(h_dimuxsecdphi_hm_us_is,h_dimuxsecdphi_hm_us_nis);

    if(h_mcdimumass1bin_true_hfl_mu_hm_us_nis !=0) h_mcdimumass1bin_true_hfl_mu_hm_us->Add(h_mcdimumass1bin_true_hfl_mu_hm_us_is,h_mcdimumass1bin_true_hfl_mu_hm_us_nis);
    if(h_mcdimuxsecPt_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecPt_true_hfl_mu_hm_us->Add(h_mcdimuxsecPt_true_hfl_mu_hm_us_is,h_mcdimuxsecPt_true_hfl_mu_hm_us_nis);
    if(h_mcdimuxsecEta_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecEta_true_hfl_mu_hm_us->Add(h_mcdimuxsecEta_true_hfl_mu_hm_us_is,h_mcdimuxsecEta_true_hfl_mu_hm_us_nis);
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_us->Add(h_mcdimuxsecFinders_true_hfl_mu_hm_us_is,h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis);
    if(h_mcdimuxsecDR_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecDR_true_hfl_mu_hm_us->Add(h_mcdimuxsecDR_true_hfl_mu_hm_us_is,h_mcdimuxsecDR_true_hfl_mu_hm_us_nis);
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_us->Add(h_mcdimuxsecDphi_true_hfl_mu_hm_us_is,h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis);

    if(h_etex2ir_hm_ls_nis !=0) h_etex2ir_hm_ls->Add(h_etex2ir_hm_ls_is,h_etex2ir_hm_ls_nis);
    if(h_dimuxsecpt_hm_ls_nis !=0) h_dimuxsecpt_hm_ls->Add(h_dimuxsecpt_hm_ls_is,h_dimuxsecpt_hm_ls_nis);
    if(h_dimuxseceta_hm_ls_nis !=0) h_dimuxseceta_hm_ls->Add(h_dimuxseceta_hm_ls_is,h_dimuxseceta_hm_ls_nis);
    if(h_dimuxsecfinders_hm_ls_nis !=0) h_dimuxsecfinders_hm_ls->Add(h_dimuxsecfinders_hm_ls_is,h_dimuxsecfinders_hm_ls_nis);
    if(h_dimuxsecdr_hm_ls_nis !=0) h_dimuxsecdr_hm_ls->Add(h_dimuxsecdr_hm_ls_is,h_dimuxsecdr_hm_ls_nis);
    if(h_dimuxsecdphi_hm_ls_nis !=0) h_dimuxsecdphi_hm_ls->Add(h_dimuxsecdphi_hm_ls_is,h_dimuxsecdphi_hm_ls_nis);

    if(h_mcdimumass1bin_true_hfl_mu_hm_ls_nis !=0) h_mcdimumass1bin_true_hfl_mu_hm_ls->Add(h_mcdimumass1bin_true_hfl_mu_hm_ls_is,h_mcdimumass1bin_true_hfl_mu_hm_ls_nis);
    if(h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecPt_true_hfl_mu_hm_ls->Add(h_mcdimuxsecPt_true_hfl_mu_hm_ls_is,h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis);
    if(h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecEta_true_hfl_mu_hm_ls->Add(h_mcdimuxsecEta_true_hfl_mu_hm_ls_is,h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis);
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecFinders_true_hfl_mu_hm_ls->Add(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is,h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis);
    if(h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecDR_true_hfl_mu_hm_ls->Add(h_mcdimuxsecDR_true_hfl_mu_hm_ls_is,h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis);
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis !=0) h_mcdimuxsecDphi_true_hfl_mu_hm_ls->Add(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is,h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis);

//Append all histos:

    if(h_etex2ir_lm_us !=0) file->Append(h_etex2ir_lm_us-> Clone("h_etex2ir_lm_us"));
    if(h_dimuxsecpt_lm_us !=0) file->Append(h_dimuxsecpt_lm_us-> Clone("h_dimuxsecpt_lm_us"));
    if(h_dimuxseceta_lm_us !=0) file->Append(h_dimuxseceta_lm_us-> Clone("h_dimuxseceta_lm_us"));
    if(h_dimuxsecfinders_lm_us !=0) file->Append(h_dimuxsecfinders_lm_us-> Clone("h_dimuxsecfinders_lm_us"));
    if(h_dimuxsecdr_lm_us !=0) file->Append(h_dimuxsecdr_lm_us-> Clone("h_dimuxsecdr_lm_us"));
    if(h_dimuxsecdphi_lm_us !=0) file->Append(h_dimuxsecdphi_lm_us-> Clone("h_dimuxsecdphi_lm_us"));

    if(h_mcdimumass1bin_true_hfl_mu_lm_us !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_lm_us-> Clone("h_mcdimumass1bin_true_hfl_mu_lm_us"));
    if(h_mcdimuxsecPt_true_hfl_mu_lm_us !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_lm_us-> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_us"));
    if(h_mcdimuxsecEta_true_hfl_mu_lm_us !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_lm_us-> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_us"));
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_us !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_lm_us-> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_us"));
    if(h_mcdimuxsecDR_true_hfl_mu_lm_us !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_lm_us-> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_us"));
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_us !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_lm_us-> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_us"));


    if(h_etex2ir_lm_ls            !=0) file->Append(h_etex2ir_lm_ls            -> Clone("h_etex2ir_lm_ls"));
    if(h_dimuxsecpt_lm_ls !=0) file->Append(h_dimuxsecpt_lm_ls-> Clone("h_dimuxsecpt_lm_ls"));
    if(h_dimuxseceta_lm_ls !=0) file->Append(h_dimuxseceta_lm_ls-> Clone("h_dimuxseceta_lm_ls"));
    if(h_dimuxsecfinders_lm_ls !=0) file->Append(h_dimuxsecfinders_lm_ls-> Clone("h_dimuxsecfinders_lm_ls"));
    if(h_dimuxsecdr_lm_ls !=0) file->Append(h_dimuxsecdr_lm_ls-> Clone("h_dimuxsecdr_lm_ls"));
    if(h_dimuxsecdphi_lm_ls !=0) file->Append(h_dimuxsecdphi_lm_ls-> Clone("h_dimuxsecdphi_lm_ls"));

    if(h_mcdimumass1bin_true_hfl_mu_lm_ls !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_lm_ls-> Clone("h_mcdimumass1bin_true_hfl_mu_lm_ls"));
    if(h_mcdimuxsecPt_true_hfl_mu_lm_ls !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_lm_ls-> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_ls"));
    if(h_mcdimuxsecEta_true_hfl_mu_lm_ls !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_lm_ls-> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_ls"));
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_lm_ls-> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_ls"));
    if(h_mcdimuxsecDR_true_hfl_mu_lm_ls !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_lm_ls-> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_ls"));
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_lm_ls-> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_ls"));


    if(h_etex2ir_hm_us            !=0) file->Append(h_etex2ir_hm_us            -> Clone("h_etex2ir_hm_us"));
    if(h_dimuxsecpt_hm_us !=0) file->Append(h_dimuxsecpt_hm_us-> Clone("h_dimuxsecpt_hm_us"));
    if(h_dimuxseceta_hm_us !=0) file->Append(h_dimuxseceta_hm_us-> Clone("h_dimuxseceta_hm_us"));
    if(h_dimuxsecfinders_hm_us !=0) file->Append(h_dimuxsecfinders_hm_us-> Clone("h_dimuxsecfinders_hm_us"));
    if(h_dimuxsecdr_hm_us !=0) file->Append(h_dimuxsecdr_hm_us-> Clone("h_dimuxsecdr_hm_us"));
    if(h_dimuxsecdphi_hm_us !=0) file->Append(h_dimuxsecdphi_hm_us-> Clone("h_dimuxsecdphi_hm_us"));

    if(h_mcdimumass1bin_true_hfl_mu_hm_us !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_hm_us-> Clone("h_mcdimumass1bin_true_hfl_mu_hm_us"));
    if(h_mcdimuxsecPt_true_hfl_mu_hm_us !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_hm_us-> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_us"));
    if(h_mcdimuxsecEta_true_hfl_mu_hm_us !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_hm_us-> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_us"));
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_us !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_hm_us-> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_us"));
    if(h_mcdimuxsecDR_true_hfl_mu_hm_us !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_hm_us-> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_us"));
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_us !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_hm_us-> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_us"));

    if(h_etex2ir_hm_ls !=0) file->Append(h_etex2ir_hm_ls-> Clone("h_etex2ir_hm_ls"));
    if(h_dimuxsecpt_hm_ls !=0) file->Append(h_dimuxsecpt_hm_ls-> Clone("h_dimuxsecpt_hm_ls"));
    if(h_dimuxseceta_hm_ls !=0) file->Append(h_dimuxseceta_hm_ls-> Clone("h_dimuxseceta_hm_ls"));
    if(h_dimuxsecfinders_hm_ls !=0) file->Append(h_dimuxsecfinders_hm_ls-> Clone("h_dimuxsecfinders_hm_ls"));
    if(h_dimuxsecdr_hm_ls !=0) file->Append(h_dimuxsecdr_hm_ls-> Clone("h_dimuxsecdr_hm_ls"));
    if(h_dimuxsecdphi_hm_ls !=0) file->Append(h_dimuxsecdphi_hm_ls-> Clone("h_dimuxsecdphi_hm_ls"));

    if(h_mcdimumass1bin_true_hfl_mu_hm_ls !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_hm_ls-> Clone("h_mcdimumass1bin_true_hfl_mu_hm_ls"));
    if(h_mcdimuxsecPt_true_hfl_mu_hm_ls !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_hm_ls-> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_ls"));
    if(h_mcdimuxsecEta_true_hfl_mu_hm_ls !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_hm_ls-> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_ls"));
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_hm_ls-> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_ls"));
    if(h_mcdimuxsecDR_true_hfl_mu_hm_ls !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_hm_ls-> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_ls"));
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_hm_ls-> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_ls"));

// ***************************************************************************************
// append isolated histos:
// ***************************************************************************************

    if(h_etex2ir_lm_us_is         !=0) file->Append(h_etex2ir_lm_us_is         -> Clone("h_etex2ir_lm_us_is"));
    if(h_dimuxsecpt_lm_us_is      !=0) file->Append(h_dimuxsecpt_lm_us_is      -> Clone("h_dimuxsecpt_lm_us_is"));
    if(h_dimuxseceta_lm_us_is     !=0) file->Append(h_dimuxseceta_lm_us_is     -> Clone("h_dimuxseceta_lm_us_is"));
    if(h_dimuxsecfinders_lm_us_is !=0) file->Append(h_dimuxsecfinders_lm_us_is -> Clone("h_dimuxsecfinders_lm_us_is"));
    if(h_dimuxsecdr_lm_us_is !=0) file->Append(h_dimuxsecdr_lm_us_is -> Clone("h_dimuxsecdr_lm_us_is"));
    if(h_dimuxsecdphi_lm_us_is !=0) file->Append(h_dimuxsecdphi_lm_us_is -> Clone("h_dimuxsecdphi_lm_us_is"));

    if(h_mcdimumass1bin_true_hfl_mu_lm_us_is !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_lm_us_is -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_us_is"));
    if(h_mcdimuxsecPt_true_hfl_mu_lm_us_is !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_lm_us_is -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_us_is"));
    if(h_mcdimuxsecEta_true_hfl_mu_lm_us_is !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_lm_us_is -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_us_is"));
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_us_is !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_lm_us_is -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_us_is"));
    if(h_mcdimuxsecDR_true_hfl_mu_lm_us_is !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_lm_us_is -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_us_is"));
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_us_is !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_lm_us_is -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_us_is"));


    if(h_etex2ir_lm_ls_is !=0) file->Append(h_etex2ir_lm_ls_is -> Clone("h_etex2ir_lm_ls_is"));
    if(h_dimuxsecpt_lm_ls_is !=0) file->Append(h_dimuxsecpt_lm_ls_is -> Clone("h_dimuxsecpt_lm_ls_is"));
    if(h_dimuxseceta_lm_ls_is !=0) file->Append(h_dimuxseceta_lm_ls_is -> Clone("h_dimuxseceta_lm_ls_is"));
    if(h_dimuxsecfinders_lm_ls_is !=0) file->Append(h_dimuxsecfinders_lm_ls_is -> Clone("h_dimuxsecfinders_lm_ls_is"));
    if(h_dimuxsecdr_lm_ls_is !=0) file->Append(h_dimuxsecdr_lm_ls_is -> Clone("h_dimuxsecdr_lm_ls_is"));
    if(h_dimuxsecdphi_lm_ls_is !=0) file->Append(h_dimuxsecdphi_lm_ls_is -> Clone("h_dimuxsecdphi_lm_ls_is"));

    if(h_mcdimumass1bin_true_hfl_mu_lm_ls_is !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_lm_ls_is -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_ls_is"));
    if(h_mcdimuxsecPt_true_hfl_mu_lm_ls_is !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_lm_ls_is -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_ls_is"));
    if(h_mcdimuxsecEta_true_hfl_mu_lm_ls_is !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_lm_ls_is -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_ls_is"));
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_ls_is"));
    if(h_mcdimuxsecDR_true_hfl_mu_lm_ls_is !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_lm_ls_is -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_ls_is"));
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_ls_is"));

    if(h_etex2ir_hm_us_is              !=0) file->Append(h_etex2ir_hm_us_is              -> Clone("h_etex2ir_hm_us_is"));
    if(h_dimuxsecpt_hm_us_is           !=0) file->Append(h_dimuxsecpt_hm_us_is           -> Clone("h_dimuxsecpt_hm_us_is"));
    if(h_dimuxseceta_hm_us_is          !=0) file->Append(h_dimuxseceta_hm_us_is          -> Clone("h_dimuxseceta_hm_us_is"));
    if(h_dimuxsecfinders_hm_us_is      !=0) file->Append(h_dimuxsecfinders_hm_us_is      -> Clone("h_dimuxsecfinders_hm_us_is"));
    if(h_dimuxsecdr_hm_us_is           !=0) file->Append(h_dimuxsecdr_hm_us_is           -> Clone("h_dimuxsecdr_hm_us_is"));
    if(h_dimuxsecdphi_hm_us_is         !=0) file->Append(h_dimuxsecdphi_hm_us_is         -> Clone("h_dimuxsecdphi_hm_us_is"));

    if(h_mcdimumass1bin_true_hfl_mu_hm_us_is        !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_hm_us_is     -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_us_is"));
    if(h_mcdimuxsecPt_true_hfl_mu_hm_us_is          !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_hm_us_is       -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_us_is"));
    if(h_mcdimuxsecEta_true_hfl_mu_hm_us_is         !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_hm_us_is      -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_us_is"));
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_us_is     !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_hm_us_is  -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_us_is"));
    if(h_mcdimuxsecDR_true_hfl_mu_hm_us_is          !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_hm_us_is -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_us_is"));
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_us_is !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_hm_us_is -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_us_is"));


    if(h_etex2ir_hm_ls_is              !=0) file->Append(h_etex2ir_hm_ls_is              -> Clone("h_etex2ir_hm_ls_is"));
    if(h_dimuxsecpt_hm_ls_is           !=0) file->Append(h_dimuxsecpt_hm_ls_is           -> Clone("h_dimuxsecpt_hm_ls_is"));
    if(h_dimuxseceta_hm_ls_is          !=0) file->Append(h_dimuxseceta_hm_ls_is          -> Clone("h_dimuxseceta_hm_ls_is"));
    if(h_dimuxsecfinders_hm_ls_is      !=0) file->Append(h_dimuxsecfinders_hm_ls_is      -> Clone("h_dimuxsecfinders_hm_ls_is"));
    if(h_dimuxsecdr_hm_ls_is           !=0) file->Append(h_dimuxsecdr_hm_ls_is           -> Clone("h_dimuxsecdr_hm_ls_is"));
    if(h_dimuxsecdphi_hm_ls_is         !=0) file->Append(h_dimuxsecdphi_hm_ls_is         -> Clone("h_dimuxsecdphi_hm_ls_is"));

    if(h_mcdimumass1bin_true_hfl_mu_hm_ls_is !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_hm_ls_is -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_ls_is"));
    if(h_mcdimuxsecPt_true_hfl_mu_hm_ls_is !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_hm_ls_is -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_ls_is"));
    if(h_mcdimuxsecEta_true_hfl_mu_hm_ls_is !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_hm_ls_is -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_ls_is"));
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_ls_is"));
    if(h_mcdimuxsecDR_true_hfl_mu_hm_ls_is !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_hm_ls_is -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_ls_is"));
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_ls_is"));


    // ***************************************************************************************
    // append non-isolated histos:
    // ***************************************************************************************

    if(h_etex2ir_lm_us_nis              !=0) file->Append(h_etex2ir_lm_us_nis              -> Clone("h_etex2ir_lm_us_nis"));
    if(h_dimuxsecpt_lm_us_nis           !=0) file->Append(h_dimuxsecpt_lm_us_nis           -> Clone("h_dimuxsecpt_lm_us_nis"));
    if(h_dimuxseceta_lm_us_nis          !=0) file->Append(h_dimuxseceta_lm_us_nis          -> Clone("h_dimuxseceta_lm_us_nis"));
    if(h_dimuxsecfinders_lm_us_nis      !=0) file->Append(h_dimuxsecfinders_lm_us_nis      -> Clone("h_dimuxsecfinders_lm_us_nis"));
    if(h_dimuxsecdr_lm_us_nis           !=0) file->Append(h_dimuxsecdr_lm_us_nis           -> Clone("h_dimuxsecdr_lm_us_nis"));
    if(h_dimuxsecdphi_lm_us_nis         !=0) file->Append(h_dimuxsecdphi_lm_us_nis         -> Clone("h_dimuxsecdphi_lm_us_nis"));

    if(h_mcdimumass1bin_true_hfl_mu_lm_us_nis     !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_lm_us_nis     -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_us_nis"));
    if(h_mcdimuxsecPt_true_hfl_mu_lm_us_nis !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_us_nis"));
    if(h_mcdimuxsecEta_true_hfl_mu_lm_us_nis !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_us_nis"));
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_us_nis"));
    if(h_mcdimuxsecDR_true_hfl_mu_lm_us_nis !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_us_nis"));
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_us_nis"));


    if(h_etex2ir_lm_ls_nis            !=0) file->Append(h_etex2ir_lm_ls_nis            -> Clone("h_etex2ir_lm_ls_nis"));
    if(h_dimuxsecpt_lm_ls_nis           !=0) file->Append(h_dimuxsecpt_lm_ls_nis           -> Clone("h_dimuxsecpt_lm_ls_nis"));
    if(h_dimuxseceta_lm_ls_nis          !=0) file->Append(h_dimuxseceta_lm_ls_nis          -> Clone("h_dimuxseceta_lm_ls_nis"));
    if(h_dimuxsecfinders_lm_ls_nis      !=0) file->Append(h_dimuxsecfinders_lm_ls_nis      -> Clone("h_dimuxsecfinders_lm_ls_nis"));
    if(h_dimuxsecdr_lm_ls_nis           !=0) file->Append(h_dimuxsecdr_lm_ls_nis           -> Clone("h_dimuxsecdr_lm_ls_nis"));
    if(h_dimuxsecdphi_lm_ls_nis         !=0) file->Append(h_dimuxsecdphi_lm_ls_nis         -> Clone("h_dimuxsecdphi_lm_ls_nis"));

    if(h_mcdimumass1bin_true_hfl_mu_lm_ls_nis !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_lm_ls_nis"));
    if(h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_lm_ls_nis"));
    if(h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_lm_ls_nis"));
    if(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_lm_ls_nis"));
    if(h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_lm_ls_nis"));
    if(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_lm_ls_nis"));


    if(h_etex2ir_hm_us_nis            !=0) file->Append(h_etex2ir_hm_us_nis            -> Clone("h_etex2ir_hm_us_nis"));
    if(h_dimuxsecpt_hm_us_nis           !=0) file->Append(h_dimuxsecpt_hm_us_nis           -> Clone("h_dimuxsecpt_hm_us_nis"));
    if(h_dimuxseceta_hm_us_nis          !=0) file->Append(h_dimuxseceta_hm_us_nis          -> Clone("h_dimuxseceta_hm_us_nis"));
    if(h_dimuxsecfinders_hm_us_nis      !=0) file->Append(h_dimuxsecfinders_hm_us_nis      -> Clone("h_dimuxsecfinders_hm_us_nis"));
    if(h_dimuxsecdr_hm_us_nis           !=0) file->Append(h_dimuxsecdr_hm_us_nis           -> Clone("h_dimuxsecdr_hm_us_nis"));
    if(h_dimuxsecdphi_hm_us_nis         !=0) file->Append(h_dimuxsecdphi_hm_us_nis         -> Clone("h_dimuxsecdphi_hm_us_nis"));

    if(h_mcdimumass1bin_true_hfl_mu_hm_us_nis !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_hm_us_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_us_nis"));
    if(h_mcdimuxsecPt_true_hfl_mu_hm_us_nis !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_us_nis"));
    if(h_mcdimuxsecEta_true_hfl_mu_hm_us_nis !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_us_nis"));
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis"));
    if(h_mcdimuxsecDR_true_hfl_mu_hm_us_nis !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_us_nis"));
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis"));


    if(h_etex2ir_hm_ls_nis            !=0) file->Append(h_etex2ir_hm_ls_nis            -> Clone("h_etex2ir_hm_ls_nis"));
    if(h_dimuxsecpt_hm_ls_nis           !=0) file->Append(h_dimuxsecpt_hm_ls_nis           -> Clone("h_dimuxsecpt_hm_ls_nis"));
    if(h_dimuxseceta_hm_ls_nis          !=0) file->Append(h_dimuxseceta_hm_ls_nis          -> Clone("h_dimuxseceta_hm_ls_nis"));
    if(h_dimuxsecfinders_hm_ls_nis      !=0) file->Append(h_dimuxsecfinders_hm_ls_nis      -> Clone("h_dimuxsecfinders_hm_ls_nis"));
    if(h_dimuxsecdr_hm_ls_nis           !=0) file->Append(h_dimuxsecdr_hm_ls_nis           -> Clone("h_dimuxsecdr_hm_ls_nis"));
    if(h_dimuxsecdphi_hm_ls_nis         !=0) file->Append(h_dimuxsecdphi_hm_ls_nis         -> Clone("h_dimuxsecdphi_hm_ls_nis"));

    if(h_mcdimumass1bin_true_hfl_mu_hm_ls_nis !=0) file->Append(h_mcdimumass1bin_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimumass1bin_true_hfl_mu_hm_ls_nis"));
    if(h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis !=0) file->Append(h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecPt_true_hfl_mu_hm_ls_nis"));
    if(h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis !=0) file->Append(h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecEta_true_hfl_mu_hm_ls_nis"));
    if(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis !=0) file->Append(h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecFinders_true_hfl_mu_hm_ls_nis"));
    if(h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis !=0) file->Append(h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecDR_true_hfl_mu_hm_ls_nis"));
    if(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis !=0) file->Append(h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis -> Clone("h_mcdimuxsecDphi_true_hfl_mu_hm_ls_nis"));

 
  }
  file->Write();
  file->Close();
  gROOT->ProcessLine(".q");
}

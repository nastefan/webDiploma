#include "TCanvas.h"
#include "TMath.h"
#include "TFile.h"
#include "TDirectory.h"
#include "TKey.h"
#include "TROOT.h"
//#include "TIter.h"
#include "iostream"
#include "iomanip"
//#include </data/zenith223a/dbot/Gut_Code_PhD/anadir/analysis_macros/inc/own_histos_danny_muonjet.h>
#include "/nfs/dust/zeus/group/stefan/test2/GoodCodeGit/anadir/analysis_macros/inc/own_histos_danny_muonjet.h"

using namespace std;

void oli_to_danny_muonjet(Bool_t slowme = false){
  cout<<"slowme is: "<<1*slowme<<endl;
  
  // Int_t obj_size_v          = 10000;
  // Int_t obj_size_h          = 1;
  Int_t DIMuon_folder_size  = 0;
 
  TH1D *obj[10000][1];
  
  // initialise histogram array:
  for(Int_t vorne = 0; vorne<10000; vorne++){
    for(Int_t hinten = 0; hinten<1; hinten++) obj[vorne][hinten] = 0;
  }
  //test histos reset start:

  h_MuJetDR_all                                      = 0;
  h_MuJetDR_lm_us                                    = 0;
  h_MuJetDR_lm_ls                                    = 0;
  h_MuJetDR_hm_us                                    = 0;
  h_MuJetDR_hm_ls                                    = 0;
  h_MuJetDR_lm_us_is                                 = 0;
  h_MuJetDR_lm_ls_is                                 = 0;
  h_MuJetDR_hm_us_is                                 = 0;
  h_MuJetDR_hm_ls_is                                 = 0;
  h_MuJetDR_lm_us_nis                                = 0;
  h_MuJetDR_lm_ls_nis                                = 0;
  h_MuJetDR_hm_us_nis                                = 0;
  h_MuJetDR_hm_ls_nis                                = 0;

  h_MuJetPt_all                                      = 0;
  h_MuJetPt_lm_us                                    = 0;
  h_MuJetPt_lm_ls                                    = 0;
  h_MuJetPt_hm_us                                    = 0;
  h_MuJetPt_hm_ls                                    = 0;
  h_MuJetPt_lm_us_is                                 = 0;
  h_MuJetPt_lm_ls_is                                 = 0;
  h_MuJetPt_hm_us_is                                 = 0;
  h_MuJetPt_hm_ls_is                                 = 0;
  h_MuJetPt_lm_us_nis                                = 0;
  h_MuJetPt_lm_ls_nis                                = 0;
  h_MuJetPt_hm_us_nis                                = 0;
  h_MuJetPt_hm_ls_nis                                = 0;
 
  h_MuJetEt_all                                      = 0;
  h_MuJetEt_lm_us                                    = 0;
  h_MuJetEt_lm_ls                                    = 0;
  h_MuJetEt_hm_us                                    = 0;
  h_MuJetEt_hm_ls                                    = 0;
  h_MuJetEt_lm_us_is                                 = 0;
  h_MuJetEt_lm_ls_is                                 = 0;
  h_MuJetEt_hm_us_is                                 = 0;
  h_MuJetEt_hm_ls_is                                 = 0;
  h_MuJetEt_lm_us_nis                                = 0;
  h_MuJetEt_lm_ls_nis                                = 0;
  h_MuJetEt_hm_us_nis                                = 0;
  h_MuJetEt_hm_ls_nis                                = 0;

  h_MuJetEta_all                                     = 0;
  h_MuJetEta_lm_us                                   = 0;
  h_MuJetEta_lm_ls                                   = 0;
  h_MuJetEta_hm_us                                   = 0;
  h_MuJetEta_hm_ls                                   = 0;
  h_MuJetEta_lm_us_is                                = 0;
  h_MuJetEta_lm_ls_is                                = 0;
  h_MuJetEta_hm_us_is                                = 0;
  h_MuJetEta_hm_ls_is                                = 0;
  h_MuJetEta_lm_us_nis                               = 0;
  h_MuJetEta_lm_ls_nis                               = 0;
  h_MuJetEta_hm_us_nis                               = 0;
  h_MuJetEta_hm_ls_nis                               = 0;

  h_MuJetMass_all                                    = 0;
  h_MuJetMass_lm_us                                  = 0;
  h_MuJetMass_lm_ls                                  = 0;
  h_MuJetMass_hm_us                                  = 0;
  h_MuJetMass_hm_ls                                  = 0;
  h_MuJetMass_lm_us_is                               = 0;
  h_MuJetMass_lm_ls_is                               = 0;
  h_MuJetMass_hm_us_is                               = 0;
  h_MuJetMass_hm_ls_is                               = 0;
  h_MuJetMass_lm_us_nis                              = 0;
  h_MuJetMass_lm_ls_nis                              = 0;
  h_MuJetMass_hm_us_nis                              = 0;
  h_MuJetMass_hm_ls_nis                              = 0;

  h_NJets_all                                     = 0;
  h_NJets_lm_us                                   = 0;
  h_NJets_lm_ls                                   = 0;
  h_NJets_hm_us                                   = 0;
  h_NJets_hm_ls                                   = 0;
  h_NJets_lm_us_is                                = 0;
  h_NJets_lm_ls_is                                = 0;
  h_NJets_hm_us_is                                = 0;
  h_NJets_hm_ls_is                                = 0;
  h_NJets_lm_us_nis                               = 0;
  h_NJets_lm_ls_nis                               = 0;
  h_NJets_hm_us_nis                               = 0;
  h_NJets_hm_ls_nis                               = 0;

//test histos reset end.

  Int_t count1 = 0;
  
  TString previous_obj, histonamebuffer;
  TString outfile, infile;
  TKey *key;
  TFile *_file0;
  
  infile = "histos.root";
  
  if( _file0 = new TFile(infile,"READ") ) cout << "file opened "<< infile << endl;

  outfile = "oli2danny_out.root";
  
  _file0->ls();
  _file0->cd("Histograms/DIMuon");
  
  cout<<"getlist is: "<<endl;
  
  TIter next( gDirectory->GetListOfKeys() );
  while ((key = (TKey *) next())) {
    obj[count1][0] = (TH1D*) gDirectory->Get(key->GetName()); // copy object to memory
    obj[count1][0]->SetDirectory(0);
    obj[count1][0]->AddDirectory(kFALSE);
   
 // do something with obj
    if( previous_obj==key->GetName() ) {

      continue;

    } 
    
    previous_obj = key->GetName();
    count1++;
  }
  cout<<"Directory DIMuon left at count1= "<<count1<<endl;
  DIMuon_folder_size = count1;
  cout<<"DIMuon_folder_size = "<<DIMuon_folder_size<<endl;
 
  TFile * file = new TFile(outfile,"RECREATE");
  for( Int_t i=0; i< count1; ++i) {
    histonamebuffer = obj[i][0]->GetName();
    obj[i][0]->AddDirectory(kFALSE);
  
    if( i < DIMuon_folder_size ){

      if( histonamebuffer=="MuJetDeltaR")                 h_MuJetDR_all        = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_is_lu")           h_MuJetDR_lm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_is_ll")           h_MuJetDR_lm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_is_hu")           h_MuJetDR_hm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_is_hl")           h_MuJetDR_hm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_nis_lu")          h_MuJetDR_lm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_nis_ll")          h_MuJetDR_lm_ls_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_nis_hu")          h_MuJetDR_hm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetDeltaR_nis_hl")          h_MuJetDR_hm_ls_nis  = obj[i][0];   

      if( histonamebuffer=="MuJetPt")                     h_MuJetPt_all        = obj[i][0];   
      if( histonamebuffer=="MuJetPt_is_lu")               h_MuJetPt_lm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetPt_is_ll")               h_MuJetPt_lm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetPt_is_hu")               h_MuJetPt_hm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetPt_is_hl")               h_MuJetPt_hm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetPt_nis_lu")              h_MuJetPt_lm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetPt_nis_ll")              h_MuJetPt_lm_ls_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetPt_nis_hu")              h_MuJetPt_hm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetPt_nis_hl")              h_MuJetPt_hm_ls_nis  = obj[i][0];   
   
      if( histonamebuffer=="MuJetEt")                     h_MuJetEt_all        = obj[i][0];   
      if( histonamebuffer=="MuJetEt_is_lu")               h_MuJetEt_lm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEt_is_ll")               h_MuJetEt_lm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEt_is_hu")               h_MuJetEt_hm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEt_is_hl")               h_MuJetEt_hm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEt_nis_lu")              h_MuJetEt_lm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetEt_nis_ll")              h_MuJetEt_lm_ls_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetEt_nis_hu")              h_MuJetEt_hm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetEt_nis_hl")              h_MuJetEt_hm_ls_nis  = obj[i][0];   

      if( histonamebuffer=="MuJetEta")                    h_MuJetEta_all        = obj[i][0];   
      if( histonamebuffer=="MuJetEta_is_lu")              h_MuJetEta_lm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEta_is_ll")              h_MuJetEta_lm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEta_is_hu")              h_MuJetEta_hm_us_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEta_is_hl")              h_MuJetEta_hm_ls_is   = obj[i][0];   
      if( histonamebuffer=="MuJetEta_nis_lu")             h_MuJetEta_lm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetEta_nis_ll")             h_MuJetEta_lm_ls_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetEta_nis_hu")             h_MuJetEta_hm_us_nis  = obj[i][0];   
      if( histonamebuffer=="MuJetEta_nis_hl")             h_MuJetEta_hm_ls_nis  = obj[i][0];   

      if( histonamebuffer=="MassJet")                     h_MuJetMass_all       = obj[i][0];   
      if( histonamebuffer=="MassJet_is_lu")               h_MuJetMass_lm_us_is  = obj[i][0];   
      if( histonamebuffer=="MassJet_is_ll")               h_MuJetMass_lm_ls_is  = obj[i][0];   
      if( histonamebuffer=="MassJet_is_hu")               h_MuJetMass_hm_us_is  = obj[i][0];   
      if( histonamebuffer=="MassJet_is_hl")               h_MuJetMass_hm_ls_is  = obj[i][0];   
      if( histonamebuffer=="MassJet_nis_lu")              h_MuJetMass_lm_us_nis = obj[i][0];   
      if( histonamebuffer=="MassJet_nis_ll")              h_MuJetMass_lm_ls_nis = obj[i][0];   
      if( histonamebuffer=="MassJet_nis_hu")              h_MuJetMass_hm_us_nis = obj[i][0];   
      if( histonamebuffer=="MassJet_nis_hl")              h_MuJetMass_hm_ls_nis = obj[i][0];

      if( histonamebuffer=="NJets")                       h_NJets_all        = obj[i][0];   
      if( histonamebuffer=="NJets_is_lu")                 h_NJets_lm_us_is   = obj[i][0];   
      if( histonamebuffer=="NJets_is_ll")                 h_NJets_lm_ls_is   = obj[i][0];   
      if( histonamebuffer=="NJets_is_hu")                 h_NJets_hm_us_is   = obj[i][0];   
      if( histonamebuffer=="NJets_is_hl")                 h_NJets_hm_ls_is   = obj[i][0];   
      if( histonamebuffer=="NJets_nis_lu")                h_NJets_lm_us_nis  = obj[i][0];   
      if( histonamebuffer=="NJets_nis_ll")                h_NJets_lm_ls_nis  = obj[i][0];   
      if( histonamebuffer=="NJets_nis_hu")                h_NJets_hm_us_nis  = obj[i][0];   
      if( histonamebuffer=="NJets_nis_hl")                h_NJets_hm_ls_nis  = obj[i][0];   

    }

  }
    
  if(42 == 42) {
 
    if(h_MuJetDR_all   != 0) file->Append( h_MuJetDR_all   -> Clone("h_MuJetDR_all")   );
    if(h_MuJetPt_all   != 0) file->Append( h_MuJetPt_all   -> Clone("h_MuJetPt_all")   );
    if(h_MuJetEt_all   != 0) file->Append( h_MuJetEt_all   -> Clone("h_MuJetEt_all")   );
    if(h_MuJetEta_all  != 0) file->Append( h_MuJetEta_all  -> Clone("h_MuJetEta_all")   );
    if(h_NJets_all     != 0) file->Append( h_NJets_all     -> Clone("h_NJets_all")  );
    if(h_MuJetMass_all != 0) file->Append( h_MuJetMass_all -> Clone("h_MuJetMass_all") );

    // ***************************************************************************************
    // produce and append pre-isolation histos:
    // ***************************************************************************************

    if(h_MuJetDR_lm_us_nis      != 0) h_MuJetDR_lm_us      = (TH1D*) h_MuJetDR_lm_us_nis      -> Clone("h_MuJetDR_lm_us");
    if(h_MuJetPt_lm_us_nis      != 0) h_MuJetPt_lm_us      = (TH1D*) h_MuJetPt_lm_us_nis      -> Clone("h_MuJetPt_lm_us");
    if(h_MuJetEt_lm_us_nis      != 0) h_MuJetEt_lm_us      = (TH1D*) h_MuJetEt_lm_us_nis      -> Clone("h_MuJetEt_lm_us");
    if(h_MuJetEta_lm_us_nis     != 0) h_MuJetEta_lm_us     = (TH1D*) h_MuJetEta_lm_us_nis     -> Clone("h_MuJetEta_lm_us");
    if(h_NJets_lm_us_nis        != 0) h_NJets_lm_us        = (TH1D*) h_NJets_lm_us_nis        -> Clone("h_NJets_lm_us");
    if(h_MuJetMass_lm_us_nis    != 0) h_MuJetMass_lm_us    = (TH1D*) h_MuJetMass_lm_us_nis    -> Clone("h_MuJetMass_lm_us");

    if(h_MuJetDR_lm_ls_nis      != 0) h_MuJetDR_lm_ls      = (TH1D*) h_MuJetDR_lm_ls_nis      -> Clone("h_MuJetDR_lm_ls");
    if(h_MuJetPt_lm_ls_nis      != 0) h_MuJetPt_lm_ls      = (TH1D*) h_MuJetPt_lm_ls_nis      -> Clone("h_MuJetPt_lm_ls");
    if(h_MuJetEt_lm_ls_nis      != 0) h_MuJetEt_lm_ls      = (TH1D*) h_MuJetEt_lm_ls_nis      -> Clone("h_MuJetEt_lm_ls");
    if(h_MuJetEta_lm_ls_nis     != 0) h_MuJetEta_lm_ls     = (TH1D*) h_MuJetEta_lm_ls_nis     -> Clone("h_MuJetEta_lm_ls");
    if(h_NJets_lm_ls_nis        != 0) h_NJets_lm_ls        = (TH1D*) h_NJets_lm_ls_nis        -> Clone("h_NJets_lm_ls");
    if(h_MuJetMass_lm_ls_nis    != 0) h_MuJetMass_lm_ls    = (TH1D*) h_MuJetMass_lm_ls_nis    -> Clone("h_MuJetMass_lm_ls");
 
    if(h_MuJetDR_hm_us_nis      != 0) h_MuJetDR_hm_us      = (TH1D*) h_MuJetDR_hm_us_nis      -> Clone("h_MuJetDR_hm_us");
    if(h_MuJetPt_hm_us_nis      != 0) h_MuJetPt_hm_us      = (TH1D*) h_MuJetPt_hm_us_nis      -> Clone("h_MuJetPt_hm_us");
    if(h_MuJetEt_hm_us_nis      != 0) h_MuJetEt_hm_us      = (TH1D*) h_MuJetEt_hm_us_nis      -> Clone("h_MuJetEt_hm_us");
    if(h_MuJetEta_hm_us_nis     != 0) h_MuJetEta_hm_us     = (TH1D*) h_MuJetEta_hm_us_nis     -> Clone("h_MuJetEta_hm_us");
    if(h_NJets_hm_us_nis        != 0) h_NJets_hm_us        = (TH1D*) h_NJets_hm_us_nis        -> Clone("h_NJets_hm_us");
    if(h_MuJetMass_hm_us_nis    != 0) h_MuJetMass_hm_us    = (TH1D*) h_MuJetMass_hm_us_nis    -> Clone("h_MuJetMass_hm_us");

    if(h_MuJetDR_hm_us_nis      != 0) h_MuJetDR_hm_ls      = (TH1D*) h_MuJetDR_hm_ls_nis      -> Clone("h_MuJetDR_hm_ls");
    if(h_MuJetPt_hm_us_nis      != 0) h_MuJetPt_hm_ls      = (TH1D*) h_MuJetPt_hm_ls_nis      -> Clone("h_MuJetPt_hm_ls");
    if(h_MuJetEt_hm_us_nis      != 0) h_MuJetEt_hm_ls      = (TH1D*) h_MuJetEt_hm_ls_nis      -> Clone("h_MuJetEt_hm_ls");
    if(h_MuJetEta_hm_us_nis     != 0) h_MuJetEta_hm_ls     = (TH1D*) h_MuJetEta_hm_ls_nis     -> Clone("h_MuJetEta_hm_ls");
    if(h_NJets_hm_us_nis        != 0) h_NJets_hm_ls        = (TH1D*) h_NJets_hm_ls_nis        -> Clone("h_NJets_hm_ls");
    if(h_MuJetMass_hm_us_nis    != 0) h_MuJetMass_hm_ls    = (TH1D*) h_MuJetMass_hm_ls_nis    -> Clone("h_MuJetMass_hm_ls");

    //Add is + nis to have nisandis:
    if(h_MuJetDR_lm_us_nis      != 0) h_MuJetDR_lm_us     -> Add(h_MuJetDR_lm_us_is      , h_MuJetDR_lm_us_nis,1,1);
    if(h_MuJetPt_lm_us_nis      != 0) h_MuJetPt_lm_us     -> Add(h_MuJetPt_lm_us_is      , h_MuJetPt_lm_us_nis,1,1);
    if(h_MuJetEt_lm_us_nis      != 0) h_MuJetEt_lm_us     -> Add(h_MuJetEt_lm_us_is      , h_MuJetEt_lm_us_nis,1,1);
    if(h_MuJetEta_lm_us_nis     != 0) h_MuJetEta_lm_us    -> Add(h_MuJetEta_lm_us_is     , h_MuJetEta_lm_us_nis,1,1);
    if(h_NJets_lm_us_nis        != 0) h_NJets_lm_us       -> Add(h_NJets_lm_us_is        , h_NJets_lm_us_nis,1,1);
    if(h_MuJetMass_lm_us_nis    != 0) h_MuJetMass_lm_us   -> Add(h_MuJetMass_lm_us_is    , h_MuJetMass_lm_us_nis,1,1);

    if(h_MuJetDR_lm_ls_nis      != 0) h_MuJetDR_lm_ls     -> Add(h_MuJetDR_lm_ls_is      , h_MuJetDR_lm_ls_nis,1,1);
    if(h_MuJetPt_lm_ls_nis      != 0) h_MuJetPt_lm_ls     -> Add(h_MuJetPt_lm_ls_is      , h_MuJetPt_lm_ls_nis,1,1);
    if(h_MuJetEt_lm_ls_nis      != 0) h_MuJetEt_lm_ls     -> Add(h_MuJetEt_lm_ls_is      , h_MuJetEt_lm_ls_nis,1,1);
    if(h_MuJetEta_lm_ls_nis     != 0) h_MuJetEta_lm_ls    -> Add(h_MuJetEta_lm_ls_is     , h_MuJetEta_lm_ls_nis,1,1);
    if(h_NJets_lm_ls_nis        != 0) h_NJets_lm_ls       -> Add(h_NJets_lm_ls_is        , h_NJets_lm_ls_nis,1,1);
    if(h_MuJetMass_lm_ls_nis    != 0) h_MuJetMass_lm_ls   -> Add(h_MuJetMass_lm_ls_is    , h_MuJetMass_lm_ls_nis,1,1);

    if(h_MuJetDR_hm_us_nis      != 0) h_MuJetDR_hm_us     -> Add(h_MuJetDR_hm_us_is      , h_MuJetDR_hm_us_nis,1,1);
    if(h_MuJetPt_hm_us_nis      != 0) h_MuJetPt_hm_us     -> Add(h_MuJetPt_hm_us_is      , h_MuJetPt_hm_us_nis,1,1);
    if(h_MuJetEt_hm_us_nis      != 0) h_MuJetEt_hm_us     -> Add(h_MuJetEt_hm_us_is      , h_MuJetEt_hm_us_nis,1,1);
    if(h_MuJetEta_hm_us_nis     != 0) h_MuJetEta_hm_us    -> Add(h_MuJetEta_hm_us_is     , h_MuJetEta_hm_us_nis,1,1);
    if(h_NJets_hm_us_nis        != 0) h_NJets_hm_us       -> Add(h_NJets_hm_us_is        , h_NJets_hm_us_nis,1,1);
    if(h_MuJetMass_hm_us_nis    != 0) h_MuJetMass_hm_us   -> Add(h_MuJetMass_hm_us_is    , h_MuJetMass_hm_us_nis,1,1);

    if(h_MuJetDR_hm_ls_nis      != 0) h_MuJetDR_hm_ls     -> Add(h_MuJetDR_hm_ls_is      , h_MuJetDR_hm_ls_nis,1,1);
    if(h_MuJetPt_hm_ls_nis      != 0) h_MuJetPt_hm_ls     -> Add(h_MuJetPt_hm_ls_is      , h_MuJetPt_hm_ls_nis,1,1);
    if(h_MuJetEt_hm_ls_nis      != 0) h_MuJetEt_hm_ls     -> Add(h_MuJetEt_hm_ls_is      , h_MuJetEt_hm_ls_nis,1,1);
    if(h_MuJetEta_hm_ls_nis     != 0) h_MuJetEta_hm_ls    -> Add(h_MuJetEta_hm_ls_is     , h_MuJetEta_hm_ls_nis,1,1);
    if(h_NJets_hm_ls_nis        != 0) h_NJets_hm_ls       -> Add(h_NJets_hm_ls_is        , h_NJets_hm_ls_nis,1,1);
    if(h_MuJetMass_hm_ls_nis    != 0) h_MuJetMass_hm_ls   -> Add(h_MuJetMass_hm_ls_is    , h_MuJetMass_hm_ls_nis,1,1);

    //Append all histos:
    if(h_MuJetDR_lm_us      != 0) file->Append( h_MuJetDR_lm_us      -> Clone("h_MuJetDR_lm_us")   );
    if(h_MuJetPt_lm_us      != 0) file->Append( h_MuJetPt_lm_us      -> Clone("h_MuJetPt_lm_us")   );
    if(h_MuJetEt_lm_us      != 0) file->Append( h_MuJetEt_lm_us      -> Clone("h_MuJetEt_lm_us")   );
    if(h_MuJetEta_lm_us     != 0) file->Append( h_MuJetEta_lm_us     -> Clone("h_MuJetEta_lm_us")   );
    if(h_NJets_lm_us        != 0) file->Append( h_NJets_lm_us        -> Clone("h_NJets_lm_us")  );
    if(h_MuJetMass_lm_us    != 0) file->Append( h_MuJetMass_lm_us    -> Clone("h_MuJetMass_lm_us") );

    if(h_MuJetDR_lm_ls      != 0) file->Append( h_MuJetDR_lm_ls      -> Clone("h_MuJetDR_lm_ls")   );
    if(h_MuJetPt_lm_ls      != 0) file->Append( h_MuJetPt_lm_ls      -> Clone("h_MuJetPt_lm_ls")   );
    if(h_MuJetEt_lm_ls      != 0) file->Append( h_MuJetEt_lm_ls      -> Clone("h_MuJetEt_lm_ls")   );
    if(h_MuJetEta_lm_ls     != 0) file->Append( h_MuJetEta_lm_ls     -> Clone("h_MuJetEta_lm_ls")   );
    if(h_NJets_lm_ls        != 0) file->Append( h_NJets_lm_ls        -> Clone("h_NJets_lm_ls")  );
    if(h_MuJetMass_lm_ls    != 0) file->Append( h_MuJetMass_lm_ls    -> Clone("h_MuJetMass_lm_ls") );

    if(h_MuJetDR_hm_us      != 0) file->Append( h_MuJetDR_hm_us      ->Clone("h_MuJetDR_hm_us")   );
    if(h_MuJetPt_hm_us      != 0) file->Append( h_MuJetPt_hm_us      ->Clone("h_MuJetPt_hm_us")   );
    if(h_MuJetEt_hm_us      != 0) file->Append( h_MuJetEt_hm_us      ->Clone("h_MuJetEt_hm_us")   );
    if(h_MuJetEta_hm_us     != 0) file->Append( h_MuJetEta_hm_us     ->Clone("h_MuJetEta_hm_us")   );
    if(h_NJets_hm_us        != 0) file->Append( h_NJets_hm_us        ->Clone("h_NJets_hm_us")  );
    if(h_MuJetMass_hm_us    != 0) file->Append( h_MuJetMass_hm_us    ->Clone("h_MuJetMass_hm_us") );

    if(h_MuJetDR_hm_ls      != 0) file->Append( h_MuJetDR_hm_ls      ->Clone("h_MuJetDR_hm_ls")   );
    if(h_MuJetPt_hm_ls      != 0) file->Append( h_MuJetPt_hm_ls      ->Clone("h_MuJetPt_hm_ls")   );
    if(h_MuJetEt_hm_ls      != 0) file->Append( h_MuJetEt_hm_ls      ->Clone("h_MuJetEt_hm_ls")   );
    if(h_MuJetEta_hm_ls     != 0) file->Append( h_MuJetEta_hm_ls     ->Clone("h_MuJetEta_hm_ls")   );
    if(h_NJets_hm_ls        != 0) file->Append( h_NJets_hm_ls        ->Clone("h_NJets_hm_ls")  );
    if(h_MuJetMass_hm_ls    != 0) file->Append( h_MuJetMass_hm_ls    ->Clone("h_MuJetMass_hm_ls") );

    // ***************************************************************************************
    // append isolated histos:
    // ***************************************************************************************
 
    if(h_MuJetDR_lm_us_is      != 0) file->Append( h_MuJetDR_lm_us_is    ->Clone("h_MuJetDR_lm_us_is") );
    if(h_MuJetPt_lm_us_is      != 0) file->Append( h_MuJetPt_lm_us_is    ->Clone("h_MuJetPt_lm_us_is") );
    if(h_MuJetEt_lm_us_is      != 0) file->Append( h_MuJetEt_lm_us_is    ->Clone("h_MuJetEt_lm_us_is") );   
    if(h_MuJetEta_lm_us_is     != 0) file->Append( h_MuJetEta_lm_us_is   ->Clone("h_MuJetEta_lm_us_is") );
    if(h_NJets_lm_us_is        != 0) file->Append( h_NJets_lm_us_is      ->Clone("h_NJets_lm_us_is") );
    if(h_MuJetMass_lm_us_is    != 0) file->Append( h_MuJetMass_lm_us_is  ->Clone("h_MuJetMass_lm_us_is") );

    if(h_MuJetDR_lm_ls_is      != 0) file->Append( h_MuJetDR_lm_ls_is    ->Clone("h_MuJetDR_lm_ls_is") );
    if(h_MuJetPt_lm_ls_is      != 0) file->Append( h_MuJetPt_lm_ls_is    ->Clone("h_MuJetPt_lm_ls_is") );
    if(h_MuJetEt_lm_ls_is      != 0) file->Append( h_MuJetEt_lm_ls_is    ->Clone("h_MuJetEt_lm_ls_is") );
    if(h_MuJetEta_lm_ls_is     != 0) file->Append( h_MuJetEta_lm_ls_is   ->Clone("h_MuJetEta_lm_ls_is") );
    if(h_NJets_lm_ls_is        != 0) file->Append( h_NJets_lm_ls_is      ->Clone("h_NJets_lm_ls_is") );
    if(h_MuJetMass_lm_ls_is    != 0) file->Append( h_MuJetMass_lm_ls_is  ->Clone("h_MuJetMass_lm_ls_is") );

    if(h_MuJetDR_hm_us_is      != 0) file->Append( h_MuJetDR_hm_us_is    ->Clone("h_MuJetDR_hm_us_is") );
    if(h_MuJetPt_hm_us_is      != 0) file->Append( h_MuJetPt_hm_us_is    ->Clone("h_MuJetPt_hm_us_is") );
    if(h_MuJetEt_hm_us_is      != 0) file->Append( h_MuJetEt_hm_us_is    ->Clone("h_MuJetEt_hm_us_is") );
    if(h_MuJetEta_hm_us_is     != 0) file->Append( h_MuJetEta_hm_us_is   ->Clone("h_MuJetEta_hm_us_is") );
    if(h_NJets_hm_us_is        != 0) file->Append( h_NJets_hm_us_is      ->Clone("h_NJets_hm_us_is") );
    if(h_MuJetMass_hm_us_is    != 0) file->Append( h_MuJetMass_hm_us_is  ->Clone("h_MuJetMass_hm_us_is") );

    if(h_MuJetDR_hm_ls_is      != 0) file->Append( h_MuJetDR_hm_ls_is    ->Clone("h_MuJetDR_hm_ls_is") );
    if(h_MuJetPt_hm_ls_is      != 0) file->Append( h_MuJetPt_hm_ls_is    ->Clone("h_MuJetPt_hm_ls_is") );
    if(h_MuJetEt_hm_ls_is      != 0) file->Append( h_MuJetEt_hm_ls_is    ->Clone("h_MuJetEt_hm_ls_is") );
    if(h_MuJetEta_hm_ls_is     != 0) file->Append( h_MuJetEta_hm_ls_is   ->Clone("h_MuJetEta_hm_ls_is") );
    if(h_NJets_hm_ls_is        != 0) file->Append( h_NJets_hm_ls_is      ->Clone("h_NJets_hm_ls_is") );
    if(h_MuJetMass_hm_ls_is    != 0) file->Append( h_MuJetMass_hm_ls_is  ->Clone("h_MuJetMass_hm_ls_is") );

    // ***************************************************************************************
    // append non-isolated histos:
    // ***************************************************************************************

    if(h_MuJetDR_lm_us_nis      != 0) file->Append( h_MuJetDR_lm_us_nis      ->Clone("h_MuJetDR_lm_us_nis")  );
    if(h_MuJetPt_lm_us_nis      != 0) file->Append( h_MuJetPt_lm_us_nis      ->Clone("h_MuJetPt_lm_us_nis")  );
    if(h_MuJetEt_lm_us_nis      != 0) file->Append( h_MuJetEt_lm_us_nis      ->Clone("h_MuJetEt_lm_us_nis")  );
    if(h_MuJetEta_lm_us_nis     != 0) file->Append( h_MuJetEta_lm_us_nis     ->Clone("h_MuJetEta_lm_us_nis")  );
    if(h_NJets_lm_us_nis        != 0) file->Append( h_NJets_lm_us_nis        ->Clone("h_NJets_lm_us_nis") );
    if(h_MuJetMass_lm_us_nis    != 0) file->Append( h_MuJetMass_lm_us_nis    ->Clone("h_MuJetMass_lm_us_nis") );

    if(h_MuJetDR_lm_ls_nis      != 0) file->Append( h_MuJetDR_lm_ls_nis      ->Clone("h_MuJetDR_lm_ls_nis")  );
    if(h_MuJetPt_lm_ls_nis      != 0) file->Append( h_MuJetPt_lm_ls_nis      ->Clone("h_MuJetPt_lm_ls_nis")  );
    if(h_MuJetEt_lm_ls_nis      != 0) file->Append( h_MuJetEt_lm_ls_nis      ->Clone("h_MuJetEt_lm_ls_nis")  );
    if(h_MuJetEta_lm_ls_nis     != 0) file->Append( h_MuJetEta_lm_ls_nis     ->Clone("h_MuJetEta_lm_ls_nis")  );
    if(h_NJets_lm_ls_nis        != 0) file->Append( h_NJets_lm_ls_nis        ->Clone("h_NJets_lm_ls_nis") );
    if(h_MuJetMass_lm_ls_nis    != 0) file->Append( h_MuJetMass_lm_ls_nis    ->Clone("h_MuJetMass_lm_ls_nis") );

    if(h_MuJetDR_hm_us_nis      != 0) file->Append( h_MuJetDR_hm_us_nis      ->Clone("h_MuJetDR_hm_us_nis")  );
    if(h_MuJetPt_hm_us_nis      != 0) file->Append( h_MuJetPt_hm_us_nis      ->Clone("h_MuJetPt_hm_us_nis")  );
    if(h_MuJetEt_hm_us_nis      != 0) file->Append( h_MuJetEt_hm_us_nis      ->Clone("h_MuJetEt_hm_us_nis")  );
    if(h_MuJetEta_hm_us_nis     != 0) file->Append( h_MuJetEta_hm_us_nis     ->Clone("h_MuJetEta_hm_us_nis")  );
    if(h_NJets_hm_us_nis        != 0) file->Append( h_NJets_hm_us_nis        ->Clone("h_NJets_hm_us_nis") );
    if(h_MuJetMass_hm_us_nis    != 0) file->Append( h_MuJetMass_hm_us_nis    ->Clone("h_MuJetMass_hm_us_nis") );

    if(h_MuJetDR_hm_ls_nis      != 0) file->Append( h_MuJetDR_hm_ls_nis      ->Clone("h_MuJetDR_hm_ls_nis")  );
    if(h_MuJetPt_hm_ls_nis      != 0) file->Append( h_MuJetPt_hm_ls_nis      ->Clone("h_MuJetPt_hm_ls_nis")  );
    if(h_MuJetEt_hm_ls_nis      != 0) file->Append( h_MuJetEt_hm_ls_nis      ->Clone("h_MuJetEt_hm_ls_nis")  );
    if(h_MuJetEta_hm_ls_nis     != 0) file->Append( h_MuJetEta_hm_ls_nis     ->Clone("h_MuJetEta_hm_ls_nis")  );
    if(h_NJets_hm_ls_nis        != 0) file->Append( h_NJets_hm_ls_nis        ->Clone("h_NJets_hm_ls_nis") );
    if(h_MuJetMass_hm_ls_nis    != 0) file->Append( h_MuJetMass_hm_ls_nis    ->Clone("h_MuJetMass_hm_ls_nis") );
 
  }
  file->Write();
  file->Close();
  gROOT->ProcessLine(".q");
}

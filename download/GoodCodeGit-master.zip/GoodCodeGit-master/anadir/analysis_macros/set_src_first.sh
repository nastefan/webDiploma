#!/bin/sh

# for dimuon
cp src_first/oli_to_danny_dimuon.C ./
cp src_first/oli_to_danny_dimuon_mymodify.h ./inc/oli_to_danny_dimuon_mymodify.h

# for secvtx
cp src_first/oli_to_danny_secvtx.C ./
cp src_first/oli_to_danny_secvtx_mymodify.h ./inc/oli_to_danny_secvtx_mymodify.h
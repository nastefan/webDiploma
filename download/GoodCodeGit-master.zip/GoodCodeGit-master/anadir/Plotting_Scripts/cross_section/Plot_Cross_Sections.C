#include <stdio.h>
#include <iostream.h>
#include <TH1D.h>
#include <TCanvas.h>
#include <TColor.h>

using namespace std;

Bool_t Plot_Cross_Sections(){

  /// set styling
  TStyle *zeus_style = gInclude->ZEUSSetStyle();
  gROOT->SetStyle("zeus_pub");
  zeus_pub->SetPadRightMargin(0.05);
  zeus_pub->SetPadLeftMargin(0.2);
  zeus_pub->SetPadTopMargin(0.16);
  zeus_pub->SetPadBottomMargin(0.16);
  gStyle->SetEndErrorSize(3);
  gROOT->Reset();

  TColor * redish    = new TColor(22222, 255./255., 175./255., 155./255.);
  TColor * blueish   = new TColor(  444, 163./255., 167./255., 255./255.);
  TColor * yellowish = new TColor(  555, 255./255., 255./255., 160./255.);
  TColor * greenish  = new TColor(  333, 165./255., 255./255., 150./255.);
  TColor * blackish  = new TColor(  111, 168./255., 168./255., 168./255.);

  gErrorIgnoreLevel = 1;

  /// set local folder to save plots;
  string data;
  string line;
  ifstream myfile ("/nfs/dust/zeus/group/stefan/outputdir/Plots/date_file.txt");
  if (myfile.is_open()) {
    while ( getline (myfile,line) )
    {
        data = line;
    }
    myfile.close();
  }

  Bool_t MBtakeON      = true;
  Bool_t binwdivide    = true;
  Bool_t plot_syserror = false;

  const Int_t nr_xsecs = 11;

  Double_t xsec_binw = 0;
  Double_t xsec_binc = 0;
  Double_t xsec_bine = 0;

  Double_t truee_draw_binw = 0;
  Double_t truee_draw_binc = 0;
  Double_t truee_draw_bine = 0;

  Double_t xsec_max       = 0;
  Double_t truee_draw_max = 0;

  Double_t data_lumi       = 376.61; // Sum Lumi 05e,06e,06/07p
  Double_t data_lumi_03_04 =  40.59; // 03-04 data e+
  Double_t data_lumi_05_06 = 190.12; // 05-06 data e-
  Double_t data_lumi_06_07 = 145.90; // 06-07 data e+

  if(MBtakeON)
    {
      cout<<(char)27<<"[06;33m"<<"WARNING!! assuming MBtake to be ON and reducing the lumi values accordingly."<<(char)27<<"[0m"<<endl;
      data_lumi_03_04 =  40.59;          // 03-04 data e+
      data_lumi_05_06 = 190.12;          // 05-06 data e-
      data_lumi_06_07 = 145.90;          // 06-07 data e+
      data_lumi       = data_lumi_03_04 + data_lumi_05_06 + data_lumi_06_07; // sum of used preupgrade years
    }

  cout<<"data_lumi 03p-07p is: "<<data_lumi<<endl;

  Double_t tracks = 4.;

  if(tracks>= 4. && tracks <= 4.){
    cout<<"Grosses Kino, 4 = 4 " << tracks << endl;
  }

  if(plot_syserror){// values from Oli
    cout<<(char)27<<"[06;33m"<<"Plotting a 30 percent systematic symmetric error."<<(char)27<<"[0m"<<endl;
  }
  if(!binwdivide){// values from Oli
    cout<<(char)27<<"[06;33m"<<"WARNING!! The xsec normalisation (binwdivide) is OFF!! - continue by pressing enter."<<(char)27<<"[0m"<<endl;
    //    getchar();
  }
  Double_t intbuffer, errbuffer, newerror, newerror2;
  TH1D* uData_m_bg_m_lData_hm[nr_xsecs];
  TH1D* uMC_p_lMC_hm[nr_xsecs];
  TH1D* uMC_m_lMC_hm[nr_xsecs];
  TH1D* true_hm[nr_xsecs];
  TH1D* true_lm[nr_xsecs];
  TH1D* recMC_hm[nr_xsecs];
  TH1D* uData_m_bg_m_lData_lm[nr_xsecs];
  TH1D* uMC_p_lMC_lm[nr_xsecs];
  TH1D* uMC_m_lMC_lm[nr_xsecs];
  TH1D* recMC_lm[nr_xsecs];

  TH1D* uData_m_bg_m_lData[nr_xsecs];
  TH1D* uMC_p_lMC[nr_xsecs];
  TH1D* uMC_m_lMC[nr_xsecs];
  TH1D* uMC_p_lMC_div_uMC_m_lMC[nr_xsecs];
  TH1D* recDATA[nr_xsecs];
  TH1D* truee[nr_xsecs];
  TH1D* recMC[nr_xsecs];
  TH1D* acceptance[nr_xsecs];
  TH1D* purity[nr_xsecs];
  TH1D* buffer1[nr_xsecs];
  TH1D* buffer2[nr_xsecs];

  TH1D* uppersyserror[nr_xsecs];
  TH1D* uppersyserror2[nr_xsecs];

  TH1D* xsec[nr_xsecs]      ;
  TH1D* xsec_age[nr_xsecs]  ;
  TH1D* xsec_age_legend[nr_xsecs]  ;
  TH1D* xsec_NLO[nr_xsecs]  ;
  TH1D* truee_draw[nr_xsecs];

  TCanvas *cccc[nr_xsecs];
  TString openthis;

  Bool_t *skip_binwdiv[nr_xsecs];

  //     for( Int_t xloop = 1; xloop < nr_xsecs; ++xloop ){
    for( Int_t xloop = 0; xloop < 6; ++xloop ){


	if (xloop !=1 /*&& xloop !=2*/) {continue;}

    openthis="uData_m_bg_m_lData_hm_"  ;
    openthis+=xloop                    ;
    uData_m_bg_m_lData_hm[xloop]    = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="uMC_p_lMC_hm_"           ;
    openthis+=xloop                    ;
    uMC_p_lMC_hm[xloop]             = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="uMC_m_lMC_hm_"           ;
    openthis+=xloop                    ;
    uMC_m_lMC_hm[xloop]             = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="true_hm_"                ;
    openthis+=xloop                    ;
    true_hm[xloop]                  = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="recMC_hm_"               ;
    openthis+=xloop                    ;
    recMC_hm[xloop]                 = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="uData_m_bg_m_lData_lm_"  ;
    openthis+=xloop                    ;
    uData_m_bg_m_lData_lm[xloop]    = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="uMC_p_lMC_lm_"           ;
    openthis+=xloop                    ;
    uMC_p_lMC_lm[xloop]             = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="uMC_m_lMC_lm_"           ;
    openthis+=xloop                    ;
    uMC_m_lMC_lm[xloop]             = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="recMC_lm_"               ;
    openthis+=xloop                    ;
    recMC_lm[xloop]                 = (TH1D*) gInclude->ReadinHisto(openthis );
    openthis="true_lm_"                ;
    openthis+=xloop                    ;
    true_lm[xloop]                  = (TH1D*) gInclude->ReadinHisto(openthis );


    uData_m_bg_m_lData_hm[xloop]  ->ls();
    uMC_p_lMC_hm[xloop]           ->ls();
    uMC_m_lMC_hm[xloop]           ->ls();
    true_hm[xloop]                ->ls();
    recMC_hm[xloop]               ->ls();
    uData_m_bg_m_lData_lm[xloop]  ->ls();
    uMC_p_lMC_lm[xloop]           ->ls();
    uMC_m_lMC_lm[xloop]           ->ls();
    true_lm[xloop]                ->ls();
    recMC_lm[xloop]               ->ls();


    // add high and low mass distribs:

    uData_m_bg_m_lData[xloop] = (TH1D*) uData_m_bg_m_lData_hm[xloop]->Clone("uData_m_bg_m_lData");
    uData_m_bg_m_lData[xloop] -> Add(uData_m_bg_m_lData_lm[xloop],1.);

    cout<<"Different Data: " << uData_m_bg_m_lData[xloop]->Integral() << endl;

    uMC_p_lMC[xloop] = (TH1D*) uMC_p_lMC_hm[xloop]->Clone("uMC_p_lMC");
    uMC_p_lMC[xloop] -> Add(uMC_p_lMC_lm[xloop],1.);
    uMC_m_lMC[xloop] = (TH1D*) uMC_m_lMC_hm[xloop]->Clone("uMC_m_lMC");
    uMC_m_lMC[xloop] -> Add(uMC_m_lMC_lm[xloop],1.);

    cout<<"Summe MC:     " << uMC_p_lMC[xloop]->Integral() << endl;
    cout<<"Differenz MC: " << uMC_m_lMC[xloop]->Integral() << endl;

    recMC[xloop] = (TH1D*) recMC_hm[xloop]->Clone("recMC");
    recMC[xloop] -> Add(recMC_lm[xloop],1.);

    cout<<"Rekonstr. MC: " << recMC[xloop]->Integral() << endl;

// divide sum and difference of bMC
    uMC_p_lMC_div_uMC_m_lMC[xloop] = (TH1D*) uMC_p_lMC[xloop]->Clone("uMC_p_lMC_div_uMC_m_lMC");
    uMC_p_lMC_div_uMC_m_lMC[xloop] -> Divide(uMC_m_lMC[xloop]);

    cout<<"Beauty Skalierung: "<< uMC_p_lMC_div_uMC_m_lMC[xloop]->Integral() << endl;

// multiply division of b mc to data_u-l
    recDATA[xloop] = (TH1D*) uData_m_bg_m_lData[xloop]->Clone("recDATA");
    recDATA[xloop] -> Multiply( uMC_p_lMC_div_uMC_m_lMC[xloop] );

    cout<<"Rekonstr. Daten: "<< recDATA[xloop]->Integral() << endl;

    // calculate acceptance (recMC/truee):
    truee[xloop]      = (TH1D*) true_hm[xloop]->Clone("truee");

    cout<<"True Events vorher: "<< truee[xloop]->Integral() << endl;

    acceptance[xloop] = (TH1D*) recMC[xloop]->Clone("acceptance");
    acceptance[xloop] -> Divide(truee[xloop]);


    purity[xloop] = (TH1D*) recMC_hm[xloop]->Clone("purity");
    purity[xloop] -> Add(recMC_lm[xloop],1.);
    purity[xloop] -> Add(true_hm[xloop],1.);
    purity[xloop] -> Divide(recMC[xloop]);

    cout<<"Berechnete Akzeptanz: " << acceptance[xloop]->Integral() << endl;

// divide recDATA (B events) by acceptance and Lumi:
    xsec[xloop] = (TH1D*) recDATA[xloop]->Clone("xsec");
    xsec[xloop] -> Divide(acceptance[xloop]);
    xsec[xloop] -> Scale(1./data_lumi);

// also lumi weight true info:
    truee_draw[xloop] = (TH1D*) truee[xloop]->Clone("truee_draw");
    truee_draw[xloop] -> Scale(1./data_lumi);

    cout<<" "<<endl;
    cout<<"Wirkungsquerschnitt ist: "<< xsec[xloop]->Integral() << endl;
    cout<<"Akzeptanz ist:           "<< acceptance[xloop]->Integral() << endl;
    cout<<"Anzahl True Events ist:  "<< truee[xloop]->Integral() << endl;
    cout<<"Anzahl Data Events ist:  "<< recDATA[xloop]->Integral() << endl;
    cout<<"Anzahl MC Events ist:    "<< recMC[xloop]->Integral() << endl;
    cout<<"Lumi gew. True Events:   "<< truee_draw[xloop]->Integral() << endl;


    xsec_age_legend[xloop] = (TH1D*) xsec[xloop]->Clone("xsec_age_legend");
    xsec_age_legend[xloop]->SetMarkerColor(4);
    xsec_age_legend[xloop]->SetMarkerSize(1.2);
    xsec_age_legend[xloop]->SetMarkerStyle(22);

// set flag for xsecs not to be divided by binwidth
    if( xsec[xloop]->GetNbinsX() == 1  ||
        xsec[xloop]->GetNbinsX() == 40 ||
        xloop == 6 || xloop == 7 ||
        xloop == 8 || xloop == 9)  skip_binwdiv[xloop] = true;

    else skip_binwdiv[xloop] = false;

//loop over bins of xsec to divide by binwidth:
    if(binwdivide){
      for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){

	if( skip_binwdiv[xloop] ) continue;

	xsec_binw = 0;
	xsec_binc = 0;
	xsec_bine = 0;

	xsec_binw =  xsec[xloop]->GetXaxis()->GetBinWidth(iii);
	xsec_binc =  xsec[xloop]->GetBinContent(iii);
	xsec_bine =  xsec[xloop]->GetBinError(iii);

	xsec_binc = xsec_binc / xsec_binw;
	xsec_bine = xsec_bine / xsec_binw;

	xsec[xloop]->SetBinContent(iii,xsec_binc);
	xsec[xloop]->SetBinError(iii,xsec_bine);

      }
    }

  //loop over bins of truee_draw to divide by binwidth:

  if(binwdivide){
      for(Int_t iii = 1; iii <= truee_draw[xloop]->GetNbinsX(); ++iii){
	if( skip_binwdiv[xloop] )continue;

	truee_draw_binw = 0;
	truee_draw_binc = 0;
	truee_draw_bine = 0;

	truee_draw_binw =  truee_draw[xloop]->GetXaxis()->GetBinWidth(iii);
	truee_draw_binc =  truee_draw[xloop]->GetBinContent(iii);
	truee_draw_bine =  truee_draw[xloop]->GetBinError(iii);

	truee_draw_binc = truee_draw_binc / truee_draw_binw;
	truee_draw_bine = truee_draw_bine / truee_draw_binw;

	truee_draw[xloop]->SetBinContent(iii,truee_draw_binc);
	truee_draw[xloop]->SetBinError(iii,truee_draw_bine);

      }
    }

    xsec_max       = xsec[xloop]       -> GetMaximum()*1.3;
    truee_draw_max = truee_draw[xloop] -> GetMaximum()*1.3;

    truee_draw[xloop]->SetLineWidth(3);
    truee_draw[xloop]->SetLineColor(2);

    xsec[xloop]->SetMarkerStyle(8);
    xsec[xloop]->SetMarkerSize(1.2);
    xsec[xloop]->SetMarkerColor(1);

    if(xloop == 0)  {
      xsec[xloop]->GetYaxis()->SetTitle("visible crossection (pb)");
      xsec[xloop]->GetXaxis()->SetTitle("arb. units");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);
    }

    if(xloop == 1)  {

      xsec[xloop]->GetYaxis()->SetTitle("d#sigma/dp_{T}^{#mu} [pb/GeV]");
      xsec[xloop]->GetYaxis()->SetRangeUser(0.2,150.);
      xsec[xloop]->GetXaxis()->SetTitle("p_{T}^{#mu} [GeV]");
      xsec[xloop]->GetXaxis()->SetTitleSize(0.06);
      xsec[xloop]->GetYaxis()->SetTitleSize(0.06);
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(0.8);

      Double_t xAxis_1[7] = {1.5, 2.0, 2.5, 3.0, 3.5, 5.0, 10.};

      TH1D *xsec_NLO_center_1 = new TH1D("xsec_NLO_center_1","hu dimuxsecpt_nis",6, xAxis_1);
      xsec_NLO_center_1->SetBinContent(1, 27.2347);
      xsec_NLO_center_1->SetBinContent(2, 15.5659);
      xsec_NLO_center_1->SetBinContent(3,  9.6352);
      xsec_NLO_center_1->SetBinContent(4,  5.7510);
      xsec_NLO_center_1->SetBinContent(5,  2.5293);
      xsec_NLO_center_1->SetBinContent(6,  0.3384);
      xsec_NLO_center_1->SetBinError(1,0.001);
      xsec_NLO_center_1->SetBinError(2,0.001);
      xsec_NLO_center_1->SetBinError(3,0.001);
      xsec_NLO_center_1->SetBinError(4,0.001);
      xsec_NLO_center_1->SetBinError(5,0.001);
      xsec_NLO_center_1->SetBinError(6,0.001);

      TH1D *xsec_NLO_upper_1 = new TH1D("xsec_NLO_upper_1","hu dimuxsecpt_nis",6, xAxis_1);
      xsec_NLO_upper_1->SetBinContent(1, 36.9886);
      xsec_NLO_upper_1->SetBinContent(2, 20.6343);
      xsec_NLO_upper_1->SetBinContent(3, 11.9370);
      xsec_NLO_upper_1->SetBinContent(4,  7.3710);
      xsec_NLO_upper_1->SetBinContent(5,  3.1540);
      xsec_NLO_upper_1->SetBinContent(6,  0.4151);
      xsec_NLO_upper_1->SetBinError(1, 0.001);
      xsec_NLO_upper_1->SetBinError(2, 0.001);
      xsec_NLO_upper_1->SetBinError(3, 0.001);
      xsec_NLO_upper_1->SetBinError(4, 0.001);
      xsec_NLO_upper_1->SetBinError(5, 0.001);
      xsec_NLO_upper_1->SetBinError(6, 0.001);

      TH1D *xsec_NLO_lower_1 = new TH1D("xsec_NLO_lower_1","hu dimuxsecpt_nis",6, xAxis_1);
      xsec_NLO_lower_1->SetBinContent(1, 22.4580);
      xsec_NLO_lower_1->SetBinContent(2, 13.1356);
      xsec_NLO_lower_1->SetBinContent(3,  7.7696);
      xsec_NLO_lower_1->SetBinContent(4,  4.8842);
      xsec_NLO_lower_1->SetBinContent(5,  2.2500);
      xsec_NLO_lower_1->SetBinContent(6,  0.3026);
      xsec_NLO_lower_1->SetBinError(1, 0.001);
      xsec_NLO_lower_1->SetBinError(2, 0.001);
      xsec_NLO_lower_1->SetBinError(3, 0.001);
      xsec_NLO_lower_1->SetBinError(4, 0.001);
      xsec_NLO_lower_1->SetBinError(5, 0.001);
      xsec_NLO_lower_1->SetBinError(6, 0.001);

      leg = new TLegend(0.606322,0.633475,0.918103,0.790254,NULL,"brNDC");
      leg->SetLineColor(1);
      leg->SetLineStyle(1);
      leg->SetLineWidth(1);
      leg->SetFillColor(0);
      leg->SetFillStyle(0);
      leg->SetBorderSize(0);
      leg->AddEntry(xsec[xloop],"ZEUS data 03p-07p","pe");
      leg->AddEntry(xsec_age_legend[xloop],"ZEUS data 96p-00p","pe");
      leg->AddEntry(truee_draw[xloop],"(PYTHIA+RAPGAP) x 1.9","l");
      leg->AddEntry(xsec_NLO_center_1,"NLO QCD","fl");

    }

    if(xloop == 2)  {
      xsec[xloop]->GetYaxis()->SetTitle("d#sigma/d#eta^{#mu} [pb]");
      xsec[xloop]->GetXaxis()->SetTitle("#eta^{#mu}");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetRangeUser(0.,50);

      Double_t xAxis_2[7] = {-2.2, -1.2, -0.6, 0.0, 0.6, 1.2, 2.5};

      TH1D *xsec_NLO_center_2 = new TH1D("xsec_NLO_center_2","hu dimuxseceta_nis",6, xAxis_2);
      xsec_NLO_center_2->SetBinContent(1,  1.7945);
      xsec_NLO_center_2->SetBinContent(2,  6.5347);
      xsec_NLO_center_2->SetBinContent(3,  9.4218);
      xsec_NLO_center_2->SetBinContent(4, 11.3589);
      xsec_NLO_center_2->SetBinContent(5, 11.0571);
      xsec_NLO_center_2->SetBinContent(6,  7.6096);
      xsec_NLO_center_2->SetBinError(1,0.001);
      xsec_NLO_center_2->SetBinError(2,0.001);
      xsec_NLO_center_2->SetBinError(3,0.001);
      xsec_NLO_center_2->SetBinError(4,0.001);
      xsec_NLO_center_2->SetBinError(5,0.001);
      xsec_NLO_center_2->SetBinError(6,0.001);

      TH1D *xsec_NLO_upper_2 = new TH1D("xsec_NLO_upper_2","hu dimuxseceta_nis",6, xAxis_2);
      xsec_NLO_upper_2->SetBinContent(1,  2.3193);
      xsec_NLO_upper_2->SetBinContent(2,  8.3682);
      xsec_NLO_upper_2->SetBinContent(3, 11.9357);
      xsec_NLO_upper_2->SetBinContent(4, 14.8043);
      xsec_NLO_upper_2->SetBinContent(5, 14.5701);
      xsec_NLO_upper_2->SetBinContent(6, 10.2255);
      xsec_NLO_upper_2->SetBinError(1,0.001);
      xsec_NLO_upper_2->SetBinError(2,0.001);
      xsec_NLO_upper_2->SetBinError(3,0.001);
      xsec_NLO_upper_2->SetBinError(4,0.001);
      xsec_NLO_upper_2->SetBinError(5,0.001);
      xsec_NLO_upper_2->SetBinError(6,0.001);

      TH1D *xsec_NLO_lower_2 = new TH1D("xsec_NLO_upper_2","hu dimuxseceta_nis",6, xAxis_2);
      xsec_NLO_lower_2->SetBinContent(1,  1.5117);
      xsec_NLO_lower_2->SetBinContent(2,  5.6488);
      xsec_NLO_lower_2->SetBinContent(3,  8.0127);
      xsec_NLO_lower_2->SetBinContent(4,  9.5728);
      xsec_NLO_lower_2->SetBinContent(5,  9.3190);
      xsec_NLO_lower_2->SetBinContent(6,  6.2398);
      xsec_NLO_lower_2->SetBinError(1,0.001);
      xsec_NLO_lower_2->SetBinError(2,0.001);
      xsec_NLO_lower_2->SetBinError(3,0.001);
      xsec_NLO_lower_2->SetBinError(4,0.001);
      xsec_NLO_lower_2->SetBinError(5,0.001);
      xsec_NLO_lower_2->SetBinError(6,0.001);


      leg = new TLegend(0.252874,0.644068,0.622126,0.792373,NULL,"brNDC");
      leg->SetLineColor(1);
      leg->SetLineStyle(1);
      leg->SetLineWidth(1);
      leg->SetFillColor(0);
      leg->SetFillStyle(0);
      leg->SetBorderSize(0);
      leg->AddEntry(xsec[xloop],"ZEUS data 03p-07p","pe");
      leg->AddEntry(xsec_age_legend[xloop],"ZEUS data 96p-00p","pe");
      leg->AddEntry(truee_draw[xloop],"(PYTHIA+RAPGAP) x 1.9","l");
      leg->AddEntry(xsec_NLO_center_2,"NLO QCD","fl");
    }

    if(xloop == 3)  {
      xsec[xloop]->GetYaxis()->SetTitle("#sigma^{vis}(finderX) (pb)");
      xsec[xloop]->GetXaxis()->SetTitle("finderX");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetRangeUser(0.,120);
    }

    if(xloop == 4)  {
      xsec[xloop]->GetYaxis()->SetTitle("d#sigma/d#DeltaR^{#mu#mu} [pb]");
      xsec[xloop]->GetXaxis()->SetTitle("#DeltaR^{#mu#mu}");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);


      Double_t xAxis_4[8] = {0.0, 1.0, 1.5, 2.0, 2.4, 2.8, 3.2, 4.0};
      /*
      TH1D *xsec_NLO_center_4 = new TH1D("xsec_NLO_center_4","hu dimuxsecdr_nis",7, xAxis_4);
      xsec_NLO_center_4->SetBinContent(1, xxxxxxx);
      xsec_NLO_center_4->SetBinContent(2, xxxxxxx);
      xsec_NLO_center_4->SetBinContent(3, xxxxxxx);
      xsec_NLO_center_4->SetBinContent(4, xxxxxxx);
      xsec_NLO_center_4->SetBinContent(5, xxxxxxx);
      xsec_NLO_center_4->SetBinContent(6, xxxxxxx);
      xsec_NLO_center_4->SetBinContent(7, xxxxxxx);
      xsec_NLO_center_4->SetBinError(1,0.001);
      xsec_NLO_center_4->SetBinError(2,0.001);
      xsec_NLO_center_4->SetBinError(3,0.001);
      xsec_NLO_center_4->SetBinError(4,0.001);
      xsec_NLO_center_4->SetBinError(5,0.001);
      xsec_NLO_center_4->SetBinError(6,0.001);
      xsec_NLO_center_4->SetBinError(7,0.001);

      TH1D *xsec_NLO_upper_4 = new TH1D("xsec_NLO_upper_4","hu dimuxsecdr_nis",7, xAxis_4);
      xsec_NLO_upper_4->SetBinContent(1, xxxxxxx);
      xsec_NLO_upper_4->SetBinContent(2, xxxxxxx);
      xsec_NLO_upper_4->SetBinContent(3, xxxxxxx);
      xsec_NLO_upper_4->SetBinContent(4, xxxxxxx);
      xsec_NLO_upper_4->SetBinContent(5, xxxxxxx);
      xsec_NLO_upper_4->SetBinContent(6, xxxxxxx);
      xsec_NLO_upper_4->SetBinContent(7, xxxxxxx);
      xsec_NLO_upper_4->SetBinError(1,0.001);
      xsec_NLO_upper_4->SetBinError(2,0.001);
      xsec_NLO_upper_4->SetBinError(3,0.001);
      xsec_NLO_upper_4->SetBinError(4,0.001);
      xsec_NLO_upper_4->SetBinError(5,0.001);
      xsec_NLO_upper_4->SetBinError(6,0.001);
      xsec_NLO_upper_4->SetBinError(7,0.001);

      TH1D *xsec_NLO_lower_4 = new TH1D("xsec_NLO_lower_4","hu dimuxsecdr_nis",7, xAxis_4);
      xsec_NLO_lower_4->SetBinContent(1, xxxxxxx);
      xsec_NLO_lower_4->SetBinContent(2, xxxxxxx);
      xsec_NLO_lower_4->SetBinContent(3, xxxxxxx);
      xsec_NLO_lower_4->SetBinContent(4, xxxxxxx);
      xsec_NLO_lower_4->SetBinContent(5, xxxxxxx);
      xsec_NLO_lower_4->SetBinContent(6, xxxxxxx);
      xsec_NLO_lower_4->SetBinContent(7, xxxxxxx);
      xsec_NLO_lower_4->SetBinError(1,0.001);
      xsec_NLO_lower_4->SetBinError(2,0.001);
      xsec_NLO_lower_4->SetBinError(3,0.001);
      xsec_NLO_lower_4->SetBinError(4,0.001);
      xsec_NLO_lower_4->SetBinError(5,0.001);
      xsec_NLO_lower_4->SetBinError(6,0.001);
      xsec_NLO_lower_4->SetBinError(7,0.001);
      */
      leg = new TLegend(0.258621,0.625,0.576149,0.798729,NULL,"brNDC");
      leg->SetLineColor(1);
      leg->SetLineStyle(1);
      leg->SetLineWidth(1);
      leg->SetFillColor(0);
      leg->SetFillStyle(0);
      leg->SetBorderSize(0);
      leg->AddEntry(xsec[xloop],"ZEUS data 03p-07p","pe");
      leg->AddEntry(xsec_age_legend[xloop],"ZEUS data 96p-00p","pe");
      leg->AddEntry(truee_draw[xloop],"(PYTHIA+RAPGAP) x 1.9","l");
      //    leg->AddEntry(xsec_NLO_center_4,"NLO QCD","fl");

    }

    if(xloop == 5)  {
      xsec[xloop]->GetYaxis()->SetTitle("d#sigma/d#Delta#phi^{#mu#mu} [pb]");
      xsec[xloop]->GetXaxis()->SetTitle("#Delta#phi^{#mu#mu}");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);


      Double_t xAxis_5[6] = {0.0, 1.047198, 1.570796, 2.094395, 2.617994, 3.141593};

      TH1D *xsec_NLO_center_5 = new TH1D("xsec_NLO_center5","hu dimuxsecdphi_nis",5, xAxis_5);
      Double_t scaleNLO = 1.;
      xsec_NLO_center_5->SetBinContent(1, scaleNLO*( 0.698+0.81 )/2      ); // bin, value
      xsec_NLO_center_5->SetBinError(1,   0.01      );
      xsec_NLO_center_5->SetBinContent(2, scaleNLO*1.436       ); // bin, value
      xsec_NLO_center_5->SetBinError(2,  0.01      );
      xsec_NLO_center_5->SetBinContent(3, scaleNLO*3.54      ); // bin, value
      xsec_NLO_center_5->SetBinError(3,  0.01      );
      xsec_NLO_center_5->SetBinContent(4, scaleNLO*7.088       ); // bin, value
      xsec_NLO_center_5->SetBinError(4,    0.01      );
      xsec_NLO_center_5->SetBinContent(5, scaleNLO*12.94      ); // bin, value
      xsec_NLO_center_5->SetBinError(5,    0.01      );

      TH1D *xsec_NLO_upper_5 = new TH1D("xsec_NLO_upper5","hu dimuxsecdphi_nis",5, xAxis_5);

      xsec_NLO_upper_5->SetBinContent(1, scaleNLO*( 1.108+1.377 )/2      ); // bin, value
      xsec_NLO_upper_5->SetBinError(1,   0.01      );
      xsec_NLO_upper_5->SetBinContent(2, scaleNLO*2.199       ); // bin, value
      xsec_NLO_upper_5->SetBinError(2,  0.01      );
      xsec_NLO_upper_5->SetBinContent(3, scaleNLO*4.721      ); // bin, value
      xsec_NLO_upper_5->SetBinError(3,  0.01      );
      xsec_NLO_upper_5->SetBinContent(4, scaleNLO*9.167       ); // bin, value
      xsec_NLO_upper_5->SetBinError(4,    0.01      );
      xsec_NLO_upper_5->SetBinContent(5, scaleNLO*15.494      ); // bin, value
      xsec_NLO_upper_5->SetBinError(5,    0.01      );

      TH1D *xsec_NLO_lower_5 = new TH1D("xsec_NLO_lower5","hu dimuxsecdphi_nis",5, xAxis_5);

      xsec_NLO_lower_5->SetBinContent(1, scaleNLO*( 0.481+0.564 )/2      ); // bin, value
      xsec_NLO_lower_5->SetBinError(1,   0.01      );
      xsec_NLO_lower_5->SetBinContent(2, scaleNLO*1.014       ); // bin, value
      xsec_NLO_lower_5->SetBinError(2,  0.01      );
      xsec_NLO_lower_5->SetBinContent(3, scaleNLO*2.698      ); // bin, value
      xsec_NLO_lower_5->SetBinError(3,  0.01      );
      xsec_NLO_lower_5->SetBinContent(4, scaleNLO*5.586       ); // bin, value
      xsec_NLO_lower_5->SetBinError(4,    0.01      );
      xsec_NLO_lower_5->SetBinContent(5, scaleNLO*11.669      ); // bin, value
      xsec_NLO_lower_5->SetBinError(5,    0.01      );


      leg = new TLegend(0.258621,0.625,0.576149,0.798729,NULL,"brNDC");
      leg->SetLineColor(1);
      leg->SetLineStyle(1);
      leg->SetLineWidth(1);
      leg->SetFillColor(0);
      leg->SetFillStyle(0);
      leg->SetBorderSize(0);
      leg->AddEntry(xsec[xloop],"ZEUS data 03p-07p","pe");
      leg->AddEntry(xsec_age_legend[xloop],"ZEUS data 96p-00p","pe");
      leg->AddEntry(truee_draw[xloop],"(PYTHIA+RAPGAP) x 1.9","l");
      leg->AddEntry(xsec_NLO_center_5,"NLO QCD","fl");
    }

    if(xloop == 7)  {
      xsec[xloop]->GetYaxis()->SetTitle("#sigma Bhad+#mu#mu (pb)");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetXaxis()->SetTitle("p_{T} B hadron (GeV)");

      leg = new TLegend(0.606322,0.633475,0.918103,0.790254,NULL,"brNDC");
      leg->SetLineColor(1);
      leg->SetLineStyle(1);
      leg->SetLineWidth(1);
      leg->SetFillColor(0);
      leg->SetFillStyle(0);
      leg->SetBorderSize(0);
      leg->AddEntry(xsec[xloop],"ZEUS data 03p-07p","pe");
      leg->AddEntry(truee_draw[xloop],"(PYTHIA+RAPGAP) x 1.9","l");
    }

    if(xloop == 8)  {
      xsec[xloop]->GetYaxis()->SetTitle("#sigma Bhad+#mu (pb)");
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetXaxis()->SetTitle("p_{T} B hadron (GeV)");

      leg = new TLegend(0.606322,0.633475,0.918103,0.790254,NULL,"brNDC");
      leg->SetLineColor(1);
      leg->SetLineStyle(1);
      leg->SetLineWidth(1);
      leg->SetFillColor(0);
      leg->SetFillStyle(0);
      leg->SetBorderSize(0);
      leg->AddEntry(xsec[xloop],"ZEUS data 03p-07p","pe");
      leg->AddEntry(truee_draw[xloop],"(PYTHIA+RAPGAP) x 1.9","l");
    }

    if(xloop >= 9 || xloop == 6)  {
      xsec[xloop]->GetXaxis()->SetTitleOffset(1.0);
      xsec[xloop]->GetYaxis()->SetTitleOffset(1.0);
    }

    intbuffer = xsec[xloop]->Integral();
    errbuffer = xsec[xloop]->GetBinError(1);
    cout<<"****************"<<endl<<"Integral of the b cross section plot: "<<intbuffer<<endl<<"****************"<<endl;
    cout<<"****************"<<endl<<"Error    of the b cross section plot: "<<errbuffer<<endl<<"****************"<<endl;
    cout<<"****************"<<endl<<"Total true                    events: "<<truee[xloop]->Integral()<<endl<<"****************"<<endl;

    cout<<"****************"<<endl<<"Integral of the b cross section plot: "<<xsec[xloop]->GetName()<<" "<<xsec[xloop]->Integral()<<endl<<"****************"<<endl;
    for(Int_t ii = 1; ii <= xsec[xloop]->GetNbinsX(); ++ii){
      cout<<"Bin Nr: "<<ii<<" Value / stat error: "<<xsec[xloop]->GetBinContent(ii)<<" / "<<xsec[xloop]->GetBinError(ii)<<" Acceptance: " <<acceptance[xloop]->GetBinContent(ii) <<" Purity: "  <<purity[xloop]->GetBinContent(ii)  <<endl;
    }
    cout<<"****************"<<endl<<"Bin Nr: "<<ii<<"Total true                    events: "<<truee[xloop]->Integral()<<endl<<"*****************"<<endl;

    cccc[xloop] = new TCanvas();

    if(xloop==1)  cccc[xloop]->SetLogy(1);

    if(xloop == 0) {
	xsec[xloop]->SetLineWidth(2);
	xsec[xloop]->Draw("e1");
	truee_draw[xloop]->Draw("hist same");

      // save a plot:
      string namecanv = "/nfs/dust/zeus/group/stefan/outputdir/Plots/" + data +"/" + "Cross_Section_tot_CS.gif";
      const char * c1 = namecanv.c_str();
      cccc[xloop]->SaveAs(c1);
      cout<<"xsec[xloop] saved : "<<c1<<endl;

      }

    if(xloop!=3 && xloop!=0){

      xsec[xloop]->SetLineWidth(2);
      xsec[xloop]->Draw("e1");
      leg->Draw();
      truee_draw[xloop]->Draw("hist same");
      xsec_age[xloop] = (TH1D*) xsec[xloop]->Clone("xsec_age");
      xsec_NLO[xloop] = (TH1D*) xsec[xloop]->Clone("xsec_NLO");


      if(xloop==7){
	for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){
	  cout<<"Bin "<<iii<<" has eror: "<<xsec[xloop]->GetBinError(iii)<<endl;
	}
      }
      xsec[xloop]->Draw("e1 same");
      uppersyserror[xloop] = (TH1D*) xsec[xloop]->Clone("uppersyserror");
      uppersyserror2[xloop] = (TH1D*) xsec[xloop]->Clone("uppersyserror2");

      for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){

	newerror = TMath::Sqrt( TMath::Power(uppersyserror[xloop]->GetBinError(iii),2.) + TMath::Power(uppersyserror[xloop]->GetBinContent(iii)*0.30,2.) );
	uppersyserror[xloop]->SetBinError(iii, newerror);

	newerror2 = TMath::Sqrt( TMath::Power(uppersyserror2[xloop]->GetBinError(iii),2.) + TMath::Power(uppersyserror2[xloop]->GetBinContent(iii)*0.265,2.) );
	uppersyserror2[xloop]->SetBinError(iii, newerror2);

      }

      if(plot_syserror)
	{
	  uppersyserror[xloop]->Draw("e1 same");
	  uppersyserror2[xloop]->Draw("e1 same");
	}
      cccc[xloop]->RedrawAxis();

    }

    else if(xloop==3){
      xsec[xloop]->Draw("e1");
      truee_draw[xloop]->Draw("hist same");

      buffer1[xloop] = (TH1D*) truee_draw[xloop]->Clone("buffer1");
      buffer2[xloop] = (TH1D*) truee_draw[xloop]->Clone("buffer2");
      buffer1[xloop]->SetLineWidth(2);
      buffer1[xloop]->SetLineColor(38);
      buffer2[xloop]->SetLineWidth(2);
      buffer2[xloop]->SetLineColor(38);

      buffer1[xloop]->Scale(1.32);
      buffer1[xloop]->Draw("hist same");
      buffer2[xloop]->Scale(0.72);
      buffer2[xloop]->Draw("hist same");

      xsec[xloop]->Draw("e1 same");
      xsec[xloop]->GetYaxis()->SetTickLength(0.03);
      cccc[xloop]->RedrawAxis();

      /// save a plot:
      string namecanv = "/nfs/dust/zeus/group/stefan/outputdir/Plots/" + data +"/" + "Cross_Section_finderX.gif";
      const char * c1 = namecanv.c_str();
      cccc[xloop]->SaveAs(c1);
      cout<<"xsec[xloop] saved : "<<c1<<endl;


    }


// Ingo's results

    if(xloop == 1){
// * pt, central reference value for systematics
//   vec/cr central(20) r 2*0. 43.0977 45.8343 18.7204 13.3949 4.0219 0.7826 12*0.
//   vec/cr statref(20) r 2*0. 13.6624  8.7235  4.7080  4.1488 1.2593 0.3663 12*0.


//    xsec_age[xloop]->GetXaxis()->SetLimits(1.7,2.2);

      Double_t xAxis21[7] = {1.6, 2.1, 2.6, 3.1, 3.6, 5.1, 10.};

      TH1D *xsec_age_1 = new TH1D("xsec_age_1","hu dimuxsecpt_nis",6, xAxis21);
      xsec_age_1->SetBinContent(1,43.0977);
      xsec_age_1->SetBinContent(2,45.8343);
      xsec_age_1->SetBinContent(3,18.7204);
      xsec_age_1->SetBinContent(4,13.3949);
      xsec_age_1->SetBinContent(5,4.0219);
      xsec_age_1->SetBinContent(6,0.7826);
      xsec_age_1->SetBinError(1,13.6624);
      xsec_age_1->SetBinError(2,8.7235);
      xsec_age_1->SetBinError(3,4.708);
      xsec_age_1->SetBinError(4,4.1488);
      xsec_age_1->SetBinError(5,1.2593);
      xsec_age_1->SetBinError(6,0.3663);

      xsec_age[xloop]->SetBinContent(1,43.0977); // bin, value
      xsec_age[xloop]->SetBinError(1,13.6624);

      xsec_age[xloop]->SetBinContent(2,45.8343); // bin, value
      xsec_age[xloop]->SetBinError(2,8.7235);

      xsec_age[xloop]->SetBinContent(3,18.7204); // bin, value
      xsec_age[xloop]->SetBinError(3, 4.7080);

      xsec_age[xloop]->SetBinContent(4, 13.3949); // bin, value
      xsec_age[xloop]->SetBinError(4, 4.1488);

      xsec_age[xloop]->SetBinContent(5, 4.0219 ); // bin, value
      xsec_age[xloop]->SetBinError(5, 1.2593);

      xsec_age[xloop]->SetBinContent(6, 0.7826); // bin, value
      xsec_age[xloop]->SetBinError(6, 0.3663);

    }

    if(xloop == 2){
// * eta, central reference value for systematics
//   vec/cr central(20) r 6.1650 13.4119 22.3383 22.4636 28.6291 11.8093 14*0.
//   vec/cr statref(20) r 2.2318  3.7663  5.0673  5.0568  6.7306  5.7318 14*0.

      Double_t xAxis13[7] = {-2.1, -1.1, -0.5, 0.1, 0.7, 1.3, 2.5};

      TH1D *xsec_age_2 = new TH1D("xsec_age_2","hu dimuxseceta_nis",6, xAxis13);

      xsec_age_2->SetBinContent(1,6.165);
      xsec_age_2->SetBinContent(2,13.4119);
      xsec_age_2->SetBinContent(3,22.3383);
      xsec_age_2->SetBinContent(4,22.4636);
      xsec_age_2->SetBinContent(5,28.6291);
      xsec_age_2->SetBinContent(6,11.8093);
      xsec_age_2->SetBinError(1,2.2318);
      xsec_age_2->SetBinError(2,3.7663);
      xsec_age_2->SetBinError(3,5.0673);
      xsec_age_2->SetBinError(4,5.0568);
      xsec_age_2->SetBinError(5,6.7306);
      xsec_age_2->SetBinError(6,5.7318);


      xsec_age[xloop]->SetBinContent(1,   6.1650      ); // bin, value
      xsec_age[xloop]->SetBinError(1,     2.2318      );

      xsec_age[xloop]->SetBinContent(2,   13.4119      ); // bin, value
      xsec_age[xloop]->SetBinError(2,     3.7663      );

      xsec_age[xloop]->SetBinContent(3,   22.3383      ); // bin, value
      xsec_age[xloop]->SetBinError(3,     5.0673      );

      xsec_age[xloop]->SetBinContent(4,   22.4636      ); // bin, value
      xsec_age[xloop]->SetBinError(4,     5.0568      );

      xsec_age[xloop]->SetBinContent(5,   28.6291      ); // bin, value
      xsec_age[xloop]->SetBinError(5,     6.7306      );

      xsec_age[xloop]->SetBinContent(6,   11.8093      ); // bin, value
      xsec_age[xloop]->SetBinError(6,     5.7318      );

      Double_t scaleNLO = 1.;
      xsec_NLO[xloop]->SetBinContent(1, scaleNLO*( 0.87+1.22 )/2      ); // bin, value
      xsec_NLO[xloop]->SetBinError(1,   0.01      );
      xsec_NLO[xloop]->SetBinContent(2, scaleNLO*1.93       ); // bin, value
      xsec_NLO[xloop]->SetBinError(2,  0.01      );
      xsec_NLO[xloop]->SetBinContent(3, scaleNLO*3.54      ); // bin, value
      xsec_NLO[xloop]->SetBinError(3,  0.01      );
      xsec_NLO[xloop]->SetBinContent(4, scaleNLO*8.45       ); // bin, value
      xsec_NLO[xloop]->SetBinError(4,    0.01      );
      xsec_NLO[xloop]->SetBinContent(5, scaleNLO*15.39      ); // bin, value
      xsec_NLO[xloop]->SetBinError(5,    0.01      );

    }


  if(xloop == 4 ){
// * dr central reference value for systematics
//   vec/cr central(20) r  -19.7591 10.3492 4.1262 11.1959 13.6734 17.7046 9.9643 13*0.
//   vec/cr statref(20) r  147.247  28.048  2.4706 4.4174  4.8298  8.1723  7.1992 13*0.

    Double_t xAxis4[8] = {0.1, 1.1, 1.6, 2.1, 2.5, 2.9, 3.3, 4.0};
    TH1D *xsec_age_4 = new TH1D("xsec_age_4","hu dimuxsecdr_nis",7, xAxis4);

    xsec_age_4->SetBinContent(1, -19.7591 );// bin, value
    xsec_age_4->SetBinContent(2,  10.3492 ); // bin, value
    xsec_age_4->SetBinContent(3,   4.1262 );  // bin, value
    xsec_age_4->SetBinContent(4,  11.1959 ); // bin, value
    xsec_age_4->SetBinContent(5,  13.6734 ); // bin, value
    xsec_age_4->SetBinContent(6,  17.7046 ); // bin, value
    xsec_age_4->SetBinContent(7,   9.9643 ); // bin, value
    xsec_age_4->SetBinError(1, 147.247  );
    xsec_age_4->SetBinError(2,  28.048  );
    xsec_age_4->SetBinError(3,   2.4706 );
    xsec_age_4->SetBinError(4,   4.4174 );
    xsec_age_4->SetBinError(5,   4.8298 );
    xsec_age_4->SetBinError(6,   8.1723 );
    xsec_age_4->SetBinError(7,   7.1992 );


    xsec_age[xloop]->SetBinContent(1,-19.7591        );// bin, value
    xsec_age[xloop]->SetBinError(1,  147.247         );

    xsec_age[xloop]->SetBinContent(2,  10.3492        ); // bin, value
    xsec_age[xloop]->SetBinError(2,    28.048        );

    xsec_age[xloop]->SetBinContent(3,  4.1262       );  // bin, value
    xsec_age[xloop]->SetBinError(3,    2.4706      );

    xsec_age[xloop]->SetBinContent(4,  11.1959       ); // bin, value
    xsec_age[xloop]->SetBinError(4,    4.4174       );

    xsec_age[xloop]->SetBinContent(5, 13.6734        ); // bin, value
    xsec_age[xloop]->SetBinError(5,   4.8298        );

    xsec_age[xloop]->SetBinContent(6, 17.7046        ); // bin, value
    xsec_age[xloop]->SetBinError(6,   8.1723        );

    xsec_age[xloop]->SetBinContent(7,  9.9643       ); // bin, value
    xsec_age[xloop]->SetBinError(7,    7.1992      );

  }


    if(xloop == 5 ){
// * dphi, central reference value for systematics
// *    final current:     4.2045 1.7352 6.6873 18.1019 14.5847 15*0.
// *    final statref:     1.9506 2.9367 2.8415  4.6668  9.1880 15*0.
//   vec/cr central(20) r  6.7525 2.0347 7.0465 18.3220 14.6486 15*0.
//   vec/cr statref(20) r  3.1300 3.4436 2.9939  4.7235  9.2283 15*0.

      Double_t xAxis5[6] = {0.1, 1.147198, 1.670796, 2.194395, 2.717994, 3.141593};

      TH1D *xsec_age_5 = new TH1D("xsec_age_5","hu dimuxsecdphi_nis",5, xAxis5);
      xsec_age_5->SetBinContent(1,4.2045);
      xsec_age_5->SetBinContent(2,1.7352);
      xsec_age_5->SetBinContent(3,6.6873);
      xsec_age_5->SetBinContent(4,18.1019);
      xsec_age_5->SetBinContent(5,14.5847);
      xsec_age_5->SetBinError(1,1.9506);
      xsec_age_5->SetBinError(2,2.9367);
      xsec_age_5->SetBinError(3,2.8415);
      xsec_age_5->SetBinError(4,4.6668);
      xsec_age_5->SetBinError(5,9.188);


      xsec_age[xloop]->SetBinContent(1, 4.2045      ); // bin, value
      xsec_age[xloop]->SetBinError(1,   1.9506      );

      xsec_age[xloop]->SetBinContent(2, 1.7352       ); // bin, value
      xsec_age[xloop]->SetBinError(2,  2.9367      );

      xsec_age[xloop]->SetBinContent(3, 6.6873       ); // bin, value
      xsec_age[xloop]->SetBinError(3,   2.8415      );

      xsec_age[xloop]->SetBinContent(4, 18.1019       ); // bin, value
      xsec_age[xloop]->SetBinError(4,    4.6668      );

      xsec_age[xloop]->SetBinContent(5, 14.5847       ); // bin, value
      xsec_age[xloop]->SetBinError(5,    9.1880      );

      Double_t scaleNLO = 1.;
      xsec_NLO[xloop]->SetBinContent(1, scaleNLO*( 0.87+1.22 )/2      ); // bin, value
      xsec_NLO[xloop]->SetBinError(1,   0.01      );
      xsec_NLO[xloop]->SetBinContent(2, scaleNLO*1.93       ); // bin, value
      xsec_NLO[xloop]->SetBinError(2,  0.01      );
      xsec_NLO[xloop]->SetBinContent(3, scaleNLO*3.54      ); // bin, value
      xsec_NLO[xloop]->SetBinError(3,  0.01      );
      xsec_NLO[xloop]->SetBinContent(4, scaleNLO*8.45       ); // bin, value
      xsec_NLO[xloop]->SetBinError(4,    0.01      );
      xsec_NLO[xloop]->SetBinContent(5, scaleNLO*15.39      ); // bin, value
      xsec_NLO[xloop]->SetBinError(5,    0.01      );

    }

  /*
   Double_t scaleNLO = 1.;
   xsec_NLO[xloop]->SetBinContent(1, scaleNLO*( 0.87+1.22 )/2      ); // bin, value
   xsec_NLO[xloop]->SetBinError(1,   0.01      );
   xsec_NLO[xloop]->SetBinContent(2, scaleNLO*1.93       ); // bin, value
   xsec_NLO[xloop]->SetBinError(2,  0.01      );
   xsec_NLO[xloop]->SetBinContent(3, scaleNLO*3.54      ); // bin, value
   xsec_NLO[xloop]->SetBinError(3,  0.01      );
   xsec_NLO[xloop]->SetBinContent(4, scaleNLO*8.45       ); // bin, value
   xsec_NLO[xloop]->SetBinError(4,    0.01      );

   xsec_NLO[xloop]->SetBinContent(5, scaleNLO*15.39      ); // bin, value
   xsec_NLO[xloop]->SetBinError(5,    0.01      );
  */


  //  if(xloop == 1 || xloop == 2 || xloop == 5){

    if(xloop == 5){

      xsec_NLO_upper_5->SetLineWidth(1);
      xsec_NLO_upper_5->SetLineColor(1);
      xsec_NLO_upper_5->SetFillColor(5);
      xsec_NLO_upper_5->Draw("hist same");

      xsec_NLO_center_5->SetLineWidth(1);
      xsec_NLO_center_5->SetLineColor(1);
      xsec_NLO_center_5->SetFillColor(5);
      xsec_NLO_center_5->Draw("hist same");

      xsec_NLO_lower_5->SetLineWidth(1);
      xsec_NLO_lower_5->SetLineColor(1);
      xsec_NLO_lower_5->SetFillColor(10);
      xsec_NLO_lower_5->Draw("hist same");

      xsec_age_5->SetMarkerColor(4);
      xsec_age_5->SetMarkerSize(1.2);
      xsec_age_5->SetMarkerStyle(22);
      xsec_age_5->SetLineColor(4);
      xsec_age_5->SetLineWidth(2);
      xsec_age_5->Draw("e1 same");

      uppersyserror_5 = (TH1D*) xsec_age_5->Clone("uppersyserror");
      uppersyserror2_5 = (TH1D*) xsec[xloop]->Clone("uppersyserror2");

      for(Int_t iii = 1; iii <= xsec_age_5->GetNbinsX(); ++iii){

	newerror = TMath::Sqrt( TMath::Power(uppersyserror_5->GetBinError(iii),2.) + TMath::Power(uppersyserror_5->GetBinContent(iii)*0.30,2.) );
	uppersyserror_5->SetBinError(iii, newerror);
      }
      for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){
	newerror2 = TMath::Sqrt( TMath::Power(uppersyserror2_5->GetBinError(iii),2.) + TMath::Power(uppersyserror2_5->GetBinContent(iii)*0.265,2.) );
	uppersyserror2_5->SetBinError(iii, newerror2);


      }
      uppersyserror_5->SetLineColor(4);
      uppersyserror_5->SetLineWidth(2);
      uppersyserror_5->Draw("z same");

      uppersyserror2_5->SetLineColor(1);
      uppersyserror2_5->SetLineWidth(2);
      uppersyserror2_5->Draw("z same");
      /*
      xsec_NLO[xloop]->SetMarkerColor(4);
      xsec_NLO[xloop]->SetMarkerSize(3);
      xsec_NLO[xloop]->SetMarkerStyle(29);
      //      Double_t shift = 0.8*xsec[xloop]->GetBinWidth(1);
      //      xsec_NLO[xloop]->GetXaxis()->SetLimits(1.5+shift,10+shift);
      xsec_NLO[xloop]->SetLineWidth(1);
      xsec_NLO[xloop]->SetLineColor(1);
      xsec_NLO[xloop]->Draw("hist same");
      */

      xsec[xloop]->Draw("e1 same");
      cccc[xloop]->RedrawAxis();

      /// save a plot:
      string namecanv = "/nfs/dust/zeus/group/stefan/outputdir/Plots/" + data +"/" + "Cross_Section_dPhi.gif";
      const char * c1 = namecanv.c_str();
      cccc[xloop]->SaveAs(c1);
      cout<<"xsec[xloop] saved : "<<c1<<endl;

    }

    newerror = 0;
    newerror2 = 0;
    if(xloop ==1){

      xsec_NLO_upper_1->SetLineWidth(1);
      xsec_NLO_upper_1->SetLineColor(1);
      xsec_NLO_upper_1->SetFillColor(5);
      xsec_NLO_upper_1->Draw("hist same");

      xsec_NLO_center_1->SetLineWidth(1);
      xsec_NLO_center_1->SetLineColor(1);
      xsec_NLO_center_1->SetFillColor(5);
      xsec_NLO_center_1->Draw("hist same");

      xsec_NLO_lower_1->SetLineWidth(1);
      xsec_NLO_lower_1->SetLineColor(1);
      xsec_NLO_lower_1->SetFillColor(10);
      xsec_NLO_lower_1->Draw("hist same");

      xsec_age_1->SetMarkerColor(4);
      xsec_age_1->SetMarkerSize(1.2);
      xsec_age_1->SetMarkerStyle(22);
      xsec_age_1->SetLineColor(1);
      xsec_age_1->SetLineWidth(2);
      xsec_age_1->Draw("e1 same");

      uppersyserror_1 = (TH1D*) xsec_age_1->Clone("uppersyserror");
      uppersyserror2_1 = (TH1D*) xsec[xloop]->Clone("uppersyserror2");

      for(Int_t iii = 1; iii <= xsec_age_1->GetNbinsX(); ++iii){
	newerror = TMath::Sqrt( TMath::Power(uppersyserror_1->GetBinError(iii),2.) + TMath::Power(uppersyserror_1->GetBinContent(iii)*0.30,2.) );
	uppersyserror_1->SetBinError(iii, newerror);
      }

      for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){
	newerror2 = TMath::Sqrt( TMath::Power(uppersyserror2_1->GetBinError(iii),2.) + TMath::Power(uppersyserror2_1->GetBinContent(iii)*0.265,2.) );
	uppersyserror2_1->SetBinError(iii, newerror2);
      }

      uppersyserror_1->SetLineColor(4);
      uppersyserror_1->SetLineWidth(2);
      uppersyserror_1->Draw("z same");

      uppersyserror2_1->SetLineColor(1);
      uppersyserror2_1->SetLineWidth(2);
      uppersyserror2_1->Draw("z same");

      xsec[xloop]->Draw("e1 same");
      cccc[xloop]->RedrawAxis();

      /// save a plot:
      string namecanv = "/nfs/dust/zeus/group/stefan/outputdir/Plots/" + data +"/" + "Cross_Section_PtMu.gif";
      const char * c1 = namecanv.c_str();
      cccc[xloop]->SaveAs(c1);
      cout<<"xsec[xloop] saved : "<<c1<<endl;



    }

    newerror = 0;
    newerror2 = 0;

    if(xloop ==2){

      xsec_NLO_upper_2->SetLineWidth(1);
      xsec_NLO_upper_2->SetLineColor(1);
      xsec_NLO_upper_2->SetFillColor(5);
      xsec_NLO_upper_2->Draw("hist same");

      xsec_NLO_center_2->SetLineWidth(1);
      xsec_NLO_center_2->SetLineColor(1);
      xsec_NLO_center_2->SetFillColor(5);
      xsec_NLO_center_2->Draw("hist same");

      xsec_NLO_lower_2->SetLineWidth(1);
      xsec_NLO_lower_2->SetLineColor(1);
      xsec_NLO_lower_2->SetFillColor(10);
      xsec_NLO_lower_2->Draw("hist same");

      xsec_age_2->SetMarkerColor(4);
      xsec_age_2->SetMarkerSize(1.2);
      xsec_age_2->SetMarkerStyle(22);
      xsec_age_2->SetLineColor(4);
      xsec_age_2->SetLineWidth(2);
      xsec_age_2->Draw("e1 same");

      uppersyserror_2 = (TH1D*) xsec_age_2->Clone("uppersyserror");
      uppersyserror2_2 = (TH1D*) xsec[xloop]->Clone("uppersyserror2");

      for(Int_t iii = 1; iii <= xsec_age_2->GetNbinsX(); ++iii){

	newerror = TMath::Sqrt( TMath::Power(uppersyserror_2->GetBinError(iii),2.) + TMath::Power(uppersyserror_2->GetBinContent(iii)*0.30,2.) );
	uppersyserror_2->SetBinError(iii, newerror);
      }
      for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){
	newerror2 = TMath::Sqrt( TMath::Power(uppersyserror2_2->GetBinError(iii),2.) + TMath::Power(uppersyserror2_2->GetBinContent(iii)*0.265,2.) );
	uppersyserror2_2->SetBinError(iii, newerror2);
      }

      uppersyserror_2->SetLineColor(4);
      uppersyserror_2->SetLineWidth(2);
      uppersyserror_2->Draw("z same");

      uppersyserror2_2->SetLineColor(1);
      uppersyserror2_2->SetLineWidth(2);
      uppersyserror2_2->Draw("z same");

      xsec[xloop]->Draw("e1 same");
      cccc[xloop]->RedrawAxis();

      /// saving Plots:
      string namecanv = "/nfs/dust/zeus/group/stefan/outputdir/Plots/" + data +"/" + "Cross_Section_Eta.gif";
      const char * c1 = namecanv.c_str();
      cccc[xloop]->SaveAs(c1);
      cout<<"xsec[xloop] saved : "<<c1<<endl;


    }

    newerror = 0;
    newerror2 = 0;


    if(xloop ==4){
      /*
      xsec_NLO_upper_4->SetLineWidth(1);
      xsec_NLO_upper_4->SetLineColor(1);
      xsec_NLO_upper_4->SetFillColor(5);
      xsec_NLO_upper_4->Draw("hist same");

      xsec_NLO_center_4->SetLineWidth(1);
      xsec_NLO_center_4->SetLineColor(1);
      xsec_NLO_center_4->SetFillColor(5);
      xsec_NLO_center_4->Draw("hist same");

      xsec_NLO_lower_4->SetLineWidth(1);
      xsec_NLO_lower_4->SetLineColor(1);
      xsec_NLO_lower_4->SetFillColor(0);
      xsec_NLO_lower_4->Draw("hist same");
      */
      xsec_age_4->SetMarkerColor(4);
      xsec_age_4->SetMarkerSize(1.2);
      xsec_age_4->SetMarkerStyle(22);
      xsec_age_4->SetLineColor(4);
      xsec_age_4->SetLineWidth(2);
      xsec_age_4->Draw("e1 same");

      uppersyserror_4 = (TH1D*) xsec_age_4->Clone("uppersyserror");
      uppersyserror2_4 = (TH1D*) xsec[xloop]->Clone("uppersyserror2");

      for(Int_t iii = 1; iii <= xsec_age_4->GetNbinsX(); ++iii){

	newerror = TMath::Sqrt( TMath::Power(uppersyserror_4->GetBinError(iii),2.) + TMath::Power(uppersyserror_4->GetBinContent(iii)*0.30,2.) );
	uppersyserror_4->SetBinError(iii, newerror);
      }
      for(Int_t iii = 1; iii <= xsec[xloop]->GetNbinsX(); ++iii){
	newerror2 = TMath::Sqrt( TMath::Power(uppersyserror2_4->GetBinError(iii),2.) + TMath::Power(uppersyserror2_4->GetBinContent(iii)*0.265,2.) );
	uppersyserror2_4->SetBinError(iii, newerror2);
      }
      uppersyserror_4->SetLineColor(4);
      uppersyserror_4->SetLineWidth(2);
      uppersyserror_4->Draw("z same");

      uppersyserror2_4->SetLineColor(1);
      uppersyserror2_4->SetLineWidth(2);
      uppersyserror2_4->Draw("z same");

      xsec[xloop]->Draw("e1 same");
      cccc[xloop]->RedrawAxis();

    /// saving Plots:
    string namecanv = "/nfs/dust/zeus/group/stefan/outputdir/Plots/" + data +"/" + "Cross_Section_dR.gif";
    const char * c1 = namecanv.c_str();
    cccc[xloop]->SaveAs(c1);
    cout<<"xsec[xloop] saved : "<<c1<<endl;

    }






    }
    return true;
}

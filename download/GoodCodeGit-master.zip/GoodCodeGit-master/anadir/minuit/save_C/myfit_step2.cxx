///************************************************
///						  *
///  Created by Stefaniuk Nazar for PhD project   *
///  ZEUS group, DESY				  *
///  8 March 2014				  *
///						  *
///************************************************

 

#include "TMinuit.h"
#include "TGraph.h"
#include <iostream>
#include "TCanvas.h"
#include "TAxis.h"
#include "TH1.h"
#include "TColor.h"
#include "TPad.h"

#include <string>
#include <stdio.h>

using namespace std;

const Int_t Nbins = 6;

Double_t data_us[2][Nbins], data_ls[2][Nbins], mc_jpsiccbh[2][Nbins], mc_bb_us[2][Nbins], mc_bb_ls[2][Nbins];
Double_t Lmass_data_us[2][Nbins], Lmass_data_ls[2][Nbins], Lmass_mc_jpsiccbh[2][Nbins], Lmass_mc_bb_us[2][Nbins], Lmass_mc_bb_ls[2][Nbins];
Double_t Hmass_data_us[2][Nbins], Hmass_data_ls[2][Nbins], Hmass_mc_jpsiccbh[2][Nbins], Hmass_mc_bb_us[2][Nbins], Hmass_mc_bb_ls[2][Nbins];

Double_t data_mc_err[Nbins];

/// Plotting function;
void plot_histo_corrected(TH1D *all_hists[25], Double_t *coeff)
{

  
  TStyle *zeus_style = gInclude->ZEUSSetStyle();

  gROOT->SetStyle("zeus_pub");

  zeus_pub->SetPadRightMargin(0.048);
  zeus_pub->SetPadLeftMargin(0.196);
  zeus_pub->SetPadTopMargin(0.05);
  zeus_pub->SetPadBottomMargin(0.16);

  TColor * redish    = new TColor(22222, 255./255., 175./255., 155./255.);
  TColor * blueish   = new TColor(  444, 163./255., 167./255., 255./255.);
  TColor * yellowish = new TColor(  555, 255./255., 255./255., 160./255.);
  TColor * greenish  = new TColor(  333, 165./255., 255./255., 150./255.);
  TColor * blackish  = new TColor(  111, 168./255., 168./255., 168./255.);
  TColor * greyish   = new TColor(  666,  98./255.,  89./255., 102./255.);
  TColor * brownish  = new TColor(  777, 128./255.,  51./255.,  43./255.);


bool bigmarker = true;
bool bg_black = true;

TH1D* all_hists_tmp_corr[5];
 all_hists_tmp_corr[0]  = (TH1D*) all_hists[0]->Clone("all_hists_tmp_corr");
 all_hists_tmp_corr[1]  = (TH1D*) all_hists[1]->Clone("all_hists_tmp_corr");
 all_hists_tmp_corr[2]  = (TH1D*) all_hists[2]->Clone("all_hists_tmp_corr");
 all_hists_tmp_corr[3]  = (TH1D*) all_hists[3]->Clone("all_hists_tmp_corr");
 all_hists_tmp_corr[4]  = (TH1D*) all_hists[4]->Clone("all_hists_tmp_corr");

// all_hists_tmp[0]->Draw("E1");

TCanvas *plot1 = new TCanvas("plot1","Fitting plot",1005,955);
plot1->cd();
  TPad *canv_1 = new TPad("canv_1", "canv_1", 0.0, 0.0, 0.99, 0.99);
  canv_1->Draw();
  canv_1->SetLogy();
  canv_1->cd();
  canv_1->Range(-3.86269,-150.588,3.62985,830.588);

  all_hists_tmp_corr[0]->SetMarkerStyle(21);
  all_hists_tmp_corr[0]->GetYaxis()->SetRange(1,5000);
// format X axis

  all_hists_tmp_corr[0]->GetXaxis()->SetRangeUser(-100.,100.);
  all_hists_tmp_corr[0]->GetXaxis()->SetTitle("L_{XY} [cm]");
  all_hists_tmp_corr[0]->GetXaxis()->SetTitleSize(0.06);
  all_hists_tmp_corr[0]->GetXaxis()->SetTitleOffset(1.0);
  all_hists_tmp_corr[0]->GetXaxis()->SetLabelSize(0.04);
  all_hists_tmp_corr[0]->GetXaxis()->SetLabelOffset(0.005);

// format Y axis

  all_hists_tmp_corr[0]->GetYaxis()->SetRangeUser(1.,3300.);
  all_hists_tmp_corr[0]->GetYaxis()->SetTitle("Events");
  all_hists_tmp_corr[0]->GetYaxis()->SetTitleSize(0.07);
  all_hists_tmp_corr[0]->GetYaxis()->SetTitleOffset(1.4);
  all_hists_tmp_corr[0]->GetYaxis()->SetLabelSize(0.06);
  all_hists_tmp_corr[0]->GetYaxis()->SetLabelOffset(0.005);

  all_hists_tmp_corr[0]->SetMarkerSize(1.0);
  all_hists_tmp_corr[0]->SetMarkerColor(1);
  all_hists_tmp_corr[0]->Draw("P");

// all_hists_tmp_corr[1]->Scale(1./1.68002);

all_hists_tmp_corr[1]->Scale(coeff[0]);
all_hists_tmp_corr[3]->Scale(coeff[1]/2.);
all_hists_tmp_corr[4]->Scale(coeff[1]/2.);


/// lfl 
  all_hists_tmp_corr[3]->Add(all_hists_tmp_corr[4],1.);
  all_hists_tmp_corr[3]->SetFillColor(444); 
  all_hists_tmp_corr[3]->SetFillStyle(1001);

/// cc bar + jpsi + BH
  all_hists_tmp_corr[2]->Add(all_hists_tmp_corr[3],1.);

  all_hists_tmp_corr[2]->SetFillColor(333);
  all_hists_tmp_corr[2]->SetFillStyle(1001);

/// b bbar
  all_hists_tmp_corr[1]->Add(all_hists_tmp_corr[2],1.);

  all_hists_tmp_corr[1]->SetFillColor(22222); 
  all_hists_tmp_corr[1]->SetFillStyle(1001);


  all_hists_tmp_corr[1]->Draw("hist same");
  all_hists_tmp_corr[2]->Draw("hist same");
  all_hists_tmp_corr[3]->Draw("hist same");

//Draw data again as top layer

  all_hists_tmp_corr[0]->Draw("P same");
  
  canv_1->RedrawAxis();

  plot1->cd();
}

void plot_histo(TH1D *all_hists[25])
{

  TStyle *zeus_style = gInclude->ZEUSSetStyle();

  gROOT->SetStyle("zeus_pub");

  zeus_pub->SetPadRightMargin(0.048);
  zeus_pub->SetPadLeftMargin(0.196);
  zeus_pub->SetPadTopMargin(0.05);
  zeus_pub->SetPadBottomMargin(0.16);

  TColor * redish    = new TColor(22222, 255./255., 175./255., 155./255.);
  TColor * blueish   = new TColor(  444, 163./255., 167./255., 255./255.);
  TColor * yellowish = new TColor(  555, 255./255., 255./255., 160./255.);
  TColor * greenish  = new TColor(  333, 165./255., 255./255., 150./255.);
  TColor * blackish  = new TColor(  111, 168./255., 168./255., 168./255.);
  TColor * greyish   = new TColor(  666,  98./255.,  89./255., 102./255.);
  TColor * brownish  = new TColor(  777, 128./255.,  51./255.,  43./255.);


bool bigmarker = true;
bool bg_black = true;

TH1D* all_hists_tmp[5];
 all_hists_tmp[0]  = (TH1D*) all_hists[0]->Clone("all_hists_tmp");
 all_hists_tmp[1]  = (TH1D*) all_hists[1]->Clone("all_hists_tmp");
 all_hists_tmp[2]  = (TH1D*) all_hists[2]->Clone("all_hists_tmp");
 all_hists_tmp[3]  = (TH1D*) all_hists[3]->Clone("all_hists_tmp");
 all_hists_tmp[4]  = (TH1D*) all_hists[4]->Clone("all_hists_tmp");

// all_hists_tmp[0]->Draw("E1");

TCanvas *plot = new TCanvas("plot","Fitting plot",1005,955);
plot->cd();
  TPad *canv_1 = new TPad("canv_1", "canv_1", 0.0, 0.0, 0.99, 0.99);
  canv_1->Draw();
  canv_1->SetLogy();
  canv_1->cd();
  canv_1->Range(-3.86269,-150.588,3.62985,830.588);

  all_hists_tmp[0]->SetMarkerStyle(21);
  all_hists_tmp[0]->GetYaxis()->SetRange(1,5000);
// format X axis

  all_hists_tmp[0]->GetXaxis()->SetRangeUser(-100.,100.);
  all_hists_tmp[0]->GetXaxis()->SetTitle("L_{XY} [cm]");
  all_hists_tmp[0]->GetXaxis()->SetTitleSize(0.06);
  all_hists_tmp[0]->GetXaxis()->SetTitleOffset(1.0);
  all_hists_tmp[0]->GetXaxis()->SetLabelSize(0.04);
  all_hists_tmp[0]->GetXaxis()->SetLabelOffset(0.005);

// format Y axis

  all_hists_tmp[0]->GetYaxis()->SetRangeUser(1.,3300.);
  all_hists_tmp[0]->GetYaxis()->SetTitle("Events");
  all_hists_tmp[0]->GetYaxis()->SetTitleSize(0.07);
  all_hists_tmp[0]->GetYaxis()->SetTitleOffset(1.4);
  all_hists_tmp[0]->GetYaxis()->SetLabelSize(0.06);
  all_hists_tmp[0]->GetYaxis()->SetLabelOffset(0.005);

  all_hists_tmp[0]->SetMarkerSize(1.0);
  all_hists_tmp[0]->SetMarkerColor(1);
  all_hists_tmp[0]->Draw("P");

/// lfl 
  all_hists_tmp[3]->Add(all_hists_tmp[4],1.);
  all_hists_tmp[3]->SetFillColor(444); 
  all_hists_tmp[3]->SetFillStyle(1001);

/// cc bar + jpsi + BH
  all_hists_tmp[2]->Add(all_hists_tmp[3],1.);

  all_hists_tmp[2]->SetFillColor(333);
  all_hists_tmp[2]->SetFillStyle(1001);

/// b bbar
  all_hists_tmp[1]->Add(all_hists_tmp[2],1.);

  all_hists_tmp[1]->SetFillColor(22222); 
  all_hists_tmp[1]->SetFillStyle(1001);


  all_hists_tmp[1]->Draw("hist same");
  all_hists_tmp[2]->Draw("hist same");
  all_hists_tmp[3]->Draw("hist same");

//Draw data again as top layer

  all_hists_tmp[0]->Draw("P same");
  
  canv_1->RedrawAxis();

  plot->cd();
}

void get_hist_Nbins(char *name_histo, Int_t RebinL , Int_t RebinH, Int_t Nbin, Double_t  *Nbinevnts, Double_t  *eNbinevnts, TH1D *aaa[25])
{

TH1::SetDefaultSumw2();
string mystring;

/// all data
mystring = string(name_histo); mystring.append("_hm_us_data");
TH1D* h_hm_us_data = (TH1D*) gInclude->ReadinHisto(mystring);
// h_hm_us_data->Draw();
// cout<<h_hm_us_data->GetBinContent(10)<<endl;

mystring = string(name_histo); mystring.append("_hm_ls_data");
TH1D* h_hm_ls_data = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_us_data");
TH1D* h_lm_us_data = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_ls_data");
TH1D* h_lm_ls_data = (TH1D*) gInclude->ReadinHisto(mystring);


/// bb mc
mystring = string(name_histo); mystring.append("_hm_us_allMC_sum");
TH1D* h_hm_us_bbmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_hm_ls_allMC_sum");
TH1D* h_hm_ls_bbmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_us_allMC_sum");
TH1D* h_lm_us_bbmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_ls_allMC_sum");
TH1D* h_lm_ls_bbmc = (TH1D*) gInclude->ReadinHisto(mystring);

h_hm_us_bbmc->Scale(1./1.68002);
h_hm_ls_bbmc->Scale(1./1.68002);
h_lm_us_bbmc->Scale(1./1.68002);
h_lm_ls_bbmc->Scale(1./1.68002);


/// J/Psi..
mystring = string(name_histo); mystring.append("_hm_us_allMC_m_charm_sum");
TH1D* h_hm_us_jpsimc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_hm_ls_allMC_m_charm_sum");
TH1D* h_hm_ls_jpsimc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_us_allMC_m_charm_sum");
TH1D* h_lm_us_jpsimc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_ls_allMC_m_charm_sum");
TH1D* h_lm_ls_jpsimc = (TH1D*) gInclude->ReadinHisto(mystring);


/// cc mc
mystring = string(name_histo); mystring.append("_hm_us_MC_c_p_lflbg_sum");
TH1D* h_hm_us_ccmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_hm_ls_MC_c_p_lflbg_sum");
TH1D* h_hm_ls_ccmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_us_MC_c_p_lflbg_sum");
TH1D* h_lm_us_ccmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_ls_MC_c_p_lflbg_sum");
TH1D* h_lm_ls_ccmc = (TH1D*) gInclude->ReadinHisto(mystring);

/// lfl
mystring = string(name_histo); mystring.append("_hm_us_MC_lflbg_sum");
TH1D* h_hm_us_lfl = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_hm_ls_MC_lflbg_sum");
TH1D* h_hm_ls_lfl = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_us_MC_lflbg_sum");
TH1D* h_lm_us_lfl = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); mystring.append("_lm_ls_MC_lflbg_sum");
TH1D* h_lm_ls_lfl = (TH1D*) gInclude->ReadinHisto(mystring);

h_hm_us_data->Rebin(RebinH);
h_hm_ls_data->Rebin(RebinH);
h_lm_us_data->Rebin(RebinL);
h_lm_ls_data->Rebin(RebinL);

h_hm_us_bbmc->Rebin(RebinH);
h_hm_ls_bbmc->Rebin(RebinH);
h_lm_us_bbmc->Rebin(RebinL);
h_lm_ls_bbmc->Rebin(RebinL);

h_hm_us_jpsimc->Rebin(RebinH);
h_hm_ls_jpsimc->Rebin(RebinH);
h_lm_us_jpsimc->Rebin(RebinL);
h_lm_ls_jpsimc->Rebin(RebinL);

h_hm_us_ccmc->Rebin(RebinH);
h_hm_ls_ccmc->Rebin(RebinH);
h_lm_us_ccmc->Rebin(RebinL);
h_lm_ls_ccmc->Rebin(RebinL);

h_hm_us_lfl->Rebin(RebinH);
h_hm_ls_lfl->Rebin(RebinH);
h_lm_us_lfl->Rebin(RebinL);
h_lm_ls_lfl->Rebin(RebinL);

// h_hm_us_data->Draw();

TH1D* aaa_tmp[20];
 aaa_tmp[0]  = (TH1D*) h_hm_us_data->Clone("aaa_tmp");
 aaa_tmp[1]  = (TH1D*) h_hm_ls_data->Clone("aaa_tmp");
 aaa_tmp[2]  = (TH1D*) h_lm_us_data->Clone("aaa_tmp");
 aaa_tmp[3]  = (TH1D*) h_lm_ls_data->Clone("aaa_tmp");

 aaa_tmp[4]  = (TH1D*) h_hm_us_bbmc->Clone("aaa_tmp");
 aaa_tmp[5]  = (TH1D*) h_hm_ls_bbmc->Clone("aaa_tmp");
 aaa_tmp[6]  = (TH1D*) h_lm_us_bbmc->Clone("aaa_tmp");
 aaa_tmp[7]  = (TH1D*) h_lm_ls_bbmc->Clone("aaa_tmp");

 aaa_tmp[8]  = (TH1D*) h_hm_us_lfl->Clone("aaa_tmp");
 aaa_tmp[9]  = (TH1D*) h_hm_ls_lfl->Clone("aaa_tmp");
 aaa_tmp[10]  = (TH1D*) h_lm_us_lfl->Clone("aaa_tmp");
 aaa_tmp[11]  = (TH1D*) h_lm_ls_lfl->Clone("aaa_tmp");

 aaa_tmp[12]  = (TH1D*) h_lm_us_jpsimc->Clone("aaa_tmp");
 aaa_tmp[13]  = (TH1D*) h_lm_ls_jpsimc->Clone("aaa_tmp");
 aaa_tmp[12]->Add(aaa_tmp[13],-1);
 aaa_tmp[14]  = (TH1D*) h_hm_us_jpsimc->Clone("aaa_tmp");
 aaa_tmp[15]  = (TH1D*) h_hm_ls_jpsimc->Clone("aaa_tmp");
 aaa_tmp[14]->Add(aaa_tmp[15],-1);

 aaa_tmp[16]  = (TH1D*) h_lm_us_jpsimc->Clone("aaa_tmp");
 aaa_tmp[17]  = (TH1D*) h_lm_ls_jpsimc->Clone("aaa_tmp");
 aaa_tmp[16]->Add(aaa_tmp[17],-1);
 aaa_tmp[18]  = (TH1D*) h_hm_us_ccmc->Clone("aaa_tmp");
 aaa_tmp[19]  = (TH1D*) h_hm_ls_ccmc->Clone("aaa_tmp");
 aaa_tmp[18]->Add(aaa_tmp[19],-1);

//  cout<<" III = "<<aaa_tmp[12]->Integral()<<endl;


aaa[5] = aaa_tmp[0];
aaa[6] = aaa_tmp[1];
aaa[7] = aaa_tmp[2];
aaa[8] = aaa_tmp[3];

aaa[9] =  aaa_tmp[4];
aaa[10] = aaa_tmp[5];
aaa[11] = aaa_tmp[6];
aaa[12] = aaa_tmp[7];

aaa[13] = aaa_tmp[8];
aaa[14] = aaa_tmp[9];
aaa[15] = aaa_tmp[10];
aaa[16] = aaa_tmp[11];

aaa[17] = aaa_tmp[12];
aaa[18] = aaa_tmp[13];
aaa[19] = aaa_tmp[14];
aaa[20] = aaa_tmp[15];

aaa[21] = aaa_tmp[16];
aaa[22] = aaa_tmp[17];
aaa[23] = aaa_tmp[18];
aaa[24] = aaa_tmp[19];

Nbinevnts[5] = aaa_tmp[0]->GetBinContent(Nbin);
Nbinevnts[6] = aaa_tmp[1]->GetBinContent(Nbin);
Nbinevnts[7] = aaa_tmp[2]->GetBinContent(Nbin);
Nbinevnts[8] = aaa_tmp[3]->GetBinContent(Nbin);

Nbinevnts[9] = aaa_tmp[4]->GetBinContent(Nbin);
Nbinevnts[10] = aaa_tmp[5]->GetBinContent(Nbin);
Nbinevnts[11] = aaa_tmp[6]->GetBinContent(Nbin);
Nbinevnts[12] = aaa_tmp[7]->GetBinContent(Nbin);

Nbinevnts[13] = aaa_tmp[8]->GetBinContent(Nbin);
Nbinevnts[14] = aaa_tmp[9]->GetBinContent(Nbin);
Nbinevnts[15] = aaa_tmp[10]->GetBinContent(Nbin);
Nbinevnts[16] = aaa_tmp[11]->GetBinContent(Nbin);

Nbinevnts[17] = aaa_tmp[12]->GetBinContent(Nbin);
Nbinevnts[18] = aaa_tmp[13]->GetBinContent(Nbin);
Nbinevnts[19] = aaa_tmp[14]->GetBinContent(Nbin);
Nbinevnts[20] = aaa_tmp[15]->GetBinContent(Nbin);

Nbinevnts[21] = aaa_tmp[16]->GetBinContent(Nbin);
Nbinevnts[22] = aaa_tmp[17]->GetBinContent(Nbin);
Nbinevnts[23] = aaa_tmp[18]->GetBinContent(Nbin);
Nbinevnts[24] = aaa_tmp[19]->GetBinContent(Nbin);


eNbinevnts[5] = aaa_tmp[0]->GetBinError(Nbin);
eNbinevnts[6] = aaa_tmp[1]->GetBinError(Nbin);
eNbinevnts[7] = aaa_tmp[2]->GetBinError(Nbin);
eNbinevnts[8] = aaa_tmp[3]->GetBinError(Nbin);

eNbinevnts[9] =  aaa_tmp[4]->GetBinError(Nbin);
eNbinevnts[10] = aaa_tmp[5]->GetBinError(Nbin);
eNbinevnts[11] = aaa_tmp[6]->GetBinError(Nbin);
eNbinevnts[12] = aaa_tmp[7]->GetBinError(Nbin);

eNbinevnts[13] = aaa_tmp[8]->GetBinError(Nbin);
eNbinevnts[14] = aaa_tmp[9]->GetBinError(Nbin);
eNbinevnts[15] = aaa_tmp[10]->GetBinError(Nbin);
eNbinevnts[16] = aaa_tmp[11]->GetBinError(Nbin);

Nbinevnts[17] = aaa_tmp[12]->GetBinError(Nbin);
Nbinevnts[18] = aaa_tmp[13]->GetBinError(Nbin);
Nbinevnts[19] = aaa_tmp[14]->GetBinError(Nbin);
Nbinevnts[20] = aaa_tmp[15]->GetBinError(Nbin);

Nbinevnts[21] = aaa_tmp[16]->GetBinError(Nbin);
Nbinevnts[22] = aaa_tmp[17]->GetBinError(Nbin);
Nbinevnts[23] = aaa_tmp[18]->GetBinError(Nbin);
Nbinevnts[24] = aaa_tmp[19]->GetBinError(Nbin);


h_hm_us_data->Add(h_hm_ls_data,1);
h_hm_us_data->Add(h_lm_us_data,1);
h_hm_us_data->Add(h_lm_ls_data,1);

h_hm_us_bbmc->Add(h_hm_ls_bbmc,1);
h_hm_us_bbmc->Add(h_lm_us_bbmc,1);
h_hm_us_bbmc->Add(h_lm_ls_bbmc,1);

h_hm_us_jpsimc->Add(h_lm_us_jpsimc,1);
h_hm_us_jpsimc->Add(h_hm_us_ccmc,1);
h_hm_us_jpsimc->Add(h_lm_us_ccmc,1);
h_hm_us_jpsimc->Add(h_hm_ls_jpsimc,-1);
h_hm_us_jpsimc->Add(h_lm_ls_jpsimc,-1);
h_hm_us_jpsimc->Add(h_hm_ls_ccmc,-1);
h_hm_us_jpsimc->Add(h_lm_ls_ccmc,-1);

h_hm_us_lfl->Add(h_lm_us_lfl,1);
h_hm_ls_lfl->Add(h_lm_ls_lfl,1);

Nbinevnts[0] = h_hm_us_data->GetBinContent(Nbin);
Nbinevnts[1] = h_hm_us_bbmc->GetBinContent(Nbin);
Nbinevnts[2] = h_hm_us_jpsimc->GetBinContent(Nbin);
Nbinevnts[3] = h_hm_us_lfl->GetBinContent(Nbin);
Nbinevnts[4] = h_hm_ls_lfl->GetBinContent(Nbin);

eNbinevnts[0] = h_hm_us_data->GetBinError(Nbin);
eNbinevnts[1] = h_hm_us_bbmc->GetBinError(Nbin);
eNbinevnts[2] = h_hm_us_jpsimc->GetBinError(Nbin);
eNbinevnts[3] = h_hm_us_lfl->GetBinError(Nbin);
eNbinevnts[4] = h_hm_ls_lfl->GetBinError(Nbin);


// cout<<Nbinevnts[0]<<"	aaa  "<<Nbinevnts[5]+Nbinevnts[6]+Nbinevnts[7]+Nbinevnts[8]<<endl;
// cout<<" checking "<<h_hm_us_data->GetBinContent(Nbin)<<"  "<<h_hm_us_data->GetBinError(Nbin)<<endl;

aaa[0] = h_hm_us_data;
aaa[1] = h_hm_us_bbmc;
aaa[2] = h_hm_us_jpsimc;
aaa[3] = h_hm_us_lfl;
aaa[4] = h_hm_ls_lfl;

}

Double_t chisq_bin_calculation(Int_t Nbins, Double_t *parameters)
{
Double_t data_us, data_ls, mc_bb_us, mc_bb_ls, mc_jpsiccbh;
Double_t data_us_err, data_ls_err, mc_bb_us_err, mc_bb_ls_err, mc_jpsiccbh_err;
Double_t chisq = 0.;
Double_t chisq_temp =0.;

TH1D** all_hists = new TH1D*[25];

Double_t NbinsN[25] = {0.};
Double_t NbinsE[25] = {0.};

for(Int_t k=0;k<Nbins;k++)
{
get_hist_Nbins("h_dl2_sign",5,5, k+1, NbinsN, NbinsE, all_hists);

data_us = NbinsN[5] + NbinsN[7];
data_ls = NbinsN[6] + NbinsN[8];
mc_bb_us = NbinsN[9] + NbinsN[11];
mc_bb_ls = NbinsN[10] + NbinsN[12];
mc_jpsiccbh = NbinsN[2];

data_us_err = sqrt(NbinsE[5]*NbinsE[5] + NbinsE[7]*NbinsE[7]);
data_ls_err = sqrt(NbinsE[6]*NbinsE[6] + NbinsE[8]*NbinsE[8]);
mc_bb_us_err = sqrt(NbinsE[9]*NbinsE[9] + NbinsE[11]*NbinsE[11]);
mc_bb_ls_err = sqrt(NbinsE[10]*NbinsE[10] + NbinsE[12]*NbinsE[12]);
mc_jpsiccbh_err = NbinsE[2];

chisq_temp = (data_us + data_ls - parameters[0]*(mc_bb_us + mc_bb_ls) - mc_jpsiccbh - parameters[1]*(data_ls - mc_bb_ls*parameters[0]));
chisq_temp = chisq_temp/sqrt(data_us_err*data_us_err + data_ls_err*data_ls_err + mc_bb_us_err*mc_bb_us_err + mc_bb_ls_err*mc_bb_ls_err + mc_jpsiccbh_err*mc_jpsiccbh_err);
chisq = chisq + chisq_temp*chisq_temp;

}

return chisq;

}

// Double_t func_MC_mass_Low(Double_t data_ls, Double_t mc_bb_us, Double_t mc_bb_ls, Double_t mc_jpsiccbh, Double_t *par, Int_t i)
// {
// 
//  Double_t value=(par[0]*(mc_bb_us - 1.02* mc_bb_ls) + 1.02*data_ls +  mc_jpsiccbh);
// 
//  Double_t value=(par[0]*(mc_bb_us + mc_bb_ls) + par[1]*(data_ls - par[0]*mc_bb_ls) + mc_jpsiccbh);
//  return value;
// }


/// *****************************************************************************************************************************  ////

Double_t func(Double_t data_ls, Double_t mc_bb_us, Double_t mc_bb_ls, Double_t mc_jpsiccbh, Double_t *par, Int_t i)
{

 Double_t value=(par[0]*(mc_bb_us + mc_bb_ls) + par[1]*(data_ls - par[0]*mc_bb_ls) + mc_jpsiccbh);
 return value;
}
/// *****************************************************************************************************************************  ////

void fcn(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag )
{

//calculate chisquare
   Double_t chisq = 0;
   Double_t delta;

   for (Int_t i=0;i<Nbins; i++) {

     data_mc_err[i] = sqrt(data_us[1][i]*data_us[1][i]+data_ls[1][i]*data_ls[1][i]+mc_bb_us[1][i]*mc_bb_us[1][i]+mc_bb_ls[1][i]*mc_bb_ls[1][i]+mc_jpsiccbh[1][i]*mc_jpsiccbh[1][i]);
     delta  = (data_us[0][i] + data_ls[0][i] - func(data_ls[0][i], mc_bb_us[0][i], mc_bb_ls[0][i], mc_jpsiccbh[0][i] ,par, i));
     delta = delta/data_mc_err[i];

     chisq += delta*delta;

   }
   f = chisq;
}

/// MYFIT function() 	  *******************************************************************************************************  ////
void myfit()
{

const Int_t Nparam = 2;

Double_t Nbinevents[25] = {0.};
Double_t eNbinevents[25] = {0.};

// name, rebin, Nbin, Nbinevens
TH1D** all_hists = new TH1D*[25];

// ********************************************************************************************

TH1D** all_hists_mass = new TH1D*[25];

Double_t NmassbinsN[25] = {0.};
Double_t NmassbinsE[25] = {0.};

Double_t chisq_massL =0.;
Double_t chisq_massH =0.;

for(Int_t k=0;k<Nbins;k++)
{
get_hist_Nbins("h_dl2_sign",5, 5, k+1, Nbinevents, eNbinevents, all_hists);

data_us[0][k] = Nbinevents[5] + Nbinevents[7];
data_ls[0][k] = Nbinevents[6] + Nbinevents[8];
mc_bb_us[0][k] = Nbinevents[9] + Nbinevents[11];
mc_bb_ls[0][k] = Nbinevents[10] + Nbinevents[12];
mc_jpsiccbh[0][k] = Nbinevents[2];

data_us[1][k] = sqrt(eNbinevents[5]*eNbinevents[5] + eNbinevents[7]*eNbinevents[7]);
data_ls[1][k] = sqrt(eNbinevents[6]*eNbinevents[6] + eNbinevents[8]*eNbinevents[8]);
mc_bb_us[1][k] = sqrt(eNbinevents[9]*eNbinevents[9] + eNbinevents[11]*eNbinevents[11]);
mc_bb_ls[1][k] = sqrt(eNbinevents[10]*eNbinevents[10] + eNbinevents[12]*eNbinevents[12]);
mc_jpsiccbh[1][k] = eNbinevents[2];

// ********************************************************************************************

get_hist_Nbins("h_mmu_accept",10,14, k+1, NmassbinsN, NmassbinsE, all_hists_mass);

Lmass_data_us[0][k] = NmassbinsN[7];
Lmass_data_ls[0][k] = NmassbinsN[8];
Lmass_mc_bb_us[0][k] = NmassbinsN[11];
Lmass_mc_bb_ls[0][k] = NmassbinsN[12];
Lmass_mc_jpsiccbh[0][k] = NmassbinsN[17] + NmassbinsN[21];

Lmass_data_us[1][k] = NmassbinsE[7];
Lmass_data_ls[1][k] = NmassbinsE[8];
Lmass_mc_bb_us[1][k] = NmassbinsE[11];
Lmass_mc_bb_ls[1][k] = NmassbinsE[12];
Lmass_mc_jpsiccbh[1][k] = sqrt(NmassbinsE[17]*NmassbinsE[17] + NmassbinsE[21]*NmassbinsE[21]);

Hmass_data_us[0][k] = NmassbinsN[5];
Hmass_data_ls[0][k] = NmassbinsN[6];
Hmass_mc_bb_us[0][k] = NmassbinsN[9];
Hmass_mc_bb_ls[0][k] = NmassbinsN[10];
Hmass_mc_jpsiccbh[0][k] = NmassbinsN[19] + NmassbinsN[23];

Hmass_data_us[1][k] = NmassbinsE[5];
Hmass_data_ls[1][k] = NmassbinsE[6];
Hmass_mc_bb_us[1][k] = NmassbinsE[9];
Hmass_mc_bb_ls[1][k] = NmassbinsE[10];
Hmass_mc_jpsiccbh[1][k] = sqrt(NmassbinsE[19]*NmassbinsE[19] + NmassbinsE[23]*NmassbinsE[23]);



}

if (43==43) {

   TMinuit *gMinuit = new TMinuit(Nparam+1);  //initialize TMinuit with a maximum of 5 params
   gMinuit->SetFCN(fcn);

   Double_t arglist[10];
   Int_t ierflg = 0;

   arglist[0] = 1;
   gMinuit->mnexcm("SET ERR", arglist ,1,ierflg);

// Set starting values and step sizes for parameters
   static Double_t vstart[2] = {1., 1.};
   static Double_t step[2] = {0.05 , 0.05};
   gMinuit->mnparm(0, "S_bb         ", vstart[0], step[0], 0,0,ierflg);
   gMinuit->mnparm(1, "S_lfl (us+ls)", vstart[1], step[1], 0,0,ierflg);
//    gMinuit->mnparm(2, "Slfl_l", vstart[2], step[2], 0,0,ierflg);
//    gMinuit->mnparm(3, "a4", vstart[3], step[3], 0,0,ierflg);

// Now ready for minimization step
   arglist[0] = 500;
   arglist[1] = 1.;
   gMinuit->mnexcm("MIGRAD", arglist ,2,ierflg);

// Print results
   Double_t amin,edm,errdef;
   Int_t nvpar,nparx,icstat;
   gMinuit->mnstat(amin,edm,errdef,nvpar,nparx,icstat);
   gMinuit->mnprin(3,amin);

/// Getting parameters: 
	Double_t par[Nparam]={0.};
	Double_t param[Nparam]={0.};
	Double_t parame[Nparam]={0.};
	Double_t best_minimum = 0.;

	/// Chisq before fitting: 
   	param[0] = 1.68002; param[1] = 2.;
	fcn(ierflg, par, best_minimum, param, ierflg);
   	cout<< " Chisq before fitting check = "<<best_minimum<<endl;
	param[0] = 0.; param[1] = 0.;best_minimum = 0.;
	///
	
	for(int i=0; i<Nparam;i++) gMinuit->GetParameter(i,param[i],parame[i]);
	fcn(ierflg, par, best_minimum, param, ierflg);

	printf(" Chisq after  fitting check =  %2.4f\n",best_minimum);
	for(int ii = 0; ii<Nparam;ii++)printf("par[%i] = %f +- %f;\n",ii,param[ii],parame[ii]);

}


/// low and high mass:

// a[0] h_hm_us_data
// a[1] h_hm_us_bbmc
// a[2] h_hm_us_jpsimc
// a[3] h_hm_us_lfl
// a[4] h_hm_ls_lfl

// a[5] h_hm_us_data
// a[6] h_hm_ls_data
// a[7] h_lm_us_data
// a[8] h_lm_ls_data

// a[9]  h_hm_us_bbmc
// a[10] h_hm_ls_bbmc
// a[11] h_lm_us_bbmc
// a[12] h_lm_ls_bbmc

// a[13] h_hm_us_lfl
// a[14] h_hm_ls_lfl
// a[15] h_lm_us_lfl
// a[16] h_lm_ls_lfl

// a[17] h_lm_us_jpsimc - h_lm_ls_jpsimc
// a[18] h_lm_ls_jpsimc
// a[19] h_hm_us_jpsimc - h_hm_ls_jpsimc
// a[20] h_hm_ls_jpsimc

// a[21] h_lm_us_ccmc - h_lm_ls_ccmc
// a[22] h_lm_ls_ccmc
// a[23] h_hm_us_ccmc - h_hm_ls_ccmc
// a[24] h_hm_ls_ccmc




// Double_t park[2] = {1.68002,2.};
// cout<<" Chisq before fitting check = "<<chisq_bin_calculation(Nbins, park)<<endl;
// cout<<" Chisq after  fitting check = "<<chisq_bin_calculation(Nbins, param)<<endl;

// plot_histo(all_hists);
// plot_histo_corrected(all_hists, param);

}

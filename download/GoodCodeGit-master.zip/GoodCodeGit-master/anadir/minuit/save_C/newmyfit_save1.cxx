///************************************************
///						  *
///  Created by Stefaniuk Nazar for PhD project   *
///  ZEUS group, DESY				  *
///  8 March 2014				  *
///						  *
///************************************************

 

#include "TMinuit.h"
#include "TGraph.h"
#include <iostream>
#include "TCanvas.h"
#include "TAxis.h"
#include "TH1.h"
#include "TColor.h"
#include "TPad.h"

#include <string>
#include <stdio.h>

using namespace std;

const Int_t NLmassBins = 50;
const Int_t NHmassBins = 84;

Int_t Rebin_coefflow = 50/NLmassBins;
Int_t Rebin_coeffhig = 84/NHmassBins;

const Int_t Nbins = 10;

Double_t Nbinevents_allbins[15][NLmassBins+NHmassBins];
Double_t eNbinevents_allbins[15][NLmassBins+NHmassBins];


Double_t data_us[2][Nbins], data_ls[2][Nbins], mc_jpsiccbh[2][Nbins], mc_bb_us[2][Nbins], mc_bb_ls[2][Nbins];
Double_t Lmass_data_us[2][Nbins], Lmass_data_ls[2][Nbins], Lmass_mc_jpsiccbh[2][Nbins], Lmass_mc_bb_us[2][Nbins], Lmass_mc_bb_ls[2][Nbins];
Double_t Hmass_data_us[2][Nbins], Hmass_data_ls[2][Nbins], Hmass_mc_jpsiccbh[2][Nbins], Hmass_mc_bb_us[2][Nbins], Hmass_mc_bb_ls[2][Nbins];

Double_t data_mc_err[NLmassBins+NHmassBins];
Int_t iter = 0;

#include <gethistbincontent.h>
#include <plot_hist_invmass_old.h>

/// *****************************************************************************************************************************  ////

void fcn(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag )
{
   Double_t chisq = 0;
   Double_t delta = 0;

iter = 0;
Double_t CC = 0.;

/// with invMass parametrization: 
if (43==43) 
{ 
   for (Int_t i=0;i<NLmassBins+NHmassBins; i++) 	
{

     if (i<NLmassBins) {CC = 1.04;} else {CC = 1.01;}

     if ((Nbinevents_allbins[0][i] + Nbinevents_allbins[1][i]+Nbinevents_allbins[4][i] + Nbinevents_allbins[6][i]+Nbinevents_allbins[2][i]+Nbinevents_allbins[3][i]) != 0) 
					{ 

     data_mc_err[i] = pow(eNbinevents_allbins[0][i],2.) + pow(CC*eNbinevents_allbins[1][i],2.) + pow(par[0]*eNbinevents_allbins[2][i],2.);
     data_mc_err[i] += pow(par[0]*CC*eNbinevents_allbins[3][i],2.) + pow(eNbinevents_allbins[4][i],2.) + pow(eNbinevents_allbins[6][i],2.);
     data_mc_err[i] = sqrt(data_mc_err[i]);
     delta = ((Nbinevents_allbins[0][i]-CC*Nbinevents_allbins[1][i] - Nbinevents_allbins[4][i]-Nbinevents_allbins[6][i])-par[0]*(Nbinevents_allbins[2][i]-CC*Nbinevents_allbins[3][i])); 

// cout<<delta<<" +/- "<<data_mc_err[i]<<endl;

     delta = delta/data_mc_err[i];
     chisq += delta*delta;
     iter++; 
					}
}
   f = chisq;

}
cout<<"  N used bins = "<<iter<<endl;
}

/// MYFIT function() 	  *******************************************************************************************************  ////
void newmyfit()
{

const Int_t Nparam = 1;

Double_t Nbinevents[15] = {0.};
Double_t eNbinevents[15] = {0.};


TH1D** all_hists_mass = new TH1D*[15];

	for(Int_t Lmassbin=0;Lmassbin<NLmassBins+NHmassBins;Lmassbin++)
	{
	if (Lmassbin<NLmassBins) 
	{ 
	get_hist_bin_content("h_mmu_accept", Rebin_coefflow, Lmassbin+1, Nbinevents, eNbinevents, all_hists_mass, "low");
	} else 
	get_hist_bin_content("h_mmu_accept", Rebin_coeffhig, Lmassbin-NLmassBins+1, Nbinevents, eNbinevents, all_hists_mass, "high");


		for(Int_t histN = 0;histN<15;histN++)
		{
		Nbinevents_allbins[histN][Lmassbin] = Nbinevents[histN];
		eNbinevents_allbins[histN][Lmassbin] = eNbinevents[histN];
		}
 
	}

if (43==43) 
{

   TMinuit *gMinuit = new TMinuit(Nparam+1);  //initialize TMinuit with N params
   gMinuit->SetFCN(fcn);

   Double_t arglist[10];
   Int_t ierflg = 0;

   arglist[0] = 1;
   gMinuit->mnexcm("SET ERR", arglist ,1,ierflg);

// Set starting values and step sizes for parameters
   static Double_t vstart[1] = {1.7/*, 2.*/};
   static Double_t step[1] = {0.01 /*, 0.05*/};
   gMinuit->mnparm(0, "S_bb           ", vstart[0], step[0], 0,0,ierflg);
//    gMinuit->mnparm(1, "S_lfl, S2*(C+1)", vstart[1], step[1], 0,0,ierflg);
// 	gMinuit->FixParameter(0);
// Now ready for minimization step
   arglist[0] = 500;
   arglist[1] = 1.;

//    	gMinuit->mnexcm("HESSE",arglist ,2,ierflg);
   	gMinuit->mnexcm("MIGRAD", arglist ,2,ierflg);
// 	gMinuit->mnexcm("MIGRAD", arglist ,2,ierflg);
//    	gMinuit->mnexcm("HESSE",arglist ,2,ierflg);
//     	gMinuit->mnexcm("MINOS",arglist ,2,ierflg);

// Print results
   Double_t amin,edm,errdef;
   Int_t nvpar,nparx,icstat;
   gMinuit->mnstat(amin,edm,errdef,nvpar,nparx,icstat);
   gMinuit->mnprin(3,amin);

/// Getting parameters: 
	Double_t par[Nparam]={0.};
	Double_t param[Nparam]={0.};
	Double_t parame[Nparam]={0.};
	Double_t best_minimum = 0.;
// 
// 	/// Chisq before fitting: 
//    	param[0] = 1.68002; param[1] = 2.04;
// 	fcn(ierflg, par, best_minimum, param, ierflg);
//    	cout<< " Chisq before fitting check = "<<best_minimum<<endl;
// 	param[0] = 0.; param[1] = 0.;best_minimum = 0.;
	///
	
	for(int i=0; i<Nparam;i++) gMinuit->GetParameter(i,param[i],parame[i]);
	fcn(ierflg, par, best_minimum, param, ierflg);

	printf(" Chisq after  fitting check =  %2.4f\n",best_minimum);
	for(int ii = 0; ii<Nparam;ii++)printf("par[%i] = %f +- %f;\n",ii,param[ii]*1.70149,parame[ii]*1.70149);

}
get_hist_bin_content("h_mmu_accept", Rebin_coefflow, 1, Nbinevents, eNbinevents, all_hists_mass, "low");
plot_hist_invmass_old(all_hists_mass,0, "a");
get_hist_bin_content("h_mmu_accept", Rebin_coeffhig, 1, Nbinevents, eNbinevents, all_hists_mass, "high");
plot_hist_invmass_old(all_hists_mass,0, "b");

// Double_t park[2] = {1.68002,2.};
// cout<<" Chisq before fitting check = "<<chisq_bin_calculation(Nbins, park)<<endl;
// cout<<" Chisq after  fitting check = "<<chisq_bin_calculation(Nbins, param)<<endl;

}

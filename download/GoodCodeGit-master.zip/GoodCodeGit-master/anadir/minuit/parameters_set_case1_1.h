static Bool_t scales_from_fit= false;
static const Double_t MC_scale_b_fit =  1.814 ;
static const Double_t MC_scale_c_fit =  1.639 ;
static const Double_t MC_scale_jpsi1_fit =  1.649 ;

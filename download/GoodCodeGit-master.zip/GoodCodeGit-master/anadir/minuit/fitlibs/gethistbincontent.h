void get_hist_bin_content(char *name_histo, Int_t RebinValue, Int_t Nbin, Double_t  *Nbinevnts, Double_t  *eNbinevnts, TH1D *aaa_tmp[17], string mass_region)
{

TH1::SetDefaultSumw2();
string mystring;

string reg1 = "low";


/// all data
mystring = string(name_histo);
if (mass_region == reg1) {mystring.append("_lm_us_data");} else {mystring.append("_hm_us_data");}
TH1D* h_lm_us_data = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_ls_data");} else {mystring.append("_hm_ls_data");}
TH1D* h_lm_ls_data = (TH1D*) gInclude->ReadinHisto(mystring);

/// bb mc
mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_us_allMC_sum");} else {mystring.append("_hm_us_allMC_sum");}
TH1D* h_lm_us_bbmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_ls_allMC_sum");} else {mystring.append("_hm_ls_allMC_sum");}
TH1D* h_lm_ls_bbmc = (TH1D*) gInclude->ReadinHisto(mystring);

// h_lm_us_bbmc->Scale(1./1.68002);
// h_lm_ls_bbmc->Scale(1./1.68002);

/// J/Psi..
mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_us_allMC_m_charm_sum");} else {mystring.append("_hm_us_allMC_m_charm_sum");}
TH1D* h_lm_us_jpsimc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_ls_allMC_m_charm_sum");} else {mystring.append("_hm_ls_allMC_m_charm_sum");}
TH1D* h_lm_ls_jpsimc = (TH1D*) gInclude->ReadinHisto(mystring);

/// cc mc
mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_us_MC_c_p_lflbg_sum");} else {mystring.append("_hm_us_MC_c_p_lflbg_sum");}
TH1D* h_lm_us_ccmc = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_ls_MC_c_p_lflbg_sum");} else {mystring.append("_hm_ls_MC_c_p_lflbg_sum");}
TH1D* h_lm_ls_ccmc = (TH1D*) gInclude->ReadinHisto(mystring);

/// lfl
mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_us_MC_lflbg_sum");} else {mystring.append("_hm_us_MC_lflbg_sum");}
TH1D* h_lm_us_lfl = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_ls_MC_lflbg_sum");} else {mystring.append("_hm_ls_MC_lflbg_sum");}
TH1D* h_lm_ls_lfl = (TH1D*) gInclude->ReadinHisto(mystring);

/// instanton
mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_us_instantons");} else {mystring.append("_hm_us_instantons");}
TH1D* h_lm_us_instantons = (TH1D*) gInclude->ReadinHisto(mystring);

mystring = string(name_histo); 
if (mass_region == reg1) {mystring.append("_lm_ls_instantons");} else {mystring.append("_hm_ls_instantons");}
TH1D* h_lm_ls_instantons = (TH1D*) gInclude->ReadinHisto(mystring);

/// Rebinnig: 

h_lm_us_data->Rebin(RebinValue);
h_lm_ls_data->Rebin(RebinValue);

h_lm_us_bbmc->Rebin(RebinValue);
h_lm_ls_bbmc->Rebin(RebinValue);

h_lm_us_jpsimc->Rebin(RebinValue);
h_lm_ls_jpsimc->Rebin(RebinValue);

h_lm_us_ccmc->Rebin(RebinValue);
h_lm_ls_ccmc->Rebin(RebinValue);

h_lm_us_lfl->Rebin(RebinValue);
h_lm_ls_lfl->Rebin(RebinValue);

h_lm_us_instantons->Rebin(RebinValue);
h_lm_ls_instantons->Rebin(RebinValue);


// h_hm_us_data->Draw();
/// Creating save copy of input data and working with that: 
TH1D* aaa_tmp[20];
 aaa_tmp[0]  = (TH1D*) h_lm_us_data->Clone("aaa_tmp");
 aaa_tmp[1]  = (TH1D*) h_lm_ls_data->Clone("aaa_tmp");

 aaa_tmp[2]  = (TH1D*) h_lm_us_bbmc->Clone("aaa_tmp");
 aaa_tmp[3]  = (TH1D*) h_lm_ls_bbmc->Clone("aaa_tmp");

 aaa_tmp[4]  = (TH1D*) h_lm_us_jpsimc->Clone("aaa_tmp");
 aaa_tmp[5]  = (TH1D*) h_lm_ls_jpsimc->Clone("aaa_tmp");
 aaa_tmp[4]->Add(aaa_tmp[5],-1);

 aaa_tmp[6]  = (TH1D*) h_lm_us_ccmc->Clone("aaa_tmp");
 aaa_tmp[7]  = (TH1D*) h_lm_ls_ccmc->Clone("aaa_tmp");
 aaa_tmp[6]->Add(aaa_tmp[7],-1);

 aaa_tmp[8]  = (TH1D*) h_lm_us_lfl->Clone("aaa_tmp");
 aaa_tmp[9]  = (TH1D*) h_lm_ls_lfl->Clone("aaa_tmp");

/// all DATA and MC plots (for plotting)
 aaa_tmp[10]  = (TH1D*) h_lm_us_data->Clone("aaa_tmp");
 aaa_tmp[10]->Add(aaa_tmp[1],1);

 aaa_tmp[11]  = (TH1D*) h_lm_us_bbmc->Clone("aaa_tmp");
 aaa_tmp[11]->Add(aaa_tmp[3],1);

 aaa_tmp[12]  = (TH1D*) h_lm_us_jpsimc->Clone("aaa_tmp");
 aaa_tmp[12]->Add(aaa_tmp[5],-1);

 aaa_tmp[13]   = (TH1D*) h_lm_us_ccmc->Clone("aaa_tmp");
 aaa_tmp[13]->Add(aaa_tmp[7],-1);

 aaa_tmp[14]   = (TH1D*) h_lm_us_lfl->Clone("aaa_tmp");
 aaa_tmp[14]->Add(aaa_tmp[9],1);

 aaa_tmp[15]  = (TH1D*) h_lm_us_instantons->Clone("aaa_tmp");
 aaa_tmp[16]  = (TH1D*) h_lm_ls_instantons->Clone("aaa_tmp");


/// Getting Nbinevents and eNbinevents: 

	for(Int_t i=0;i<17;i++)
	{
		Nbinevnts[i] = aaa_tmp[i]->GetBinContent(Nbin);
		eNbinevnts[i] = aaa_tmp[i]->GetBinError(Nbin);
	}


}

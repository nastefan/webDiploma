void plot_hist_invmass_old(TH1D *all_hists[15], bool logY, char *canv_name)
{

  Double_t bb_sc = 1.68002;

  TStyle *zeus_style = gInclude->ZEUSSetStyle();

  gROOT->SetStyle("zeus_pub");

  zeus_pub->SetPadRightMargin(0.048);
  zeus_pub->SetPadLeftMargin(0.196);
  zeus_pub->SetPadTopMargin(0.05);
  zeus_pub->SetPadBottomMargin(0.16);

  TColor * redish    = new TColor(22222, 255./255., 175./255., 155./255.);
  TColor * blueish   = new TColor(  444, 163./255., 167./255., 255./255.);
  TColor * yellowish = new TColor(  555, 255./255., 255./255., 160./255.);
  TColor * greenish  = new TColor(  333, 165./255., 255./255., 150./255.);
  TColor * blackish  = new TColor(  111, 168./255., 168./255., 168./255.);
  TColor * greyish   = new TColor(  666,  98./255.,  89./255., 102./255.);
  TColor * brownish  = new TColor(  777, 128./255.,  51./255.,  43./255.);


bool bigmarker = true;
bool bg_black = true;

TH1D* all_hists_tmp[5];
 all_hists_tmp[0]  = (TH1D*) all_hists[0]->Clone("all_hists_tmp");
 all_hists_tmp[1]  = (TH1D*) all_hists[2]->Clone("all_hists_tmp");
 all_hists_tmp[2]  = (TH1D*) all_hists[4]->Clone("all_hists_tmp");
 all_hists_tmp[3]  = (TH1D*) all_hists[6]->Clone("all_hists_tmp");
 all_hists_tmp[4]  = (TH1D*) all_hists[8]->Clone("all_hists_tmp");

// all_hists_tmp[0]->Draw("E1");

TCanvas *plot = new TCanvas(canv_name,"Fitting plot",1005,955);
plot->cd();
  TPad *canv_1 = new TPad("canv_1", "canv_1", 0.0, 0.0, 0.99, 0.99);
  canv_1->Draw();
  if (logY) {canv_1->SetLogy();}
  canv_1->cd();
  canv_1->Range(-3.86269,-150.588,3.62985,830.588);

  all_hists_tmp[0]->SetMarkerStyle(20);
  all_hists_tmp[0]->SetMarkerSize(1.1);
  all_hists_tmp[0]->GetYaxis()->SetRange(1,5000);
// format X axis

  all_hists_tmp[0]->GetXaxis()->SetRangeUser(-100.,100.);
//   all_hists_tmp[0]->GetXaxis()->SetTitle("S = L_{XY}/#sigma_{Lxy}");
  all_hists_tmp[0]->GetXaxis()->SetTitle("Invmass");
  all_hists_tmp[0]->GetXaxis()->SetTitleSize(0.06);
  all_hists_tmp[0]->GetXaxis()->SetTitleOffset(1.0);
  all_hists_tmp[0]->GetXaxis()->SetLabelSize(0.04);
  all_hists_tmp[0]->GetXaxis()->SetLabelOffset(0.005);

// format Y axis

//   all_hists_tmp[0]->GetYaxis()->SetRangeUser(1.,3300.);
  all_hists_tmp[0]->GetYaxis()->SetTitle("Events");
  all_hists_tmp[0]->GetYaxis()->SetTitleSize(0.07);
  all_hists_tmp[0]->GetYaxis()->SetTitleOffset(1.4);
  all_hists_tmp[0]->GetYaxis()->SetLabelSize(0.06);
  all_hists_tmp[0]->GetYaxis()->SetLabelOffset(0.005);

  all_hists_tmp[0]->SetMarkerSize(1.0);
  all_hists_tmp[0]->SetMarkerColor(1);
  all_hists_tmp[0]->Draw("P");

//   all_hists_tmp[1]->Scale(bb_sc);	// bb scale
//   all_hists_tmp[4]->SetFillColor(444); 
//   all_hists_tmp[4]->SetFillStyle(1001);


/// lfl 
  all_hists_tmp[4]->SetFillColor(444); 
  all_hists_tmp[4]->SetFillStyle(1001);

/// cc bar + jpsi + BH
  all_hists_tmp[3]->Add(all_hists_tmp[4],1.);
  all_hists_tmp[3]->SetFillColor(333);
  all_hists_tmp[3]->SetFillStyle(1001);

/// Jpsi...
  all_hists_tmp[2]->Add(all_hists_tmp[3],1.);
  all_hists_tmp[2]->SetFillColor(555);
  all_hists_tmp[2]->SetFillStyle(1001);

/// b bbar
  all_hists_tmp[1]->Add(all_hists_tmp[2],1.);

  all_hists_tmp[1]->SetFillColor(22222); 
  all_hists_tmp[1]->SetFillStyle(1001);


  all_hists_tmp[1]->Draw("hist same");
  all_hists_tmp[2]->Draw("hist same");
  all_hists_tmp[3]->Draw("hist same");
  all_hists_tmp[4]->Draw("hist same");
//Draw data again as top layer

  all_hists_tmp[0]->Draw("P same");
  
  canv_1->RedrawAxis();

  plot->cd();
}
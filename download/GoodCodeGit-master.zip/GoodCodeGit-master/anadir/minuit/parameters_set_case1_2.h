static Bool_t scales_from_fit= false;
static const Double_t MC_scale_b_fit =  2.270 ;
static const Double_t MC_scale_c_fit =  0.951 ;
static const Double_t MC_scale_jpsi1_fit =  4.721 ;

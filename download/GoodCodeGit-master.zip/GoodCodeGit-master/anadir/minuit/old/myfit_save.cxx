//
//   Example of a program to fit non-equidistant data points
//   =======================================================
//
//   The fitting function fcn is a simple chisquare function
//   The data consists of 5 data points (arrays x,y,z) + the errors in errorsz
//   More details on the various functions or parameters for these functions
//   can be obtained in an interactive ROOT session with:
//    Root > TMinuit *minuit = new TMinuit(10);
//    Root > minuit->mnhelp("*")  to see the list of possible keywords
//    Root > minuit->mnhelp("SET") explains most parameters
//Author: Rene Brun

#include "TMinuit.h"
#include "TGraph.h"
#include <iostream>
#include "TCanvas.h"
#include "TAxis.h"

using namespace std;

Double_t z[5],x[5],errorz[5];

//______________________________________________________________________________
Double_t func(Double_t x,Double_t *par)
{
 Double_t value=(par[0]*x + par[1]*x*x);
 return value;
}
// 	fcn(ierflg, par, best_minimum, param, ierflg);
//______________________________________________________________________________
void fcn(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{
   const Int_t nbins = 5;
   Int_t i;

//calculate chisquare
   Double_t chisq = 0;
   Double_t delta;
   for (i=0;i<nbins; i++) {
     delta  = (z[i]-func(x[i],par))/errorz[i];
     chisq += delta*delta;
   }
   f = chisq;
}

//______________________________________________________________________________
void myfit()
{

	const Int_t Nbins = 5;
	const Int_t Nparam = 2;

// The z values
	z[0]=1;
	z[1]=1;
	z[2]=1;
	z[3]=1;
	z[4]=1;
// The errors on z values
        Double_t error = 0.001;
	errorz[0]=error;
	errorz[1]=error;
	errorz[2]=error;
	errorz[3]=error;
	errorz[4]=error;
// the x values
	x[0]=0.8;
	x[1]=0.88;
	x[2]=0.87;
	x[3]=0.81;
	x[4]=0.82;

   TMinuit *gMinuit = new TMinuit(Nparam+1);  //initialize TMinuit with a maximum of 5 params
   gMinuit->SetFCN(fcn);

   Double_t arglist[10];
   Int_t ierflg = 0;

   arglist[0] = 1;
   gMinuit->mnexcm("SET ERR", arglist ,1,ierflg);

// Set starting values and step sizes for parameters
   static Double_t vstart[2] = {1, 0.001 /*, 0.1 , 0.01*/};
   static Double_t step[2] = {0.005 , 0.005/* , 0.01 , 0.001*/};
   gMinuit->mnparm(0, "a1", vstart[0], step[0], 0,0,ierflg);
   gMinuit->mnparm(1, "a2", vstart[1], step[1], 0,0,ierflg);
//    gMinuit->mnparm(2, "a3", vstart[2], step[2], 0,0,ierflg);
//    gMinuit->mnparm(3, "a4", vstart[3], step[3], 0,0,ierflg);

// Now ready for minimization step
   arglist[0] = 500;
   arglist[1] = 1.;
   gMinuit->mnexcm("MIGRAD", arglist ,2,ierflg);

// Print results
   Double_t amin,edm,errdef;
   Int_t nvpar,nparx,icstat;
   gMinuit->mnstat(amin,edm,errdef,nvpar,nparx,icstat);
   //gMinuit->mnprin(3,amin);

/// Getting parameters: 
	Double_t par[Nparam]={0.};
	Double_t param[Nparam]={0.};
	Double_t parame[Nparam]={0.};
	Double_t best_minimum = 0.;

	for(int i=0; i<Nparam;i++) gMinuit->GetParameter(i,param[i],parame[i]);
	fcn(ierflg, par, best_minimum, param, ierflg);

	printf("last chi^{2}: %f\n",best_minimum);
	for(int ii = 0; ii<Nparam;ii++)printf("par[%i] = %f +- %f;\n",ii,param[ii],parame[ii]);

/// Getting reweighted numbers: 
Double_t new_X[Nbins]={0.};

	for(Int_t j=0;j<Nbins;j++){ 
	new_X[j] = (double) func(x[j],param); // doesn't work  // work after adding lib files
// 	new_X[j] = (double) param[0]*x[j]+param[1]*x[j]*x[j];	// work properly
	cout<<new_X[j]<<endl;

	}

/// Plotting results: 

Double_t xaxis[Nbins];   xaxis[0] = 0.;xaxis[1] = 1.;xaxis[2] = 2.;xaxis[3] = 3.;xaxis[4] = 4.;

  TGraph *gr = new TGraph(Nbins,xaxis,z);	/// original 1 
  TGraph *gr1 = new TGraph(Nbins,xaxis,x);	/// should be fitted numbers
  TGraph *gr2 = new TGraph(Nbins,xaxis,new_X);	/// original 1 

TCanvas *c1 = new TCanvas("c1","A Simple Graph Example",200,10,700,500);
c1->Divide(1,1);

   gr->SetMinimum(0.6);
   gr->SetMaximum(1.1);
   gr->SetLineColor(2);
   gr->SetLineWidth(4);
   gr->SetMarkerColor(4);
   gr->SetMarkerStyle(21);
   gr->SetTitle("a simple graph");
   gr->GetXaxis()->SetTitle("X title");
   gr->GetYaxis()->SetTitle("Y title");
   gr->Draw("ACP");

   gr1->SetLineColor(2);
   gr1->SetLineWidth(4);
   gr1->SetMarkerColor(4);
   gr1->SetMarkerStyle(21);
   gr1->SetTitle("a simple graph");
   gr1->GetXaxis()->SetTitle("X title");
   gr1->GetYaxis()->SetTitle("Y title");
   gr1->Draw("P");

   gr2->SetLineColor(2);
   gr2->SetLineWidth(4);
   gr2->SetMarkerColor(8);
   gr2->SetMarkerStyle(22);
   gr2->SetTitle("a simple graph");
   gr2->GetXaxis()->SetTitle("X title");
   gr2->GetYaxis()->SetTitle("Y title");
   gr2->Draw("P");

}

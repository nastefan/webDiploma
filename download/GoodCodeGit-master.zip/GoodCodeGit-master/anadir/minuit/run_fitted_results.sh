#!bin/sh/

#//////////////////////////////////////////////////////////////////////////////////////////////////////////
# root -l newmyfit.cxx

cd /data/zenith234d/stefan/GutCode/anadir/mini_HeraII_0307p_Data_MC_Dimuon_Finalversion_dbothistos_dimuon
sh Histogramm_Plotscript.sh
# root -l run_8_plotmaker.C

cd /data/zenith234d/stefan/GutCode/anadir/mini_HeraII_0307p_Data_MC_Dimuon_Finalversion_dbothistos_secvtx
sh Histogramm_Plotscript.sh
# root -l run_8_plotmaker.C

# cd /data/zenith234d/stefan/GutCode/anadir/minuit

#//////////////////////////////////////////////////////////////////////////////////////////////////////////

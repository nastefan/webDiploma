///************************************************
///						  *
///  Created by Stefaniuk Nazar for PhD project   *
///  ZEUS group, DESY				  *
///  8 March 2014				  *
///						  *
///************************************************

#include "TMinuit.h"
#include "TGraph.h"
#include <iostream>
#include "TCanvas.h"
#include "TAxis.h"
#include "TH1.h"
#include "TColor.h"
#include "TPad.h"

#include <string>
#include <stdio.h>
// #include "file.h"

using namespace std;

Bool_t instanton_part = false;


const Int_t NLmassBins = 50;
const Int_t NHmassBins = 42;

Int_t Rebin_coefflow = 50/NLmassBins;
Int_t Rebin_coeffhig = 84/NHmassBins;

const Int_t Nbins = 10;

Int_t NtakenbinsHM = 18/Rebin_coeffhig;
Int_t HM_hrange = 4 + 0.5*Rebin_coeffhig*NtakenbinsHM;

Double_t Nbinevents_allbins[17][NLmassBins+NHmassBins];
Double_t eNbinevents_allbins[17][NLmassBins+NHmassBins];


Double_t data_mc_err[NLmassBins+NHmassBins];
static Int_t iter = 0;

//********************************************************************************************
/// DLS parameters :
const Int_t DLSBins = 10;

Int_t Rebin_coeff_DLS = 30/DLSBins;

Double_t Nbinevents_allbins_DLS[17][2*DLSBins];
Double_t eNbinevents_allbins_DLS[17][2*DLSBins];

Double_t data_mc_err_DLS[2*DLSBins];

Double_t DL_lfldata[20];
Double_t sigma_lfl = 13;
//********************************************************************************************


#include <fitlibs/gethistbincontent.h>
#include <fitlibs/plot_hist_invmass_old.h>

/// *****************************************************************************************************************************  ////
//  function : [Sbmc*(Nbmc_u - C*Nbmc_l) - (Ndata_u - C*Ndata_l - Nvm_u - Ncc_u - Nbh_u) ]
//  par[0] = Sbmc;
//  par[1] = Sccmc;
//  par[2] = S_{bh+jpsi+psi+Y}
void fcn(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag )
{
   Double_t chisq = 0;
   Double_t delta = 0;

iter = 0;
Double_t C = 0.;
Double_t delta_DLS = 0;
/// with invMass parametrization:
if (42== 43) {
   for (Int_t i=0;i<NLmassBins+NtakenbinsHM; i++)
	{
     if (i<NLmassBins) {C = 1.04;} else {C = 1.01;}
     if ((eNbinevents_allbins[0][i]+eNbinevents_allbins[1][i]+eNbinevents_allbins[2][i]+eNbinevents_allbins[3][i]+eNbinevents_allbins[4][i]+eNbinevents_allbins[6][i]) !=0)
					{

// squared root from sum of squared static errors:
     data_mc_err[i] = pow(eNbinevents_allbins[0][i],2.) + pow(C*eNbinevents_allbins[1][i],2.) + pow(par[0]*eNbinevents_allbins[2][i],2.);
     data_mc_err[i] += pow(par[0]*C*eNbinevents_allbins[3][i],2.) + pow(par[2]*eNbinevents_allbins[4][i],2.) + pow(par[1]*eNbinevents_allbins[6][i],2.);
     if (instanton_part) {data_mc_err[i] += pow(par[3]*eNbinevents_allbins[15][i],2.) + pow(par[3]*eNbinevents_allbins[16][i],2.);}
     data_mc_err[i] = sqrt(data_mc_err[i]);

// minimized value:
     if (instanton_part)
     {
	delta = ((Nbinevents_allbins[0][i]-C*Nbinevents_allbins[1][i] - par[2]*Nbinevents_allbins[4][i]-par[1]*Nbinevents_allbins[6][i])-par[0]*(Nbinevents_allbins[2][i]-C*Nbinevents_allbins[3][i]) - par[3]*Nbinevents_allbins[15][i] + C*par[3]*Nbinevents_allbins[16][i]);
     }
else
     {	delta = ((Nbinevents_allbins[0][i]-C*Nbinevents_allbins[1][i] - par[2]*Nbinevents_allbins[4][i]-par[1]*Nbinevents_allbins[6][i])-par[0]*(Nbinevents_allbins[2][i]-C*Nbinevents_allbins[3][i])); }

// additional constraint  ()
     delta = delta/data_mc_err[i] + ((par[1]-1.)/0.2) + ((par[2]-1.)/0.5);
     chisq += delta*delta;
     iter++;
					}
	}
}
if (43==43) 	{
/// FOR DL_s :
   for (Int_t i=0;i<DLSBins+DLSBins; i++)
{
     if (i<DLSBins) {C = 1.02;} else {C = 1.01;}
     if ((eNbinevents_allbins_DLS[0][i]+eNbinevents_allbins_DLS[1][i]+eNbinevents_allbins_DLS[2][i]+eNbinevents_allbins_DLS[3][i]+eNbinevents_allbins_DLS[4][i]+eNbinevents_allbins_DLS[6][i]) !=0)
					{

// squared root from sum of squared static errors:
     data_mc_err_DLS[i] = pow(eNbinevents_allbins_DLS[0][i],2.) + pow(C*eNbinevents_allbins_DLS[1][i],2.) + pow(par[0]*eNbinevents_allbins_DLS[2][i],2.);
     data_mc_err_DLS[i] += pow(par[0]*C*eNbinevents_allbins_DLS[3][i],2.) + pow(par[2]*eNbinevents_allbins_DLS[4][i],2.) + pow(par[1]*eNbinevents_allbins_DLS[6][i],2.);
     data_mc_err_DLS[i] = sqrt(data_mc_err_DLS[i])*1.02;

    // minimized value for DLS:
     delta_DLS = ((Nbinevents_allbins_DLS[0][i]-C*Nbinevents_allbins_DLS[1][i] - par[2]*Nbinevents_allbins_DLS[4][i]-par[1]*Nbinevents_allbins_DLS[6][i])-par[0]*(Nbinevents_allbins_DLS[2][i]-C*Nbinevents_allbins_DLS[3][i]));
//********************************************************************************************
     if (delta_DLS >= 0) {DL_lfldata[i] = delta_DLS;} else {DL_lfldata[i] = delta_DLS;}
     delta_DLS = delta_DLS/data_mc_err_DLS[i] /*+ ((par[1]-1.)/0.2) + ((par[2]-1.)/0.5)*/  ;
     chisq += delta_DLS*delta_DLS;
     iter++;
					}
}
		}

    Int_t thehalf = iter/2;

    // for(int k=0;k<iter;k++) {cout<<k<<"  "<<DL_lfldata[k]<<endl;}

     chisq +=
      (DL_lfldata[0]/DL_lfldata[thehalf-1]-1)*(DL_lfldata[0]/DL_lfldata[thehalf-1]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[1]/DL_lfldata[thehalf-2]-1)*(DL_lfldata[1]/DL_lfldata[thehalf-2]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[2]/DL_lfldata[thehalf-3]-1)*(DL_lfldata[2]/DL_lfldata[thehalf-3]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[3]/DL_lfldata[thehalf-4]-1)*(DL_lfldata[3]/DL_lfldata[thehalf-4]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[4]/DL_lfldata[thehalf-5]-1)*(DL_lfldata[4]/DL_lfldata[thehalf-5]-1)/(sigma_lfl*sigma_lfl)

     +(DL_lfldata[thehalf]/DL_lfldata[iter-1]-1)*(DL_lfldata[thehalf+1]/DL_lfldata[iter-1]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[thehalf+1]/DL_lfldata[iter-2]-1)*(DL_lfldata[thehalf+1]/DL_lfldata[iter-2]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[thehalf+2]/DL_lfldata[iter-3]-1)*(DL_lfldata[thehalf+2]/DL_lfldata[iter-3]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[thehalf+3]/DL_lfldata[iter-4]-1)*(DL_lfldata[thehalf+3]/DL_lfldata[iter-4]-1)/(sigma_lfl*sigma_lfl)
     +(DL_lfldata[thehalf+4]/DL_lfldata[iter-5]-1)*(DL_lfldata[thehalf+4]/DL_lfldata[iter-5]-1)/(sigma_lfl*sigma_lfl)

     ;
     chisq += ((par[0]/2.0 - 1.)/0.2)*((par[0]/2.0-1.)/0.2  ) +
     ((par[1]/1.37-1.)/0.5)*((par[1]/1.37-1.)/0.5)
    //  + ((par[2]/2.5-1.)/0.5)*((par[2]/2.5-1.)/0.5)
     ;

    //  cout<<"chi!!"<<DL_lfldata[8]<<"  "<<DL_lfldata[12]<<endl;
     iter = iter;
     f = chisq;
}

/// MYFIT function() 	*******************************************************************************************************  ////
void newmyfit()
{

const Int_t Nparam = 3;

/// For dimumass plot:
Double_t Nbinevents[17] = {0.};
Double_t eNbinevents[17] = {0.};

Int_t ccount =0.;

TH1D** all_hists_mass = new TH1D*[17];

	for(Int_t massbin=0;massbin<NLmassBins+NtakenbinsHM;massbin++)
	{
	if (massbin<NLmassBins)
	{
	get_hist_bin_content("h_mmu_accept", Rebin_coefflow, massbin+1, Nbinevents, eNbinevents, all_hists_mass, "low");
	} else
	get_hist_bin_content("h_mmu_accept", Rebin_coeffhig, massbin-NLmassBins+1, Nbinevents, eNbinevents, all_hists_mass, "high");


		for(Int_t histN = 0;histN<17;histN++)
		{
		Nbinevents_allbins[histN][massbin] = Nbinevents[histN];

		eNbinevents_allbins[histN][massbin] = eNbinevents[histN];
		}
// 		cout<<massbin<<"	15 "<<Nbinevents_allbins[15][massbin]<<endl;
// 		cout<<massbin<<"	16 "<<Nbinevents_allbins[16][massbin]<<endl;
 		if (Nbinevents_allbins[0][massbin] < 20) {ccount++;}
	}

cout<<" End of invmass plot bin getting"<<endl;
cout<<" HM_hrange = "<<HM_hrange<<endl;
cout<<" Nproblems (bins with low statistic)  = "<<ccount<<endl;

/// For DLs plot:
Double_t Nbinevents_DLS[17] = {0.};
Double_t eNbinevents_DLS[17] = {0.};

Int_t ccount_DLS =0.;

TH1D** all_hists_DLS = new TH1D*[17];

	for(Int_t bin=0;bin<DLSBins+DLSBins;bin++)
	{
	if (bin<DLSBins)
	{
	get_hist_bin_content("h_dl2_sign", Rebin_coeff_DLS, bin+1, Nbinevents_DLS, eNbinevents_DLS, all_hists_DLS, "low");
	} else
	get_hist_bin_content("h_dl2_sign", Rebin_coeff_DLS, bin-DLSBins+1, Nbinevents_DLS, eNbinevents_DLS, all_hists_DLS, "high");


		for(Int_t histN = 0;histN<17;histN++)
		{
		Nbinevents_allbins_DLS[histN][bin] = Nbinevents_DLS[histN];

		eNbinevents_allbins_DLS[histN][bin] = eNbinevents_DLS[histN];
		}
// 		cout<<massbin<<"	"<<Nbinevents_allbins[0][massbin]<<endl;
 		if (Nbinevents_allbins_DLS[0][bin] < 20) {ccount++;}
	}

cout<<" End of DLs plot bin getting"<<endl;
cout<<" Nproblems (bins with low statistic)  = "<<ccount<<endl;
// get_content_add();

if (43==43)
{

   TMinuit *gMinuit = new TMinuit(Nparam+1);  //initialize TMinuit with N params
   gMinuit->SetFCN(fcn);

   Double_t arglist[10];
   Int_t ierflg = 0;

   arglist[0] = 1;
   gMinuit->mnexcm("SET ERR", arglist ,1,ierflg);

// Set starting values and step sizes for parameters
   static Double_t vstart[3] = {1.9, 1.37, 2.5/*,1.*/};
   static Double_t step[3] = {0.01 , 0.01, 0.01/*, 0.01*/};
   gMinuit->mnparm(0, "S_bb " , vstart[0], step[0], 0,0,ierflg);
   gMinuit->mnparm(1, "cc_par", vstart[1], step[1], 0,0,ierflg);
   gMinuit->mnparm(2, "jp_par", vstart[2], step[2], 0,0,ierflg);
   //gMinuit->mnparm(3, "ins_sc", vstart[3], step[3], 0,0,ierflg);
  //  gMinuit->FixParameter(0);
  //  gMinuit->FixParameter(1);
   gMinuit->FixParameter(2);

// Now ready for minimization step
   arglist[0] = 500;
   arglist[1] = 1.;

//    	gMinuit->mnexcm("HESSE",arglist ,2,ierflg);
   	gMinuit->mnexcm("MIGRAD", arglist ,2,ierflg);
// 	gMinuit->mnexcm("MIGRAD", arglist ,2,ierflg);
//    	gMinuit->mnexcm("HESSE",arglist ,2,ierflg);
//     	gMinuit->mnexcm("MINOS",arglist ,2,ierflg);

// Print results
   Double_t amin,edm,errdef;
   Int_t nvpar,nparx,icstat;
   gMinuit->mnstat(amin,edm,errdef,nvpar,nparx,icstat);
   gMinuit->mnprin(3,amin);

/// Getting parameters:
	Double_t par[Nparam]={0.};
	Double_t param[Nparam]={0.};
	Double_t parame[Nparam]={0.};
	Double_t best_minimum = 0.;
	Double_t chi2_ndf = 0.;

	for(int i=0; i<Nparam;i++) gMinuit->GetParameter(i,param[i],parame[i]);
	fcn(ierflg, par, best_minimum, param, ierflg);

	cout<<" N used bins = "<<iter<<endl;
	printf(" chi2 after  fitting check =  %2.4f\n",best_minimum);
	cout<<" chi2/ndf  = "<<best_minimum/(iter)<<endl;

	for(int ii = 0; ii<Nparam;ii++)
	if (ii==0) {printf("par[%i] = %1.3f +- %1.3f;\n",ii,param[ii]/*1.93*//*1.70149*/,parame[ii]/*1.93*//*1.70149*/);}
	else if (ii==1) {printf("par[%i] = %1.3f +- %1.3f;\n",ii,param[ii]/*1.37*/,parame[ii]/*1.37*/);}
	else if (ii==2) {printf("par[%i] = %1.3f +- %1.3f;\n",ii,param[ii]/*2.5*/,parame[ii]/**2.5*/);}

}
get_hist_bin_content("h_mmu_accept", Rebin_coefflow, 1, Nbinevents, eNbinevents, all_hists_mass, "low");
plot_hist_invmass_old(all_hists_mass,0, "a");
get_hist_bin_content("h_mmu_accept", Rebin_coeffhig, 1, Nbinevents, eNbinevents, all_hists_mass, "high");
plot_hist_invmass_old(all_hists_mass,0, "b");

//********************************************************************************************
/// store fit results to the file? : false / true
char decision[100] = "true";

//********************************************************************************************
FILE *f;
f=fopen("parameters_set.h","w");
fprintf(f,"static Bool_t scales_from_fit= %s;\n",decision);
fprintf(f,"%s %1.3f %s","static const Double_t MC_scale_b_fit = ", param[0]/*1.93/*1.70149*/,";\n");
fprintf(f,"%s %1.3f %s","static const Double_t MC_scale_c_fit = ", param[1]/*1.37*/,";\n");
fprintf(f,"%s %1.3f %s","static const Double_t MC_scale_jpsi1_fit = ", param[2]/*2.5*/,";\n");

fclose(f);

cout<<"	Old parameters: "<<endl;
cout<<" S_bb = "<<1.70149<<endl;
cout<<" cc__ = "<<1.37<<endl;
cout<<" jps_ = "<<2.5<<endl;

//********************************************************************************************
// gROOT->ProcessLine(".q");

}

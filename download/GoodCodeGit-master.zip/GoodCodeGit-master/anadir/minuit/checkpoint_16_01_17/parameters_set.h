static Bool_t scales_from_fit= true;
static const Double_t MC_scale_b_fit =  2.065 ;
static const Double_t MC_scale_c_fit =  1.118 ;
static const Double_t MC_scale_jpsi1_fit =  2.500 ;

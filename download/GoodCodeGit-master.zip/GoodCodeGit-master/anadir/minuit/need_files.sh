#!bin/sh

a1="mini_HeraII_0307p_Data_MC_Dimuon_Finalversion_dbothistos_secvtx"
a2="mini_HeraII_0307p_Data_MC_Dimuon_Finalversion_dbothistos_dimuon"
#a1="mini_HeraII_0307p_Data_MC_Dimuon_Finalversion_dbothistos_secvtx/original_checkpoint1"


cp ../$a1/h_dl2_sign_hm_ls_allMC_m_charm_sum ./
cp ../$a1/h_dl2_sign_hm_ls_allMC_sum ./
cp ../$a1/h_dl2_sign_hm_ls_data ./
cp ../$a1/h_dl2_sign_hm_ls_MC_c_p_lflbg_sum ./
cp ../$a1/h_dl2_sign_hm_ls_MC_lflbg_sum ./
cp ../$a1/h_dl2_sign_hm_us_allMC_m_charm_sum ./
cp ../$a1/h_dl2_sign_hm_us_allMC_sum ./
cp ../$a1/h_dl2_sign_hm_us_data ./
cp ../$a1/h_dl2_sign_hm_us_MC_c_p_lflbg_sum ./
cp ../$a1/h_dl2_sign_hm_us_MC_lflbg_sum ./
cp ../$a1/h_dl2_sign_lm_ls_allMC_m_charm_sum ./
cp ../$a1/h_dl2_sign_lm_ls_allMC_sum ./
cp ../$a1/h_dl2_sign_lm_ls_data ./
cp ../$a1/h_dl2_sign_lm_ls_MC_c_p_lflbg_sum ./
cp ../$a1/h_dl2_sign_lm_ls_MC_lflbg_sum ./
cp ../$a1/h_dl2_sign_lm_us_allMC_m_charm_sum ./
cp ../$a1/h_dl2_sign_lm_us_allMC_sum ./
cp ../$a1/h_dl2_sign_lm_us_data ./
cp ../$a1/h_dl2_sign_lm_us_MC_c_p_lflbg_sum ./
cp ../$a1/h_dl2_sign_lm_us_MC_lflbg_sum ./
cp ../$a1/h_dl2_sign_hm_ls_instantons ./
cp ../$a1/h_dl2_sign_hm_us_instantons ./
cp ../$a1/h_dl2_sign_lm_ls_instantons ./
cp ../$a1/h_dl2_sign_lm_us_instantons ./


cp ../$a2/h_mmu_accept_hm_ls_allMC_m_charm_sum ./
cp ../$a2/h_mmu_accept_hm_ls_allMC_sum ./
cp ../$a2/h_mmu_accept_hm_ls_data ./
cp ../$a2/h_mmu_accept_hm_ls_MC_c_p_lflbg_sum ./
cp ../$a2/h_mmu_accept_hm_ls_MC_lflbg_sum ./
cp ../$a2/h_mmu_accept_hm_us_allMC_m_charm_sum ./
cp ../$a2/h_mmu_accept_hm_us_allMC_sum ./
cp ../$a2/h_mmu_accept_hm_us_data ./
cp ../$a2/h_mmu_accept_hm_us_MC_c_p_lflbg_sum ./
cp ../$a2/h_mmu_accept_hm_us_MC_lflbg_sum ./
cp ../$a2/h_mmu_accept_lm_ls_allMC_m_charm_sum ./
cp ../$a2/h_mmu_accept_lm_ls_allMC_sum ./
cp ../$a2/h_mmu_accept_lm_ls_data ./
cp ../$a2/h_mmu_accept_lm_ls_MC_c_p_lflbg_sum ./
cp ../$a2/h_mmu_accept_lm_ls_MC_lflbg_sum ./
cp ../$a2/h_mmu_accept_lm_us_allMC_m_charm_sum ./
cp ../$a2/h_mmu_accept_lm_us_allMC_sum ./
cp ../$a2/h_mmu_accept_lm_us_data ./
cp ../$a2/h_mmu_accept_lm_us_MC_c_p_lflbg_sum ./
cp ../$a2/h_mmu_accept_lm_us_MC_lflbg_sum ./
cp ../$a2/h_mmu_accept_hm_ls_instantons ./
cp ../$a2/h_mmu_accept_hm_us_instantons ./
cp ../$a2/h_mmu_accept_lm_ls_instantons ./
cp ../$a2/h_mmu_accept_lm_us_instantons ./


#!bin/sh

# sh ../analysis_macros/set_src_first.sh
mkdir ../mini_HeraII_0307p_Data_MC_xsec1_Finalversion_dbothistos_dimuon

#cd ../Extraction_Scripts
#sh run_all_xsection1.sh
cd ../mini_HeraII_0307p_Data_MC_xsec1_Finalversion_dbothistos_dimuon
rm *.root
cd ../autoscripts
sh move_all_xsec1.sh
cd ../mini_HeraII_0307p_Data_MC_xsec1_Finalversion_dbothistos_dimuon
sh mergefiles.sh
sh Cross_Sectionscript.sh

# root -l run_8_plotmaker.C


#!/bin/sh
cd /nfs/dust/zeus/group/stefan/test2/GoodCodeGit/anadir/
analyse mini_HeraII_05e_Data_only_Dimuon_Finalversion dbot_general_gmuon_dimuon_analyse_12_HeraII_Switch_05e.cards


// #include "/nfs/dust/zeus/group/stefan/test2/GoodCodeGit/anadir/Plotting_Scripts/includes/Useful_Codes/Nevents_Histosum/Draw_Errorbar.C"
// #include "/nfs/dust/zeus/group/stefan/test2/GoodCodeGit/anadir/minuit/parameters_set.h"

Int_t Crosssection_Extraction(Bool_t highmass=true, Bool_t autoquit=false){

// CASE 0; Original fit
  Bool_t scales_from_fit= false;
  // Double_t MC_scale_b_fit =  1.921 ;
  // Double_t MC_scale_c_fit =  1.458 ;
  // Double_t MC_scale_jpsi1_fit =  2.448 ;

// Systematics:
// based on the fit procedure;
Double_t MC_scale_b_fit =  2.107 ;
Double_t MC_scale_c_fit =  1.461 ;
Double_t MC_scale_jpsi1_fit =  2.402 ;


  if(highmass)
    {
      cout<<"***************************************"<<endl;
      cout<<"**** executing beauty est. hm *********"<<endl;
      cout<<"***************************************"<<endl;
    }

  else if(!highmass)
    {
      cout<<"***************************************"<<endl;
      cout<<"**** executing beauty est. lm *********"<<endl;
      cout<<"***************************************"<<endl;
    }

  gROOT->Reset();
  gROOT->SetStyle("Plain");
  gROOT->UseCurrentStyle();

  gErrorIgnoreLevel = 1;

  Int_t  count1            = 0;
  Int_t  nfiles            = 47; // WARNING! Do not move below 'dataposition'!
  Int_t  dataposition      = nfiles -1;
  Int_t  charmbegin        = 12;
  Int_t  charmend          = 39; // is only +1 as the +2 corresponds to adding the 2 rapgap files: one c one b, thus the charm is shifted by one rapgap. 050409
  Int_t  BH_position1       = 30;
  Int_t  BH_position2       = 31;
  Int_t  BH_position3       = 32;
  Int_t  jpsi_position1     = 33;
  Int_t  jpsi_position2     = 34;
  Int_t  psiprime_position1 = 35;
  Int_t  psiprime_position2 = 36;
  Int_t  ups1_position      = 37;
  Int_t  ups2_position      = 38;
  Int_t  ups3_position      = 39;
  Int_t  nhistos           = -9999;
  Int_t  nrows             = 9+4;
  Int_t  startfile         = 0;
  Int_t  typechooser       = 0;
  Int_t  rangechooser      = 0;
  Int_t  histonr           = 0;

  Int_t  MCentries         = 0;
  Int_t  dataentries       = 0;
  Stat_t MCintegral        = 0.;
  Stat_t MCallintegral     = 0.;
  Stat_t dataintegral      = 0.;
  Stat_t MCintegral_ls     = 0.;
  Stat_t dataintegral_ls   = 0.;

  Double_t binerror        = 0.;

  // s_MC^b = (d^u-d^l-(c^u+bh^u+jpsi^u+psiprime^u))/(b^u-b^l)
  Double_t  data_unlike                = 0.;
  Double_t  data_like                  = 0.;
  Double_t  beauty_unlike              = 0.;
  Double_t  beauty_like                = 0.;
  Double_t  all_bg_p_beauty_m_lfl_bg_u = 0.;


  Bool_t oldfilestyle  = false;
  Bool_t realtime      = false;
  Bool_t print_single  = false;
  Bool_t bigmarker     = false;
  Bool_t charm_extra   = false;

  Double_t useccbarincl = 1.0;   // 1.8 if like sign charm is subtracted. In the old sample there was
                                 // nearly NO like sign background, due to the preselection - here there is lots. Checks NEEDE!! 050203
  Double_t usedimuccbar = 0.0;
  Double_t rapgapscale  = 1.0; // to change DIS contrib.
  Double_t us_bg_corr   = 0;
  Bool_t smoothMC       = false;
  Bool_t list_histos    = true;
  Bool_t MBtakeON       = true;
  Bool_t fromoli        = true;
  Bool_t plot_dists_std = false;
  Bool_t plot_dists_kum = true;
  Bool_t plot_ls        = false;
  Bool_t plot_diffxsec  = false;   // if true, norm. for differential xsec, if false, norm. for tot. xsec is used.
//   Bool_t plot_hm = true;        // if false, lm is plotted
  Bool_t plot_hm       = highmass; // if false, lm is plotted

  TString iso_chooser = "nis"; // possible values: is, nis & nisandis
    Bool_t calc_b_frac = autoquit;

    //  Bool_t calc_b_frac = true; //WARNING!!! take it back to autoquit!!! 050416
//  Bool_t plot_nis = false;

  Bool_t MC_first = false;

//Bool_t during_construction = true; // because of pt_rel plot adding bug - non interger values for overflow?!!? -> due to using it in cout and rebinning?
//Bool_t during_construction = true; // 040407 - seems to have a c-b mixing bug - description without b just too good and factor 2 in stats... have I mixed data with MC - or added twice? or analysed the wrong .root files (include files)?

  Bool_t during_construction = false; //040521 distribs look good.

  TString previous_obj, printname, filename, strbuffer;
  TPad * padbuffer;

// Set plotting parametes:

  Double_t data_lumi       = 376.16; // Sum Lumi 05e,06e,06/07p
  Double_t data_lumi_03_04 =  40.59; // 03-04 data e+
  Double_t data_lumi_05_06 = 190.12; // 05-06 data e-
  Double_t data_lumi_06_07 = 145.90; // 06-07 data e+

  if(MBtakeON)
    {
      cout<<(char)27<<"[06;33m"<<"WARNING!! assuming MBtake to be ON and reducing the lumi values accordingly."<<(char)27<<"[0m"<<endl;
      data_lumi_03_04 =  40.59;          // 03-04 data e+
      data_lumi_05_06 = 190.12;          // 05-06 data e-
      data_lumi_06_07 = 145.90;          // 06-07 data e+
      data_lumi       = data_lumi_03_04 + data_lumi_05_06 + data_lumi_06_07; // sum of used preupgrade years
    }

  cout<<"data_lumi 03p-07p is: "<<data_lumi<<endl;

  Double_t dim_fl_exc = 1.0;

  if (scales_from_fit) { MC_scale_b = MC_scale_b_fit; } else
  if(!plot_diffxsec)  Double_t MC_scale_b = /*1.9*/1.70149;            // tuning 080116 - for tot. xsec with BHadron ptb PAPERED2
  else                Double_t MC_scale_b = 1.777;          // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  if (scales_from_fit) { MC_scale_c = MC_scale_c_fit;} else
  Double_t MC_scale_c = 1.37;                               // knowing 080116 - Achim's charm (D* analyse)
                                                            // scaling factor PAPERED2 (nach neuen effizienz korrekturen)

  if (scales_from_fit) { MC_scale_BH_DIS = (MC_scale_jpsi1_fit*0.55/2.5);} else
  if(!plot_diffxsec) Double_t MC_scale_BH_DIS = 0.55;      // tuning 080116 - for tot. xsec PAPERED2, new charm 1.37
  else               Double_t MC_scale_BH_DIS = 1.2;        // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  if (scales_from_fit) { MC_scale_BH_ela = (MC_scale_jpsi1_fit*6./2.5);} else
  if(!plot_diffxsec) Double_t MC_scale_BH_ela = 5.;         // tuning 080116 - for tot. xsec PAPERED2, new charm 1.37
  else               Double_t MC_scale_BH_ela = 1.2;        // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  if (scales_from_fit) { MC_scale_BH_inela = (MC_scale_jpsi1_fit*2.2/2.5);} else
  if(!plot_diffxsec) Double_t MC_scale_BH_inela = 2.0;      // tuning 080116 - for tot. xsec PAPERED2, new charm 1.37
  else               Double_t MC_scale_BH_inela = 1.2;      // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  Double_t b_mixing = 0.00;                                 // 041015: after cheching: BBbar osci is ON in our Pythia sample - take
                                                            // additional mixing out again *sigh*
  if (scales_from_fit) { MC_scale_jpsi1 = MC_scale_jpsi1_fit;} else
  if(!plot_diffxsec)  Double_t MC_scale_jpsi1 = 2.5;        // tuning 080116 - for tot. xsec with BHadron ptb PAPERED2, new charm 1.37
  else                Double_t MC_scale_jpsi1 = 2.097;      // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  if (scales_from_fit) { MC_scale_jpsi2 = (MC_scale_jpsi1_fit*0.90*0.036/2.5);} else
  if(!plot_diffxsec)  Double_t MC_scale_jpsi2 = 0.145;       // tuning 080116 - for tot. xsec with BHadron ptb PAPERED2, new charm 1.37
  else                Double_t MC_scale_jpsi2 = 2.097;      // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  if (scales_from_fit) { MC_scale_psiprime1 = (MC_scale_jpsi1_fit*5./2.5);} else
  if(!plot_diffxsec)  Double_t MC_scale_psiprime1 = 5.;     // tuning 080116, for tot. xsec PAPERED2, new charm 1.37
  else                Double_t MC_scale_psiprime1 = 0.3;    // tuning 080116, for diff. xsecs PAPERED2, new charm 1.37

  if (scales_from_fit) { MC_scale_psiprime2 = (MC_scale_jpsi1_fit*0.0027/2.5);} else
  if(!plot_diffxsec)  Double_t MC_scale_psiprime2 = 0.0027; // tuning 080116, for tot. xsec PAPERED2, new charm 1.37
  else                Double_t MC_scale_psiprime2 = 0.3;    // tuning 080116, for diff. xsecs PAPERED2, new charm 1.37

  Double_t MC_scale_ups1   = 0.0040447;
  Double_t MC_scale_ups2   = MC_scale_ups1*0.19/0.73;
  Double_t MC_scale_ups3   = MC_scale_ups1*0.08/0.73;


/*
  if(!plot_diffxsec)  Double_t MC_scale_b = 1.864;       // tuning 080116 - for tot. xsec with BHadron ptb PAPERED2
  else                Double_t MC_scale_b = 1.777;       // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  Double_t MC_scale_c = 1.37;                            // knowing 080116 - Achim's charm (D* analyse) scaling factor
                                                         // PAPERED2 (nach neuen effizienz korrekturen)

  if(!plot_diffxsec) Double_t MC_scale_BH = 0.75;        // tuning 080116 - for tot. xsec PAPERED2, new charm 1.37
  else               Double_t MC_scale_BH = 1.2;         // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  Double_t b_mixing = 0.00;                              // 041015: after cheching: BBbar osci is ON in our Pythia sample -
                                                         // take additional mixing out again *sigh*

  if(!plot_diffxsec)  Double_t MC_scale_jpsi = 1.82;     // tuning 080116 - for tot. xsec with BHadron ptb PAPERED2, new charm 1.37
  else                Double_t MC_scale_jpsi = 2.097;    // tuning 080116 - for differential xsecs PAPERED2, new charm 1.37

  if(!plot_diffxsec)  Double_t MC_scale_psiprime = 1.16; // tuning 080116, for tot. xsec PAPERED2, new charm 1.37
  else                Double_t MC_scale_psiprime = 1.3;  // tuning 080116, for diff. xsecs PAPERED2, new charm 1.37
*/
  Double_t gluspli_up = .0;                              // enhance only gluon splitting MC a bit (dirty!!)

  if(iso_chooser == "nis" && !plot_hm) {

    Double_t scaledown_psiprime = 1.0; // neutral 050412
    Double_t scaledown_jpsi     = 1.0;
    Double_t scaledown_c        = 1.0;
    Double_t scaledown_b        = 1.0;

    cout<<endl<<(char)27<<"[06;33m"<<"WARNING!!!!!!! scaling down psiprime from default by factor: "<<scaledown_psiprime<<(char)27<<"[0m"<<endl;
    MC_scale_psiprime1 = MC_scale_psiprime1*scaledown_psiprime;
    MC_scale_psiprime2 = MC_scale_psiprime2*scaledown_psiprime;

    cout<<(char)27<<"[06;33m"<<      "WARNING!!!!!!! scaling down jpsi     from default by factor: "<<scaledown_jpsi<<(char)27<<"[0m"<<endl;
    MC_scale_jpsi1 = MC_scale_jpsi1*scaledown_jpsi;
    MC_scale_jpsi2 = MC_scale_jpsi2*scaledown_jpsi;

//     cout<<      "WARNING!!!!!!! scaling down c        from default by factor: "<<scaledown_c<<endl;
//     MC_scale_c = MC_scale_c*scaledown_c;

     cout<<(char)27<<"[06;33m"<<      "WARNING!!!!!!! scaling down b        from default by factor: "<<scaledown_b<<(char)27<<"[0m"<<endl;
     MC_scale_b = MC_scale_b*scaledown_b;

    cout<<"acknowledge by pressing return"<<endl;
    if(!autoquit)getchar();
  }
  if( plot_ls && calc_b_frac ){
    cout<<(char)27<<"[06;33m"<<"WARNING!!!!!!! both plot_ls AND calc_b_frac are true - this is momentarily impossible - breaking...!"<<(char)27<<"[0m"<<endl;
    break;
  }
  if( plot_dists_std && plot_dists_kum ){
    cout<<(char)27<<"[06;33m"<<"WARNING!!!!!!! both plot_dists_std AND plot_dists_kum are true - this is not possible - breaking...!"<<(char)27<<"[0m"<<endl;
    break;
  }
  if(gluspli_up != 1.0) {
    cout<<(char)27<<"[06;33m"<<"WARNING!!!!!!! scaling bbbar gluon splitting to: "<<MC_scale_b*gluspli_up<<endl;
    cout<<"acknowledge by pressing return"<<(char)27<<"[0m"<<endl;
     if(!autoquit)    getchar();
  }
  if(useccbarincl != .0) {
    cout<<(char)27<<"[06;33m"<<"WARNING!!!!!!! Using BAD inclusive ccbar MC scaled by factor: "<<useccbarincl<<" dimufactor: "<<usedimuccbar<<(char)27<<"[0m"<<endl;

//  cout<<"acknowledge by pressing return"<<endl;
//  getchar();

  }

  // c    best fit: 2.4, b = 0.
  // c+b  best fit: 2.4, b = 1.6, c = 1.2
  // Int_t    rebinvalue = 10; // for most plots
  // Int_t    rebinvalue = 20; // for mupt
  // Int_t    rebinvalue = 4; // for eta
  // Int_t    rebinvalue = 2; // for lm mmu
  // Int_t    rebinvalue = 1; // for test
  Int_t    rebinvalue = 0; // for no rebinning
  // 0 = b-MC,  4 = c-MC,  dataposition = data

  // to be updated when plots are added: 031201
  // second array index: 0 = b-MC,  4 = c-MC,  dataposition = data
  // obj[0 +N*13][] :  h_mmu
  // obj[1 +N*13][] :  h_DR
  // obj[2 +N*13][] :  h_DR_mmu
  // obj[3 +N*13][] :  h_ptmus
  // obj[4 +N*13][] :  h_ptmu
  // obj[5 +N*13][] :  h_dphi
  // obj[6 +N*13][] :  h_muqual
  // obj[7 +N*13][] :  h_mueta
  // obj[8 +N*13][] :  h_calet
  // obj[9 +N*13][] :  h_triggers
  // obj[10+N*13][] :  h_ptasym
  // obj[11+N*13][] :  h_dphii
  // obj[12+N*13][] :  h_deta
  //
  // choose N => lm/hm us/ls
  // N     range
  // ---0-----------
  // 0    all
  // 1    lm_us
  // 2    lm_ls
  // 3    hm_us
  // 4    hm_ls
  // 5... nope!


  // now also below! begin >>>
  // prepared checked types:
  // typechooser = 10; // pt_asym -> Doesn/t work yet - rebinning...
  // typechooser = 7;  // mueta
  // typechooser = 4;  // mupt
  // typechooser = 8;  // calet
  // typechooser = 0;  // mmu
  // typechooser = 1;  // DR
  // typechooser = 6;  // muqual
  // typechooser = 11;  // dphii
  // typechooser = 12;  // deta
  // typechooser = 13;
  //
  // rangechooser = 3; // hm_us
  // rangechooser = 1; // lm_us // tested only for mmu!!
  // now also below! end <<<
  // will be set below - as nhistos is unknown here.
  // histonr = typechooser + rangechooser*nhistos; // nhistos = 11 for histos v2 (before 031201)
  // histonr = typechooser + rangechooser*nhistos; // nhistos = 13 for histos after 031130

  // old: now renewed above... 031201
  // Int_t histonr = 43; // 43 = pt_asym_hm_us -> Doesn/t work yet - rebinning...
  // Int_t histonr = 40; // 40 = mueta_hm_us
  // Int_t histonr = 37; // 37 = mupt
  // Int_t histonr = 41; // 41 = calet_hm_us
  // Int_t histonr = 33; // 33 = mmu_hm_us
  // Int_t histonr = 18; // 18 = mueta_lm
  // Int_t histonr = 11; // 11 = mmu_lm_us
  // Int_t histonr = 34; // 34 = DR_hm_us
  // Int_t histonr = 39; // 39 = muqual_hm_us
  // Int_t histonr = 39-22; // 39-22 = muqual_lm_us

  // if(histo == mueta_hm_us ) rebinvalue = 4;
  // static const Int_t obj_size_v = 1000;
  // static const Int_t obj_size_h = nfiles+20;
  // TH1D *obj[obj_size_v][obj_size_h];

  TH1D *obj[1000][60];

  TKey *key;

// initialise histogram array:

  for(Int_t vorne = 0; vorne<1000; vorne++)
    {
      for(Int_t hinten = 0; hinten<60; hinten++) obj[vorne][hinten] = 0;
    }

  if( during_construction )
    {
    //******* CONSTRUCTION WARNING!!!
      cout<<"*******************************************************************************************************"<<endl;
      cout<<"*** CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! ***"<<endl;
      cout<<"*** CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! ***"<<endl;
      cout<<"*******************************************************************************************************"<<endl;
    }

  if(dim_fl_exc != 1.0)
    {//******* FL EXC FUDGED -  WARNING!!!
      cout<<"*******************************************************************************************************************"<<endl;
      cout<<"***FL EXC FUDGED-WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! ***"<<endl;
      cout<<"***FL EXC FUDGED-WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! ***"<<endl;
      cout<<"*******************************************************************************************************************"<<endl;
    }

  for(Int_t i=startfile; i<nfiles; i++)
    { // here fileloop
      cout<<"i is equal: "<<i<<endl;

      if(i==0)
	{// bpeterson_dir_9900_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_dir_9900_all_histosv04.root","READ");
	  else                file = new TFile("b_06p-07p_dir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==1)
	{// bpeterson_res_9900_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_res_9900_all_histosv04.root","READ");
	  else                file = new TFile("b_06p-07p_res.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==2)
	{// bpeterson_exc_g_9900_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_exc_g_9900_all_histosv04.root","READ");
	  else                file = new TFile("b_06p-07p_exgamma.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==3)
	{// bpeterson_exc_p_9900_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_exc_p_9900_all_histosv04.root","READ");
	  else                file = new TFile("b_06p-07p_exproton.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout << file->GetName() <<" : file opened" << endl;
	}
      else if(i==4)
	{// bpeterson_dir_9899_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_dir_9899_all_histosv04.root","READ");
	  else                file = new TFile("b_05e-06e_dir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout << file->GetName() <<" : file opened" << endl;
	}
      else if(i==5)
	{// bpeterson_res_9899_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_res_9899_all_histosv04.root","READ");
	  else                file = new TFile("b_05e-06e_res.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==6)
	{// bpeterson_exc_g_9899_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_exc_g_9899_all_histosv04.root","READ");
	  else                file = new TFile("b_05e-06e_exgamma.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==7)
	{// bpeterson_exc_p_9899_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_exc_p_9899_all_histosv04.root","READ");
	  else                file = new TFile("b_05e-06e_exproton.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==8)
	{// bpeterson_dir_9697_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_dir_9697_all_histosv04.root","READ");
	  else                file = new TFile("b_03p-04p_dir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==9)
	{// bpeterson_res_9697_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_res_9697_all_histosv04.root","READ");
	  else                file = new TFile("b_03p-04p_res.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==10)
	{// bpeterson_exc_g_9697_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_exc_g_9697_all_histosv04.root","READ");
	  else                file = new TFile("b_03p-04p_exgamma.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==11)
	{// bpeterson_exc_p_9697_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("bpeterson_exc_p_9697_all_histosv04.root","READ");
	  else                file = new TFile("b_03p-04p_exproton.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==12)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_06p-07p_dir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==13)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_06p-07p_exgamma.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==14)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_06p-07p_exproton.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==15)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_06p-07p_res.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==16)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_05e-06e_dir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==17)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_05e-06e_exgamma.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==18)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_05e-06e_exproton.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==19)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_05e-06e_res.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==20)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_03p-04p_dir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==21)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_03p-04p_exgamma.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==22)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_03p-04p_exproton.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==23)
	{// ccbar
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_03p-04p_res.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==24)
	{// ccbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_03p-04p_dirrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==25)
	{// ccbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_05e-06e_dirrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==26)
	{// ccbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_06p-07p_dirrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==27)
	{// ccbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_03p-04p_resrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==28)
	{// ccbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_05e-06e_resrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==29)
	{// ccbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("c_06p-07p_resrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==30)
	{// all_BH_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_BH_fudge_040615_extr.root","READ");
	  else                file = new TFile("BH_DIS.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==31)
	{// all_BH_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_BH_fudge_040615_extr.root","READ");
	  else                file = new TFile("BH_elastic.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==32)
	{// all_BH_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_BH_fudge_040615_extr.root","READ");
	  else                file = new TFile("BH_inelastic.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==33)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("jpsi1.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==34)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("jpsi2.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==35)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("psiprime1.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==36)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("psiprime2.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==37)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("upsilon_1sdir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==38)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("upsilon_2sdir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==39)
	{// all_jpsi_hrw_fudge_040615_extr.root
	  if(oldfilestyle)    file = new TFile("all_jpsi_hrw_fudge_040615_extr.root","READ");
	  else                file = new TFile("upsilon_3sdir.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==40)
	{// bbbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("b_03p-04p_dirrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==41)
	{// bbbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("b_05e-06e_dirrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==42)
	{// bbbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("b_06p-07p_dirrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==43)
	{// bbbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("b_03p-04p_resrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==44)
	{// bbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("b_05e-06e_resrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==45)
	{// bbbar Rapgap
	  if(oldfilestyle)    file = new TFile("doesnotexist.root","READ");
	  else                file = new TFile("b_06p-07p_resrap.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}
      else if(i==46)
	{// batch101to106_all_histosv04.root
	  if(oldfilestyle)    file = new TFile("0307p.root","READ");
	  else                file = new TFile("0307p.root","READ");
	  //TIter next( file->GetListOfKeys() );
	  count1=0;
	  cout <<  file->GetName() <<" : file opened" << endl;
	}


    else{
      cout << "bad filenames given, i has value: "<< i << endl;
      continue;
    }

	TIter next( file->GetListOfKeys() );

    while ((key = (TKey *) next())) {
      obj[count1][i] = (TH1D*) file->Get(key->GetName()); // copy object to memory
      obj[count1][i]->SetDirectory(0);

      // do something with obj
      if( previous_obj==key->GetName() )
	{
	  continue;
	}

      previous_obj = key->GetName();
      count1++;
    }

    file->Close();

  }

// reweight MC histos and add the reweighted ones:

  cout<<"Start reweighting and adding MC histos..."<<endl;

  for(Int_t j=startfile; j<nfiles; j++) {
    for(Int_t k=0; k<count1; k++) {
      cout<<".";

//*****************Luminosities for MC Samples*******************
// 			03/04       05/06          06/07
//---------------------------------------------------------------
// incl bbbar
// DIR		       371.61       1797.44        1558.53
// RES		       352.91       1785.22        1555.75
// EXCG		       465.53       1829.81        1416.72
// EXCP		       389.95       1836.76        1736.66
//
//incl ccbar
// DIR                  40.59        190.12         145.90
// EXCG                 40.59        190.12         145.90
// EXCP                 40.59        190.12         145.90
// RES                  40.59        190.12         145.90

      if(j==00)  obj[k][j]->Scale( MC_scale_b *(data_lumi_06_07/            1558.53 ) ); // b_06p-07p_dir.root
      if(j==01)  obj[k][j]->Scale( MC_scale_b *(data_lumi_06_07/            1555.75 ) ); // b_06p-07p_exgamma.root
      if(j==02)  obj[k][j]->Scale( dim_fl_exc*MC_scale_b *(data_lumi_06_07/ 1416.72 ) ); // b_06p-07p_exproton.root
      if(j==03)  obj[k][j]->Scale( dim_fl_exc*MC_scale_b *(data_lumi_06_07/ 1736.66 ) ); // b_06p-07p_res.root

      if(j==04)  obj[k][j]->Scale( MC_scale_b *(data_lumi_05_06/            1797.44 ) ); // b_05e-06e_dir.root
      if(j==05)  obj[k][j]->Scale( MC_scale_b *(data_lumi_05_06/            1785.22 ) ); // b_05e-06e_exgamma.root
      if(j==06)  obj[k][j]->Scale( dim_fl_exc*MC_scale_b *(data_lumi_05_06/ 1829.81 ) ); // b_05e-06e_exproton.root
      if(j==07)  obj[k][j]->Scale( dim_fl_exc*MC_scale_b *(data_lumi_05_06/ 1836.76 ) ); // b_05e-06e_res.root

      if(j==08)  obj[k][j]->Scale( MC_scale_b *(data_lumi_03_04/            371.61 ) ); // b_03p-04p_dir.root
      if(j==09)  obj[k][j]->Scale( MC_scale_b *(data_lumi_03_04/            352.91 ) ); // b_03p-04p_exgamma.root
      if(j==10)  obj[k][j]->Scale( dim_fl_exc*MC_scale_b *(data_lumi_03_04/ 465.53 ) ); // b_03p-04p_exproton.root
      if(j==11)  obj[k][j]->Scale( dim_fl_exc*MC_scale_b *(data_lumi_03_04/ 389.95 ) ); // b_03p-04p_res.root

      if(j==12)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_06_07/ 145.90  ) ); // c_06p-07p_dir.root
      if(j==13)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_06_07/ 145.90  ) ); // c_06p-07p_exgamma.root
      if(j==14)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_06_07/ 145.90  ) ); // c_06p-07p_exproton.root
      if(j==15)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_06_07/ 145.90  ) ); // c_06p-07p_res.root

      if(j==16)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_05_06/ 190.12  ) ); // c_05e-06e_dir.root
      if(j==17)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_05_06/ 190.12  ) ); // c_05e-06e_exgamma.root
      if(j==18)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_05_06/ 190.12  ) ); // c_05e-06e_exproton.root
      if(j==19)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_05_06/ 190.12  ) ); // c_05e-06e_res.root

      if(j==20)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_03_04/  40.59  ) ); // c_03p-04p_dir.root
      if(j==21)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_03_04/  40.59  ) ); // c_03p-04p_exgamma.root
      if(j==22)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_03_04/  40.59  ) ); // c_03p-04p_exproton.root
      if(j==23)  obj[k][j]->Scale( useccbarincl*MC_scale_c *(data_lumi_03_04/  40.59  ) ); // c_03p-04p_res.root

      if(j==24)  obj[k][j]->Scale( rapgapscale*MC_scale_c *(data_lumi_03_04/ 124.491  ) ); // c_03p-04p_dirrap.root
      if(j==25)  obj[k][j]->Scale( rapgapscale*MC_scale_c *(data_lumi_05_06/ 449.839  ) ); // c_05e-06e_dirrap.root
      if(j==26)  obj[k][j]->Scale( rapgapscale*MC_scale_c *(data_lumi_06_07/ 498.047  ) ); // c_06p-07p_dirrap.root
      if(j==27)  obj[k][j]->Scale( rapgapscale*MC_scale_c *(data_lumi_03_04/  41.444  ) ); // c_03p-04p_resrap.root
      if(j==28)  obj[k][j]->Scale( rapgapscale*MC_scale_c *(data_lumi_05_06/ 202.371  ) ); // c_05e-06e_resrap.root
      if(j==29)  obj[k][j]->Scale( rapgapscale*MC_scale_c *(data_lumi_06_07/ 498.113  ) ); // c_06p-07p_resrap.root

      if(j==30)  obj[k][j]->Scale( MC_scale_BH_DIS        *(data_lumi/       21808.51 ) ); // BH_DIS.root
      if(j==31)  obj[k][j]->Scale( MC_scale_BH_ela        *(data_lumi/        1546.21 ) ); // BH_elastic.root
      if(j==32)  obj[k][j]->Scale( MC_scale_BH_inela      *(data_lumi/        2740.01 ) ); // BH_inelastic.root
      if(j==33)  obj[k][j]->Scale( MC_scale_jpsi1         *(data_lumi/        7144.6  ) ); // jpsi1.root
      if(j==34)  obj[k][j]->Scale( MC_scale_jpsi2         *(data_lumi/        1786.57 ) ); // jpsi2.root
      if(j==35)  obj[k][j]->Scale( MC_scale_psiprime1     *(data_lumi/        5916.6  ) ); // psiprime1.root
      if(j==36)  obj[k][j]->Scale( MC_scale_psiprime2     *(data_lumi/      581.39536 ) ); // psiprime2.root
      if(j==37)  obj[k][j]->Scale( MC_scale_ups1          *(data_lumi/        357.608 ) ); // upsilon_1sdir.root
      if(j==38)  obj[k][j]->Scale( MC_scale_ups2          *(data_lumi/        357.608 ) ); // upsilon_2sdir.root
      if(j==39)  obj[k][j]->Scale( MC_scale_ups3          *(data_lumi/        357.608 ) ); // upsilon_3sdir.root

      if(j==40)  obj[k][j]->Scale( rapgapscale*MC_scale_b *(data_lumi_03_04/ 1167.787  ) ); // b_03p-04p_dirrap.root
      if(j==41)  obj[k][j]->Scale( rapgapscale*MC_scale_b *(data_lumi_05_06/ 3040.652  ) ); // b_05e-06e_dirrap.root
      if(j==42)  obj[k][j]->Scale( rapgapscale*MC_scale_b *(data_lumi_06_07/ 2577.944  ) ); // b_06p-07p_dirrap.root
      if(j==43)  obj[k][j]->Scale( rapgapscale*MC_scale_b *(data_lumi_03_04/ 1167.247  ) ); // b_03p-04p_resrap.root
      if(j==44)  obj[k][j]->Scale( rapgapscale*MC_scale_b *(data_lumi_05_06/ 3039.42   ) ); // b_05e-06e_resrap.root
      if(j==45)  obj[k][j]->Scale( rapgapscale*MC_scale_b *(data_lumi_06_07/ 2500.     ) ); // b_06p-07p_resrap.root

// add lumi-reweighted beauty histos to first beauty histo sample:

      if(j!=0 && j!=dataposition && (j<charmbegin || j>charmend) )
	{
	  obj[k][0]->Add(obj[k][j],1);  // ccbar MC is added later on below!
	  //cout<<"beauty histo adding section: j used: "<<j<<" k used: "<<k<<"    Added histo: "<<obj[k][0]->GetName()<<" to histo: "<<obj[k][j]->GetName()<<endl;
	}

// add lumi-reweighted charm histos to first charm histo sample:

      if(j!=0 && j!=dataposition &&  j!=charmbegin && !(j<charmbegin || j>charmend) && j!=BH_position1 && j!=BH_position2 && j!=BH_position3 && j!= jpsi_position1 && j!= jpsi_position2 && j!= psiprime_position1 && j!= psiprime_position2 && j!= ups1_position && j!= ups2_position && j!= ups3_position )
	{
	  obj[k][charmbegin]->Add(obj[k][j],1); // ccbar MC is added to ccbar MC here - added to total MC estimate later!
	  //cout<<"charm histo adding section: j used: "<<j<<" k used: "<<k<<"    Added histo: "<<obj[k][0]->GetName()<<" to histo: "<<obj[k][j]->GetName()<<endl;
	}
    }
  }

  cout<<endl<<"Done reweighting and adding MC histos."<<endl;


  Int_t  pl_range = 1;        // set equal nhistos below
  Bool_t plot_good, lastplot;

  // prepared checked types:
  // typechooser = 0;  // mmu
  // typechooser = 1;  // DR
  // typechooser = 4;  // mupt
  // typechooser = 6;  // muqual
  // typechooser = 7;  // mueta
  // typechooser = 8;  // calet
  // typechooser = 10; // pt_asym -> Doesn/t work yet - rebinning...
  // typechooser = 11;  // dphii
  // typechooser = 12;  // deta
  // typechooser = 13;
  // //
  // ***************************************
  // choose low mass (1) / high mass (3) range here:
  // also is, nis or nisandis
  // ***************************************

  if(plot_hm)rangechooser = 3; // hm_us
  else       rangechooser = 1; // lm_us

  if(iso_chooser == "nis") {
    cout<<"Thinking you want iso range: nis"<<endl;
    rangechooser+=8;
  }
  else if(iso_chooser == "is") {
    cout<<"Thinking you want iso range: is"<<endl;
    rangechooser+=4;
  }
  else if(iso_chooser == "nisandis") {
    cout<<"Thinking you want iso range: nisandis"<<endl;
    rangechooser+=0; // good - +4 works
  }
  else {
    //    rangechooser+=4;
    cout<<endl<<"*** ERROR! no proper iso range chosen - exiting"<<endl<<endl;
    cout<<"Possible isolation choices are: nis, is & nisandis"<<endl;
    break;
  }
  if(!(rangechooser == 3 || rangechooser == 1 || rangechooser == 7 || rangechooser == 5 || rangechooser == 11 || rangechooser == 9 )) {
    cout<<"*** Error: ! No range (hm or lm) chosen - exiting."<<endl;
    break;
  }

  nhistos = count1/nrows;
  pl_range = nhistos;

  TH1D* hm_us_bMC[1000];
  TH1D* hm_ls_data[1000];
  TH1D* hm_ls_bMC_lfl[1000];
  TH1D* hm_us_bMC_buffer[1000];
  TH1D* hm_ls_bMC_buffer[1000];
  TH1D* bMC_u_plus_l[1000];
  TH1D* bMC_u_minus_l[1000];
  TH1D* cMC_orig[1000];
  TH1D* b_frac[1000];
  TH1D* b_acc[1000];
  TH1D* b_MCrec[1000];
  TH1D* b_xsec[1000];
  TH1D* xsec_buffer[1000];
  TH1D* Charm_MC_p_lfl_bg[1000];
  TH1D* jpsi_p_Charm_MC_p_lfl_bg[1000];
  TH1D* lfl_bg_us[1000];
  TH1D* lfl_bg_ls[1000];
  TH1D* hm_ls_bMC[1000];
  TH1D* orig_true[1000];
  TH1D* BH_p_jpsi_p_Charm_MC_p_lfl_bg[1000];

  TString title, histoname;

  for(Int_t plotss = 0; plotss < pl_range; plotss++)
    { // plotting loop start >>>
      title =obj[plotss+rangechooser*nhistos][dataposition]->GetTitle();

    //    getchar();
    //    if(plotss != 0 && plotss!= 3 ) continue;

      cout<<"plotss: "<<plotss<<" Name: "<<obj[plotss+rangechooser*nhistos][dataposition]->GetName()<<" Title: "<<obj[plotss+rangechooser*nhistos][dataposition]->GetTitle()<<endl;

    // if(title=="hu etex2ir_nis")cout<<endl<<endl<<"************************************** HIT ********************************"<<endl;
    // if(title!="hu etex2ir_nis")cout<<endl<<endl<<"************************************** should continue ********************************"<<endl;
    // if(title.Contains("etex2ir_nis")|| title.Contains("dimuxsecpt_nis"))cout<<endl<<endl<<"************************************** HIT ******************************** titl: "<<title<<endl;
    // if()cout<<endl<<endl<<"************************************** should continue ********************************"<<endl;
    // was like this 060407
      // if( (!( title.Contains("etex2ir_nis") || title.Contains("dimuxsecpt_nis") || title.Contains("dimuxseceta_nis") || title.Contains("dimuxsecdr_nis") || title.Contains("dimuxsecdphi_nis") || title.Contains("dimuxsecptb_nis") || title.Contains("dimuxsecfinders_nis") )  && autoquit )|| (plotss > 10 && autoquit) ) continue;

    if( (!( title.Contains("etex2ir_nis") || title.Contains("dimuxsecpt_nis") || title.Contains("dimuxseceta_nis") || title.Contains("dimuxsecdr_nis") || title.Contains("dimuxsecdphi_nis") || title.Contains("dimuxsecptb_nis") || title.Contains("dimuxsecptb_sameb_nis") || title.Contains("dimuxsecptb_diffb_nis") || title.Contains("dimuxsecptb_samecone_nis") || title.Contains("dimuxsecptb_asym_nis") || title.Contains("dimuxsecfinders_nis") )  && autoquit )|| (plotss > 6+5 && autoquit) ) continue;

    // if( (!( title.Contains("etex2ir_nis") || title.Contains("dimuxsecpt_nis") || title.Contains("dimuxseceta_nis") || title.Contains("dimuxsecdr_nis") || title.Contains("dimuxsecdphi_nis") )  && autoquit )|| plotss > 0 ) continue;
    // if( (!(  title.Contains("dimuxsecpt_nis")  )  && autoquit )|| plotss > 4 ) continue;
    // if( (plotss != 0 || ! ( (title.Contains("etex2ir_nis"))||(title.Contains("dimuxsecpt_nis")) ) )&& autoquit ) continue;
    //    if ( plotss != 0 ) continue;

    plot_good = false;
    lastplot  = false;

    if( ( plotss != 2 && plotss != 3 && plotss != 5 && plotss != 9 ) || (fromoli) )
      { // choice of histos to plot

      //  if( !(obj[histonr][dataposition]->IsA()->InheritsFrom("TH2F")) ){ // choice of histos to plot

      plot_good = true;
      if(plotss == pl_range-1) lastplot = true;

// set histonr form type and rangechooser:
      typechooser = plotss;
      histonr     = typechooser + rangechooser*nhistos;

      MCintegral   = 0.;
      dataintegral = 0.;
      MCintegral   = obj[histonr][0]->Integral();
      dataintegral = obj[histonr][dataposition]->Integral();

//      cout<<" *** b MC us *** "<<obj[histonr][0]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<MCintegral<<endl;
//      cout<<" *** data us *** "<<obj[histonr][dataposition]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<dataintegral<<endl;

      MCintegral   = 0.;
      dataintegral = 0.;
      MCintegral   = obj[histonr+nhistos][0]->Integral();
      dataintegral = obj[histonr+nhistos][dataposition]->Integral();

//      cout<<" *** b MC ls *** "<<obj[histonr+nhistos][0]->GetName()<<" with hnr "<<histonr+nhistos<<" has Integral: "<<MCintegral<<endl;
//      cout<<" *** data ls *** "<<obj[histonr+nhistos][dataposition]->GetName()<<" with hnr "<<histonr+nhistos<<" has Integral: "<<dataintegral<<endl;

// here: "correct" [beauty_hm only!!!!(=obj[histonr][0](us) und histonr+nhistos (ls) )] us and ls distribs -> us' = (1-mixing)*us + mixing*ls && ls' = (1-mixing)*ls + mixing*us
// with mixing = 0.3 for the moment
// TH1D* hm_us_bMC_buffer[plotss]  = (TH1D*) obj[histonr][0]->Clone("hm_us_bMC_buffer");
// TH1D* hm_ls_bMC_buffer[plotss]  = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC_buffer");

      hm_us_bMC_buffer[plotss]  = (TH1D*) obj[histonr][0]->Clone("hm_us_bMC_buffer");
      hm_ls_bMC_buffer[plotss]  = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC_buffer");

      if(b_mixing != 0.0 && plot_hm) {
	cout<<"**************************************************************************************"<<endl;
	cout<<"**** WARNING!!! B mixing is enabled!!!! ***** mixing factor is: "<<b_mixing<<" ******************"<<endl;
	cout<<"**************************************************************************************"<<endl;
	cout<<"**** cloning these histos: "<<	obj[histonr][0]->GetName()<<endl;
	cout<<"**** and:                  "<<	obj[histonr+nhistos][0]->GetName()<<endl;

	//	TH1D* hm_us_bMC_buffer[plotss]  = (TH1D*) obj[histonr][0]->Clone("hm_us_bMC_buffer");
	//	TH1D* hm_ls_bMC_buffer[plotss]  = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC_buffer");
	//  Add(const TH1 *h1, const TH1 *h2, Double_t c1, Double_t c2)
	//    -*-*-*Replace contents of this histogram by the addition of h1 and h2*-*-*
	//          ===============================================================
	//    this = c1*h1 + c2*h2
	obj[histonr][0]->        Add(hm_us_bMC_buffer[plotss], hm_ls_bMC_buffer[plotss],(1. - b_mixing), b_mixing );
	obj[histonr+nhistos][0]->Add(hm_ls_bMC_buffer[plotss], hm_us_bMC_buffer[plotss],(1. - b_mixing), b_mixing );
	cout<<"Directly after mixing. b MC us integral ="<<obj[histonr][0]->Integral()<<endl;
	cout<<"Directly after mixing. b MC ls integral ="<<obj[histonr+nhistos][0]->Integral()<<endl;
      }

      // set rebinvalues individually for each histo type:
      strbuffer = obj[histonr][dataposition]->GetName();
      cout<<"We are at histo: "<<strbuffer<<" with histonr: "<<histonr<<endl;
      cout<<"We are also at:  "<<obj[histonr+nhistos][dataposition]->GetName()<<" with histonr: "<<histonr+nhistos<<endl;
      //      getchar();
      //      if(!(strbuffer.Contains("mmu") || strbuffer.Contains("dimupt")) ) continue;

      if(plot_dists_std || plot_dists_kum)  cc = new TCanvas();
      if((plot_dists_std || plot_dists_kum) && plot_ls ) cc->Divide(1,2);
      if((plot_dists_std || plot_dists_kum) && plot_ls ) cc->cd(2);

      if( strbuffer.Contains("mmu") ) {
 	if( strbuffer.Contains("lm") ) rebinvalue = 16;
 	else if(strbuffer.Contains("hm_us_is"))
 	  rebinvalue = 20;
 	else
 	  rebinvalue = 12; // choose 10 for comparison with achim 05012
 	//	  rebinvalue = 6; // choose 10 for comparison with achim 05012
 	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	rebinvalue = 0;
	MC_first = false;
      }
      else if( strbuffer.Contains("DR") ) {
		rebinvalue = 2;
	//	rebinvalue = 2*10;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("ptmu") ) {
	rebinvalue = 2;
	if(fromoli && (!(iso_chooser == "is") || !plot_hm) ) rebinvalue = 2;
	if(fromoli && (iso_chooser == "is") && plot_hm) rebinvalue = 3;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	//	MC_first = true;
	MC_first = false;
      }
      else if( strbuffer.Contains("mueta") && !(strbuffer.Contains("dimueta"))) {
	rebinvalue = 2*2*2;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("dimueta")) {
	rebinvalue = 2*2*2;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("calet") ) {
	rebinvalue = 5;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("ptasym") ) {
	//      rebinvalue = 2; // out 040622
	rebinvalue = 0;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("dphii") ) {
	//	rebinvalue = 2;
	//	rebinvalue = 2*13;
	//	rebinvalue = 8;
	rebinvalue = 0;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("deta") ) {
	rebinvalue = 2;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("thrust") && !strbuffer.Contains("ptrel") ) {
	rebinvalue = 2;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("dimuphi")  ) {
	rebinvalue = 10;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("ptrel") ) {
	rebinvalue = 0;
	//      cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	//	cout<<strbuffer<<" c has entries: "<<obj[histonr+nhistos][charmbegin]->GetEntries()<<endl;
	//	cout<<strbuffer<<" b has entries: "<<obj[histonr+nhistos][0]->GetEntries()<<endl;
	//	cout<<strbuffer<<" data has entries: "<<obj[histonr+nhistos][dataposition]->GetEntries()<<endl;
	//	MC_first = true;
	MC_first = false;
      }
      else if( strbuffer.Contains("sqsum") ) {
	//	rebinvalue = 6;
	rebinvalue = 6;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else if( strbuffer.Contains("cal_et") ) {
	//	rebinvalue = 6;
	rebinvalue = 4;
	//	cout<<strbuffer<<" has nbinsX: "<<obj[histonr][0]->GetNbinsX()<<" rebinning by: "<<rebinvalue<<endl;
	MC_first = false;
      }
      else {
	rebinvalue = 0;
	MC_first = false;
      }

// do some proper adding (only MC and bg estimates are modified, data is left alone)
// TH1D* hm_us_bMC[plotss]  = (TH1D*) obj[histonr][0]->Clone("hm_us_bMC");
// TH1D* cMC_orig[plotss]   = (TH1D*) obj[histonr][charmbegin]->Clone("cMC_orig");

      hm_us_bMC[plotss]  = (TH1D*) obj[histonr][0]->Clone("hm_us_bMC");

//       hm_ls_bMC[plotss]  = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC");

      if(calc_b_frac){

// fill MC true container with true info:

//  if( title.Contains("etex2ir_nis") )              orig_true[plotss] = (TH1D*) obj[0][0]   -> Clone("orig_true");
//  if( title.Contains("etex2ir_nis") )              orig_true[plotss] = (TH1D*) obj[5][0]   -> Clone("orig_true");
//  else if( title.Contains("dimuxsecpt_nis") )      orig_true[plotss] = (TH1D*) obj[6][0]   -> Clone("orig_true");
//  else if( title.Contains("dimuxseceta_nis") )     orig_true[plotss] = (TH1D*) obj[7][0]   -> Clone("orig_true");
//  else if( title.Contains("dimuxsecfinders_nis") ) orig_true[plotss] = (TH1D*) obj[8][0]   -> Clone("orig_true");
//  else if( title.Contains("dimuxsecdr_nis") )      orig_true[plotss] = (TH1D*) obj[9][0]   -> Clone("orig_true");
//  else if( title.Contains("dimuxsecdphi_nis") )    orig_true[plotss] = (TH1D*) obj[10][0]  -> Clone("orig_true");

//  if( title.Contains("etex2ir_nis") )              orig_true[plotss] = (TH1D*) obj[138][0] -> Clone("orig_true");
//  else if( title.Contains("dimuxsecpt_nis") )      orig_true[plotss] = (TH1D*) obj[139][0] -> Clone("orig_true");
//  else if( title.Contains("dimuxseceta_nis") )     orig_true[plotss] = (TH1D*) obj[140][0] -> Clone("orig_true");
//  else if( title.Contains("dimuxsecfinders_nis") ) orig_true[plotss] = (TH1D*) obj[141][0] -> Clone("orig_true");
//  else if( title.Contains("dimuxsecdr_nis") )      orig_true[plotss] = (TH1D*) obj[142][0] -> Clone("orig_true");
//  else if( title.Contains("dimuxsecdphi_nis") )    orig_true[plotss] = (TH1D*) obj[143][0] -> Clone("orig_true");

// obj[161] contains object:  h_mcdimumass1bin_true_hfl_mu_hm_us_nis
// obj[162] contains object:  h_mcdimuxsecPt_true_hfl_mu_hm_us_nis
// obj[163] contains object:  h_mcdimuxsecEta_true_hfl_mu_hm_us_nis
// obj[164] contains object:  h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis
// obj[165] contains object:  h_mcdimuxsecDR_true_hfl_mu_hm_us_nis
// obj[166] contains object:  h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis
// obj[167] contains object:  h_mcdimuxsecPtb_true_hfl_mu_hm_us_nis
// with additional plots May 06
// obj[253] contains object:  h_mcdimumass1bin_true_hfl_mu_hm_us_nis
// obj[254] contains object:  h_mcdimuxsecPt_true_hfl_mu_hm_us_nis
// obj[255] contains object:  h_mcdimuxsecEta_true_hfl_mu_hm_us_nis
// obj[256] contains object:  h_mcdimuxsecFinders_true_hfl_mu_hm_us_nis
// obj[257] contains object:  h_mcdimuxsecDR_true_hfl_mu_hm_us_nis
// obj[258] contains object:  h_mcdimuxsecDphi_true_hfl_mu_hm_us_nis
// obj[259] contains object:  h_mcdimuxsecPtb_true_hfl_mu_hm_us_nis
// obj[260] contains object:  h_mcdimuxsecPtb_sameb_true_hfl_mu_hm_us_nis
// obj[261] contains object:  h_mcdimuxsecPtb_diffb_true_hfl_mu_hm_us_nis
// obj[262] contains object:  h_mcdimuxsecPtb_samecone_true_hfl_mu_hm_us_nis
// obj[263] contains object:  h_mcdimuxsecPtb_asym_true_hfl_mu_hm_us_nis
//	cout<<"### INFO ###: Histo title is: "<<title<<" at plotss: "<<plotss<<" next number is 1 if title contians dimuxsecpt_nis"<<1*title.Contains("dimuxsecpt_nis")<<endl;
       /*
	if( title.Contains("etex2ir_nis") )                     orig_true[plotss] = (TH1D*) obj[242][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecpt_nis") )             orig_true[plotss] = (TH1D*) obj[243][0]->Clone("orig_true");
	else if( title.Contains("dimuxseceta_nis") )            orig_true[plotss] = (TH1D*) obj[244][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecfinders_nis") )        orig_true[plotss] = (TH1D*) obj[245][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecdr_nis") )             orig_true[plotss] = (TH1D*) obj[246][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecdphi_nis") )           orig_true[plotss] = (TH1D*) obj[247][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_nis") )            orig_true[plotss] = (TH1D*) obj[248][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_sameb_nis") )      orig_true[plotss] = (TH1D*) obj[249][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_diffb_nis") )      orig_true[plotss] = (TH1D*) obj[250][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_samecone_nis") )   orig_true[plotss] = (TH1D*) obj[251][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_asym_nis") )       orig_true[plotss] = (TH1D*) obj[252][0]->Clone("orig_true");

	if( title.Contains("etex2ir_nis") )                     orig_true[plotss] = (TH1D*) obj[253][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecpt_nis") )             orig_true[plotss] = (TH1D*) obj[254][0]->Clone("orig_true");
	else if( title.Contains("dimuxseceta_nis") )            orig_true[plotss] = (TH1D*) obj[255][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecfinders_nis") )        orig_true[plotss] = (TH1D*) obj[256][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecdr_nis") )             orig_true[plotss] = (TH1D*) obj[257][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecdphi_nis") )           orig_true[plotss] = (TH1D*) obj[258][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_nis") )            orig_true[plotss] = (TH1D*) obj[259][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_sameb_nis") )      orig_true[plotss] = (TH1D*) obj[260][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_diffb_nis") )      orig_true[plotss] = (TH1D*) obj[261][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_samecone_nis") )   orig_true[plotss] = (TH1D*) obj[262][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecptb_asym_nis") )       orig_true[plotss] = (TH1D*) obj[263][0]->Clone("orig_true");
	*/

	if( title.Contains("etex2ir_nis") )                     orig_true[plotss] = (TH1D*) obj[138][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecpt_nis") )             orig_true[plotss] = (TH1D*) obj[139][0]->Clone("orig_true");
	else if( title.Contains("dimuxseceta_nis") )            orig_true[plotss] = (TH1D*) obj[140][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecfinders_nis") )        orig_true[plotss] = (TH1D*) obj[141][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecdr_nis") )             orig_true[plotss] = (TH1D*) obj[142][0]->Clone("orig_true");
	else if( title.Contains("dimuxsecdphi_nis") )           orig_true[plotss] = (TH1D*) obj[143][0]->Clone("orig_true");

	else{
	  orig_true[plotss] = (TH1D*) obj[2][0]->Clone("orig_true");
	  cout<<"ERROR!!! Something went wrong here (in test_inclFinder_and_pTb_samediff_080115)."<<endl;
	  cout<<"Did not find the MC true info corresponding to these histos! - I'll break as soon as anykey is pressed!"<<endl;
	  getchar();
	  break;
	}
      }
      cMC_orig[plotss]   = (TH1D*) obj[histonr][charmbegin]->Clone("cMC_orig");

      if(42 == 42){
	// charmsubmarker
      // prepare charm MC. Subtract charm like sign part ("fake") from charm unlike sign ("real"):
	// WARNING: Now (050410) charm contains open charm only! NO jpsi, psiprime, thus ls bg is subtracted for them here too.
// 	obj[histonr][charmbegin]->ls();
// 	obj[histonr+nhistos][charmbegin]->ls();
// 	getchar();

	obj[histonr][charmbegin]->Add(obj[histonr+nhistos][charmbegin],-1);
	obj[histonr][jpsi_position1]     ->Add(obj[histonr+nhistos][jpsi_position1],-1);
	obj[histonr][jpsi_position2]     ->Add(obj[histonr+nhistos][jpsi_position2],-1);
	obj[histonr][psiprime_position1] ->Add(obj[histonr+nhistos][psiprime_position1],-1);
	obj[histonr][psiprime_position2] ->Add(obj[histonr+nhistos][psiprime_position2],-1);
	obj[histonr][BH_position1]       ->Add(obj[histonr+nhistos][BH_position1],-1);
	obj[histonr][BH_position2]       ->Add(obj[histonr+nhistos][BH_position2],-1);
	obj[histonr][BH_position3]       ->Add(obj[histonr+nhistos][BH_position3],-1);
	obj[histonr][ups1_position]      ->Add(obj[histonr+nhistos][ups1_position],-1);
	obj[histonr][ups2_position]      ->Add(obj[histonr+nhistos][ups2_position],-1);
	obj[histonr][ups3_position]      ->Add(obj[histonr+nhistos][ups3_position],-1);
	//      cout<<"Charm: subtracting charm like sign background!!"<<endl;
      }

      else{
	cout<<"*"<<endl;
	cout<<"***"<<endl;
	cout<<"*****"<<endl;
	cout<<"******** ERROR!!! Not subtracting charm like sign background!!"<<endl;
	cout<<"*****"<<endl;
	cout<<"***"<<endl;
	cout<<"*"<<endl;
      }
      // the tag "hm" in the name of this histo is historic and WRONG! it is also "lm" in lm mode!! 050417
      if(plot_ls || calc_b_frac) hm_ls_data[plotss] = (TH1D*) obj[histonr+nhistos][dataposition]->Clone("hm_ls_data");

      //      cout<<"After cloning... "<<strbuffer<<endl;

      //cout<<histonr+nhistos<<" "<<dataposition<<" obj[histonr+nhistos][dataposition]->GetName(): "<<obj[histonr+nhistos][dataposition]->GetName()<<endl;
      //cout<<histonr<<" "<<dataposition<<" obj[histonr][dataposition]->GetName(): "<<obj[histonr][dataposition]->GetName()<<endl;
      //obj[histonr+nhistos][dataposition]->Draw();
      //return;

      cout<<"Before lf bg estimate... "<<endl;

      MCentries   = 0;
      dataentries = 0;
      MCentries   = obj[histonr][0]->GetEntries();
      dataentries = obj[histonr+nhistos][dataposition]->GetEntries();

      cout<<obj[histonr+nhistos][dataposition]->GetName()<<" has entries: "<<dataentries<<endl;
      cout<<obj[histonr][0]->GetName()<<" has entries: "<<MCentries<<endl;

      obj[histonr+nhistos][dataposition]->Add(obj[histonr+nhistos][0],-1); // subtract b-MC hm_ls
                                                                           //from hm_ls data = lfl_ls_bg = lfl_us_bg

// treat unlike sign and like sign BG differently:

      lfl_bg_us[plotss] = (TH1D*) obj[histonr+nhistos][dataposition]->Clone("lfl_bg_us");
      lfl_bg_ls[plotss] = (TH1D*) obj[histonr+nhistos][dataposition]->Clone("lfl_bg_ls");

// correct for small ls us asymetry:

        if(plot_hm) us_bg_corr = 1.02;
        else        us_bg_corr = 1.06;

//        if(plot_hm) us_bg_corr = 1.0;
//        else us_bg_corr = 1.0;
//        cout<<"WARNING!!!! DISABLED BG estimate correction for tests!!!!!"<<endl;

      lfl_bg_us[plotss]->Scale(us_bg_corr);

      //add total MC sum:

      obj[histonr][0]->Add(obj[histonr][charmbegin],1);         // add  c-MC hm_us-ls    to   b-MC
      obj[histonr][0]->Add(obj[histonr][BH_position1],1);       // add  BH-MC-ls         to   b-MC
      obj[histonr][0]->Add(obj[histonr][BH_position2],1);       // add  BH-MC-ls         to   b-MC
      obj[histonr][0]->Add(obj[histonr][BH_position3],1);       // add  BH-MC-ls         to   b-MC
      obj[histonr][0]->Add(obj[histonr][jpsi_position1],1);     // add  jpsi-MC-ls       to   b-MC
      obj[histonr][0]->Add(obj[histonr][jpsi_position2],1);     // add  jpsi-MC-ls       to   b-MC
      obj[histonr][0]->Add(obj[histonr][psiprime_position1],1); // add  psiprime-MC-ls   to   b-MC
      obj[histonr][0]->Add(obj[histonr][psiprime_position2],1); // add  psiprime-MC-ls   to   b-MC
      obj[histonr][0]->Add(obj[histonr][ups1_position],1);      // add  Y-MC-ls          to   b-MC
      obj[histonr][0]->Add(obj[histonr][ups2_position],1);      // add  Y-MC-ls          to   b-MC
      obj[histonr][0]->Add(obj[histonr][ups3_position],1);      // add  Y-MC-ls          to   b-MC


      cout<<" Todays output:"<<endl;
      cout<<" fixed BG+b_ul  hm nis us histo entries:"<<obj[histonr][0]->GetEntries()<<" Integral: "<<obj[histonr][0]->Integral()<<endl;

      all_bg_p_beauty_m_lfl_bg_u = obj[histonr][0]->Integral();
      obj[histonr][0]->Add(lfl_bg_us[plotss],1);          // add      lfl_us_bg        to   b-MC

      cout<<"After lf bg estimate... "<<endl;

      MCentries     = 0;
      dataentries   = 0;
      MCallintegral = 0;
      MCintegral    = hm_us_bMC[plotss]->Integral();
      MCentries     = obj[histonr][0]->GetEntries();
      MCallintegral = obj[histonr][0]->Integral();

      dataintegral  =  obj[histonr][dataposition]->Integral();
      dataentries   = lfl_bg_us[plotss]->GetEntries();

      cout<<lfl_bg_us[plotss]->GetName()<<" lfl bg has entries: "<<dataentries<<endl;
      cout<<obj[histonr][0]->GetName()<<" has entries: "<<MCentries<<endl;

      cout<<endl<<" *** THESE ARE GOOD!! *** b MC us   *** "<<obj[histonr][0]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<MCintegral<<endl; // using obj[histonr][0] only for name! integral value is taken correctly from  hm_us_bMC[plotss]. 050417
      cout<<" *** THESE ARE GOOD!! *** all MC us *** "<<obj[histonr][0]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<MCallintegral<<endl;
      cout<<" *** THESE ARE GOOD!! *** data us   *** "<<obj[histonr][dataposition]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<dataintegral<<endl<<endl;


      cout<<" Todays output:"<<endl;
      cout<<" charm  hm nis us histo entries:"<<cMC_orig[plotss]->GetEntries()<<" Integral: "<<cMC_orig[plotss]->Integral()<<endl;
      cout<<" charm  hm nis ls histo entries:"<<obj[histonr+nhistos][charmbegin]->GetName()<<" "<<obj[histonr+nhistos][charmbegin]->GetEntries()<<" Integral: "<<obj[histonr+nhistos][charmbegin]->Integral()<<endl;

      cout<<endl<<" beauty hm nis us histo entries:"<<hm_us_bMC_buffer[plotss]->GetEntries()<<" Integral: "<<hm_us_bMC_buffer[plotss]->Integral()<<endl;
      cout<<" beauty hm nis ls histo entries:"<<hm_ls_bMC_buffer[plotss]->GetEntries()<<" Integral: "<<hm_ls_bMC_buffer[plotss]->Integral()<<endl;
//       getchar();

      MCintegral_ls = obj[histonr+nhistos][0]->Integral();
      if(plot_ls) dataintegral_ls =  hm_ls_data[plotss]->Integral();

      cout<<endl<<" *** THESE ARE GOOD!! *** b MC ls   *** "<<obj[histonr+nhistos][0]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<MCintegral_ls<<endl;
      if(plot_ls)       cout<<" *** THESE ARE GOOD!! *** data ls   *** "<<hm_ls_data[plotss]->GetName()<<" with hnr "<<histonr<<" has Integral: "<<dataintegral_ls<<endl<<endl;

// s_MC^b = (d^u-d^l-(c^u+bh^u+jpsi^u+psiprime^u))/(b^u-b^l)

      data_unlike   = dataintegral;
      data_like     = dataintegral_ls;
      beauty_unlike = MCintegral;
      beauty_like   = MCintegral_ls;

      if(plot_ls && (beauty_unlike - beauty_like)!=0) cout<<"And your beauty scale is: "<<(data_unlike - data_like - (all_bg_p_beauty_m_lfl_bg_u-beauty_unlike))/(beauty_unlike - beauty_like)<<endl;
      else if((beauty_unlike - beauty_like)==0) cout<<"Captain - this might be a problem here...!"<<endl;
      //      getchar();

      if(42 == 8)
      //      if( 42 == 42 )
	{

//*****************************************************************************************;
// calc xsecs here: ***** start ***********************************************************;
//*****************************************************************************************;

	  xsec_buffer[plotss]  = (TH1D*) obj[histonr][0]->Clone("xsec_buffer");
	  cout<<" we got "<<xsec_buffer[plotss]->GetNbinsX()<<" bins in "<<xsec_buffer[plotss]->GetName()<<endl;
	  cout<<" plotss is: "<<plotss<<endl;
	  for(Int_t binloop = 0; binloop <= xsec_buffer[plotss]->GetNbinsX(); ++binloop) {
	  //	xsec_buffer[plotss]->ls();
	  //	cout<<"binloop is: "<<binloop<<" plotss is: "<<plotss<<endl;
	    xsec_buffer[plotss]->SetBinContent(binloop+1, (hm_us_bMC[plotss]->GetBinContent(binloop+1)+obj[histonr+nhistos][0]->GetBinContent(binloop+1)) / data_lumi );
	  //	binerror =	TMath::Sqrt(obj[histonr][0]->GetBinContent(binloop+1) / data_lumi)*0.000001 ;
	  //	binerror = 0.1;
	  //	binerror = TMath::Sqrt( TMath::Power( TMath::Sqrt(hm_us_bMC[plotss]->GetBinContent(binloop+1)+obj[histonr+nhistos][0]->GetBinContent(binloop+1)) / data_lumi, 2.) + TMath::Power(hm_us_bMC[plotss]->GetBinContent(binloop+1)*data_lumi*0.02 / (data_lumi*data_lumi), 2.) );

	  // It is WRONG to calc the error likewise. I need to get the error of the beauty etc. sections included,
	  // etc. -> This is just a small test!! 050124
	    binerror = TMath::Sqrt( TMath::Power( 0.1*(hm_us_bMC[plotss]->GetBinContent(binloop+1)+obj[histonr+nhistos][0]->GetBinContent(binloop+1)) / data_lumi, 2.) + TMath::Power(hm_us_bMC[plotss]->GetBinContent(binloop+1)*data_lumi*0.0225 / (data_lumi*data_lumi), 2.) );
	    xsec_buffer[plotss]->SetBinError(binloop+1, binerror);
	  }
	  cout<<"here comes your    xsec in 0th iteration: "<< (MCintegral+MCintegral_ls) / data_lumi <<" pb"<<endl;
	  cout<<"here comes your us xsec in 0th iteration: "<< (MCintegral) / data_lumi <<" pb"<<endl;
	  cout<<"here comes your ls xsec in 0th iteration: "<< (MCintegral_ls) / data_lumi <<" pb"<<endl;
	//*****************************************************************************************;
	// calc xsecs here: ***** end *************************************************************;
	//*****************************************************************************************;
	}

      //      getchar();
      if(plot_dists_std){
	// some plotting...
	if(MC_first) obj[histonr][0]->Draw("hist");   //draw MC description first to set the scale

	obj[histonr][dataposition]->SetMarkerStyle(8);
	if(bigmarker) obj[histonr][dataposition]->SetMarkerSize(2.);
	if(rebinvalue > 0) {
	  obj[histonr][dataposition]->Rebin(rebinvalue);
	  //	lfl_bg_us[plotss]->Rebin(rebinvalue);
	}
	if (MC_first)  obj[histonr][dataposition]->Draw("E P same");    // us data
	else obj[histonr][dataposition]->Draw("E P");    // us data

	obj[histonr][0]->SetFillColor(3);
	obj[histonr][0]->SetFillStyle(3001);
	if(rebinvalue > 0) {
	  obj[histonr][0]->Rebin(rebinvalue);
	  //	obj[histonr+nhistos][0]->Rebin(rebinvalue);
	}
	obj[histonr][0]->Draw("hist same"); // us MC (b + c + jpsi + Y + BH + bg_estim.)

	//      cout<<"After plotting green "<<strbuffer<<endl;

	hm_us_bMC[plotss]->SetLineWidth(2);
	hm_us_bMC[plotss]->SetFillColor(6);
	hm_us_bMC[plotss]->SetFillStyle(3001);
	if(rebinvalue > 0) hm_us_bMC[plotss]->Rebin(rebinvalue);
	hm_us_bMC[plotss]->Draw("hist same"); // us MC (b only)

	//      cout<<"After plotting magenta "<<strbuffer<<endl;


	lfl_bg_us[plotss]->SetFillColor(4); // Following comment is nonsens, outdated: ploting data on 2*bg = ls_bg + us_bg (as we also plot us_data + ls_data)
	lfl_bg_us[plotss]->SetFillStyle(3001);
	if(rebinvalue > 0)  lfl_bg_us[plotss]->Rebin(rebinvalue); // moved to rebinposition of nhistos above 050324
	lfl_bg_us[plotss]->Draw("hist same"); // lfl bg estimate only


	obj[histonr][charmbegin]->SetFillColor(2);
	obj[histonr][charmbegin]->SetFillStyle(3001);
	if(rebinvalue > 0){
	  obj[histonr][charmbegin]->Rebin(rebinvalue);
	  //	obj[histonr+nhistos][charmbegin]->Rebin(rebinvalue);
	}
	obj[histonr][charmbegin]->Draw("hist same"); // us c-MC (c only!)

	obj[histonr][BH_position1]->SetFillColor(5);
	obj[histonr][BH_position1]->SetFillStyle(3001);
	if(rebinvalue > 0){
	  obj[histonr][BH_position1]->Rebin(rebinvalue);
	  //	obj[histonr+nhistos][BH_position]->Rebin(rebinvalue);
	}
	obj[histonr][BH_position1]->Draw("hist same"); // BH-MC (BH only to see contrib.)

	obj[histonr][jpsi_position2]->SetFillColor(38);
	obj[histonr][jpsi_position2]->SetFillStyle(3001);
	if(rebinvalue > 0){
	  obj[histonr][jpsi_position2]->Rebin(rebinvalue);
	  //	obj[histonr+nhistos][jpsi_position]->Rebin(rebinvalue);
	}
	obj[histonr][jpsi_position2]->Draw("hist same"); // jpsi-MC (jpsi only to see contrib.)

	obj[histonr][dataposition]->Draw("E P same");    // us data draw again, to be there as top layer

	if((plot_dists_std || plot_dists_kum) && plot_ls) {
	  cc->cd(1);
	  hm_ls_data[plotss]->SetMarkerStyle(8);
	  if(bigmarker) hm_ls_data[plotss]->SetMarkerSize(2.);
	  if(rebinvalue>0) hm_ls_data[plotss]->Rebin(rebinvalue);
	  hm_ls_data[plotss]->Draw("hist E P");

	  if(rebinvalue>0) {
	    obj[histonr+nhistos][0]->Rebin(rebinvalue);
	    obj[histonr+nhistos][dataposition]->Rebin(rebinvalue);
	  }

	  //	  TH1D* hm_ls_bMC_lfl[plotss] = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC_lfl");
	  hm_ls_bMC_lfl[plotss] = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC_lfl");
	  hm_ls_bMC_lfl[plotss]->Add(obj[histonr+nhistos][dataposition], 1);
	  hm_ls_bMC_lfl[plotss]->SetFillColor(3);
	  hm_ls_bMC_lfl[plotss]->SetFillStyle(3001);
	  hm_ls_bMC_lfl[plotss]->Draw("hist same"); // ls b MC + lfl bg es.
	  obj[histonr+nhistos][dataposition]->SetFillStyle(3001);
	  obj[histonr+nhistos][dataposition]->SetFillColor(4);
	  obj[histonr+nhistos][dataposition]->Draw("hist same"); // lfl bg estimate only
	  obj[histonr+nhistos][0]->SetLineWidth(2);
	  obj[histonr+nhistos][0]->SetFillColor(6);
	  obj[histonr+nhistos][0]->SetFillStyle(3001);
	  obj[histonr+nhistos][0]->Draw("hist same"); // ls hm MC
	}
      }
      else if(plot_dists_kum){
	// some plotting...
	//	if(MC_first) obj[histonr][0]->Draw("hist");   //draw MC description first to set the scale

	obj[histonr][dataposition]->SetMarkerStyle(8);
	if(bigmarker) obj[histonr][dataposition]->SetMarkerSize(2.);
	if(rebinvalue > 0) {
	  obj[histonr][dataposition]->Rebin(rebinvalue);
	  //	lfl_bg_us[plotss]->Rebin(rebinvalue);
	}
	//	if (MC_first)  obj[histonr][dataposition]->Draw("E P same");    // us data
	//	else
	obj[histonr][dataposition]->Draw("E P");    // us data
	histoname=obj[histonr][dataposition]->GetName();
	histoname.Append("_data");
 	if(!plot_hm) gInclude->DumpHisto((TH1D*)obj[histonr][dataposition]->Clone(histoname),histoname);
 	else gInclude->DumpHisto((TH1D*)obj[histonr][dataposition]->Clone(histoname),histoname);

	//	obj[histonr][0]->SetFillColor(6);
	obj[histonr][0]->SetFillColor(2);
	obj[histonr][0]->SetFillStyle(3001);
	//obj[histonr][0]->SetFillStyle(3013);
	if(rebinvalue > 0) {
	  obj[histonr][0]->Rebin(rebinvalue);
	  //	obj[histonr+nhistos][0]->Rebin(rebinvalue);
	}
	obj[histonr][0]->Draw("hist same"); // total sum is shown rear red - is the kum beauty. old: us MC (b + c + jpsi + Y + BH + bg_estim.)
	histoname=obj[histonr][dataposition]->GetName();
	histoname.Append("_allMC_sum");
 	if(!plot_hm) gInclude->DumpHisto((TH1D*)obj[histonr][0]->Clone(histoname),histoname);
 	else gInclude->DumpHisto((TH1D*)obj[histonr][0]->Clone(histoname),histoname);

	//      cout<<"After plotting magenta "<<strbuffer<<endl;

// 	hm_us_bMC[plotss]->SetLineWidth(2);
// 	hm_us_bMC[plotss]->SetFillColor(6);
// 	hm_us_bMC[plotss]->SetFillStyle(3001);
// 	if(rebinvalue > 0) hm_us_bMC[plotss]->Rebin(rebinvalue);
// 	hm_us_bMC[plotss]->Draw("hist same"); // us MC (b only)

// 	//      cout<<"After plotting magenta "<<strbuffer<<endl;

// 	obj[histonr][charmbegin]->SetFillColor(2);
// 	obj[histonr][charmbegin]->SetFillStyle(3001);
// 	if(rebinvalue > 0){
// 	  obj[histonr][charmbegin]->Rebin(rebinvalue);
// 	  //	obj[histonr+nhistos][charmbegin]->Rebin(rebinvalue);
// 	}
// 	obj[histonr][charmbegin]->Draw("hist same"); // us c-MC (c only to see contrib.)


        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] = (TH1D*)obj[histonr][BH_position1]->Clone("BH_p_jpsi_p_Charm_MC_p_lfl_bg");
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][BH_position2],1);       // add BH
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][BH_position3],1);       // add BH
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][jpsi_position1],1);     // add jpsi
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][jpsi_position2],1);     // add jpsi
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][psiprime_position1],1); // add psiprime
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][psiprime_position2],1); // add psiprime
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][ups1_position],1);      // add Y 1s
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][ups2_position],1);      // add Y 2s
        BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][ups3_position],1);      // add Y 3s
	BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(obj[histonr][charmbegin],1);         // add charm
	BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> Add(lfl_bg_us[plotss],1); // add lfl bg
 	BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> SetFillColor(5);
	BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss] -> SetFillStyle(3001);

	// 	BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss]->SetFillStyle(3013);

 	if(rebinvalue > 0)
	  {
	    BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss]->Rebin(rebinvalue);
	  }
 	BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss]->Draw("hist same"); // BH+jpsi+psiprime+charm+lflbg - MC
	histoname=obj[histonr][dataposition]->GetName();
	histoname.Append("_allMC_m_charm_sum");

 	if(!plot_hm) gInclude->DumpHisto((TH1D*)BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss]->Clone(histoname),histoname);
 	else         gInclude->DumpHisto((TH1D*)BH_p_jpsi_p_Charm_MC_p_lfl_bg[plotss]->Clone(histoname),histoname);

// Where did these 4 below come from?!?!?!? 050412
// obj[histonr][jpsi_position]->Draw("hist same");
// obj[histonr][psiprime_position]->Draw("hist same");
// obj[histonr][charmbegin]->Draw("hist same");
// obj[histonr][BH_position]->Draw("hist same");

// 	jpsi_p_Charm_MC_p_lfl_bg[plotss] = (TH1D*)obj[histonr][jpsi_position]->Clone("jpsi_p_Charm_MC_p_lfl_bg");
// 	jpsi_p_Charm_MC_p_lfl_bg[plotss]->Add(obj[histonr][charmbegin],1); // add charm
// 	jpsi_p_Charm_MC_p_lfl_bg[plotss]->Add(lfl_bg_us[plotss],1); // add lfl bg
// 	// 	jpsi_p_Charm_MC_p_lfl_bg[plotss]->SetFillColor(38);
//  	jpsi_p_Charm_MC_p_lfl_bg[plotss]->SetFillColor(5);
//  	jpsi_p_Charm_MC_p_lfl_bg[plotss]->SetFillStyle(3001);
//  	if(rebinvalue > 0){
//  	  jpsi_p_Charm_MC_p_lfl_bg[plotss]->Rebin(rebinvalue);
//  	  //	obj[histonr+nhistos][jpsi_position]->Rebin(rebinvalue);
//  	}
//  	jpsi_p_Charm_MC_p_lfl_bg[plotss]->Draw("hist same"); // jpsi-MC +below stuff

	if(42 == 42)
	  {
	    Charm_MC_p_lfl_bg[plotss] = (TH1D*)obj[histonr][charmbegin]->Clone("Charm_MC_p_lfl_bg");
            Charm_MC_p_lfl_bg[plotss]->Add(lfl_bg_us[plotss],1); // add lfl bg to charm
	  //	Charm_MC_p_lfl_bg[plotss]->SetFillColor(2);
	    Charm_MC_p_lfl_bg[plotss]->SetFillColor(3);
	    Charm_MC_p_lfl_bg[plotss]->SetFillStyle(3001);
	  //	Charm_MC_p_lfl_bg[plotss]->SetFillStyle(3013);

	    if(rebinvalue > 0)
	      {
		Charm_MC_p_lfl_bg[plotss]->Rebin(rebinvalue);
	      }

	  Charm_MC_p_lfl_bg[plotss]->Draw("hist same"); // green us c-MC + lfl bg (behind blue lfl bg)
	  histoname=obj[histonr][dataposition]->GetName();
	  histoname.Append("_MC_c_p_lflbg_sum");

 	  if(!plot_hm) gInclude->DumpHisto((TH1D*)Charm_MC_p_lfl_bg[plotss]->Clone(histoname),histoname);
 	  else         gInclude->DumpHisto((TH1D*)Charm_MC_p_lfl_bg[plotss]->Clone(histoname),histoname);
	}

	lfl_bg_us[plotss]->SetFillColor(4);
	lfl_bg_us[plotss]->SetFillStyle(3001);

	if(rebinvalue > 0)  lfl_bg_us[plotss]->Rebin(rebinvalue);
	lfl_bg_us[plotss]->Draw("hist same"); // lfl bg estimate is drawn last - ok050407
	histoname=obj[histonr][dataposition]->GetName();
	histoname.Append("_MC_lflbg_sum");

 	if(!plot_hm) gInclude->DumpHisto((TH1D*)lfl_bg_us[plotss]->Clone(histoname),histoname);
 	else         gInclude->DumpHisto((TH1D*)lfl_bg_us[plotss]->Clone(histoname),histoname);

 	obj[histonr][dataposition]->Draw("E P same");    // us data draw again, to be there as top layer


	if((plot_dists_std || plot_dists_kum) && plot_ls) {
	  cc->cd(1);
	  hm_ls_data[plotss]->SetMarkerStyle(8);
	  if(bigmarker) hm_ls_data[plotss]->SetMarkerSize(2.);
	  if(rebinvalue>0) hm_ls_data[plotss]->Rebin(rebinvalue);
	  hm_ls_data[plotss]->Draw("hist E P");

	  histoname=obj[histonr+nhistos][dataposition]->GetName();
	  histoname.Append("_data");
 	  if(!plot_hm) gInclude->DumpHisto((TH1D*)hm_ls_data[plotss]->Clone(histoname),histoname);
 	  else gInclude->DumpHisto((TH1D*)hm_ls_data[plotss]->Clone(histoname),histoname);

	  if(rebinvalue>0)
	    {
	      obj[histonr+nhistos][0]->Rebin(rebinvalue);
	      obj[histonr+nhistos][dataposition]->Rebin(rebinvalue);
	    }

	  hm_ls_bMC_lfl[plotss] = (TH1D*) obj[histonr+nhistos][0]->Clone("hm_ls_bMC_lfl");
	  hm_ls_bMC_lfl[plotss] -> Add(obj[histonr+nhistos][dataposition], 1);

	  hm_ls_bMC_lfl[plotss] -> SetFillColor(2);
	  hm_ls_bMC_lfl[plotss] -> SetFillStyle(3001);
	  hm_ls_bMC_lfl[plotss] -> Draw("hist same"); // ls b MC + lfl bg es.

	  histoname=obj[histonr+nhistos][dataposition]->GetName();
	  histoname.Append("_allMC_sum");
 	  if(!plot_hm) gInclude->DumpHisto((TH1D*)hm_ls_bMC_lfl[plotss]->Clone(histoname),histoname);
 	  else gInclude->DumpHisto((TH1D*)hm_ls_bMC_lfl[plotss]->Clone(histoname),histoname);

	  obj[histonr+nhistos][dataposition]->SetFillStyle(3001);
	  obj[histonr+nhistos][dataposition]->SetFillColor(4);
	  obj[histonr+nhistos][dataposition]->Draw("hist same"); // lfl bg estimate only

	  histoname=obj[histonr+nhistos][dataposition]->GetName();
	  histoname.Append("_MC_lflbg_sum");
 	  if(!plot_hm) gInclude->DumpHisto((TH1D*)obj[histonr+nhistos][dataposition]->Clone(histoname),histoname);
 	  else         gInclude->DumpHisto((TH1D*)obj[histonr+nhistos][dataposition]->Clone(histoname),histoname);

// Data again on top
	  hm_ls_data[plotss]->Draw("hist E P same");

// 	  obj[histonr+nhistos][0]->SetLineWidth(2);
// 	  obj[histonr+nhistos][0]->SetFillColor(6);
// 	  obj[histonr+nhistos][0]->SetFillStyle(3001);
// 	  obj[histonr+nhistos][0]->Draw("hist same"); // ls hm MC
	}
      }

      if(calc_b_frac && !plot_ls){
	// *********************************************************************************************;
	// plot beauty fraction in separate histo start:;
	// *********************************************************************************************;
	// rebin unrebinned histos first:;
	if(rebinvalue>0 && !(plot_dists_std || plot_dists_kum)){
	  obj[histonr][dataposition]->Rebin(rebinvalue);
	  obj[histonr][0]->Rebin(rebinvalue);
	  hm_us_bMC[plotss]->Rebin(rebinvalue);
	  hm_ls_bMC[plotss]->Rebin(rebinvalue);
	  lfl_bg_us[plotss]->Rebin(rebinvalue);
	  obj[histonr][charmbegin]->Rebin(rebinvalue);
	  obj[histonr][BH_position1]->Rebin(rebinvalue);
	  obj[histonr][BH_position2]->Rebin(rebinvalue);
	  obj[histonr][BH_position3]->Rebin(rebinvalue);
	  obj[histonr][jpsi_position1]->Rebin(rebinvalue);
	  obj[histonr][jpsi_position2]->Rebin(rebinvalue);
	  obj[histonr][ups1_position]->Rebin(rebinvalue);
	  obj[histonr][ups2_position]->Rebin(rebinvalue);
	  obj[histonr][ups3_position]->Rebin(rebinvalue);
	  hm_ls_data[plotss]->Rebin(rebinvalue);
	  obj[histonr+nhistos][0]->Rebin(rebinvalue);
	}
	//	if(rebinvalue>0) hm_ls_data[plotss]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][jpsi_position1]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][jpsi_position2]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr][psiprime_position1]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr][psiprime_position2]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][psiprime_position1]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][psiprime_position2]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][BH_position1]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][BH_position2]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][BH_position3]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][ups1_position]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][ups2_position]->Rebin(rebinvalue);
	if(rebinvalue>0) obj[histonr+nhistos][ups3_position]->Rebin(rebinvalue);
	if(rebinvalue>0) hm_us_bMC_buffer[plotss]->Rebin(rebinvalue);
	if(rebinvalue>0) hm_ls_bMC_buffer[plotss]->Rebin(rebinvalue);

	  // fill     unlike data:
 	cout<<"1 bins at sub data: "<<obj[histonr][dataposition]->GetNbinsX()<<endl;
 	cout<<"1 name at sub data: "<<obj[histonr][dataposition]->GetName()<<endl;
	cout<<" unlike data has entries: "<<obj[histonr][dataposition]->Integral()<<endl;
// 	TH1D* b_frac[plotss]   = (TH1D*) obj[histonr][dataposition]->Clone("b_frac");
	b_frac[plotss]   = (TH1D*) obj[histonr][dataposition]->Clone("b_frac");
	// Subtr.      unlike open charm  (subtraction of like has been done above):
 	cout<<"2 bins at sub data: "<<obj[histonr][charmbegin]->GetNbinsX()<<endl;
 	cout<<"2 name at sub data: "<<obj[histonr][charmbegin]->GetName()<<endl;
	cout<<" unlike charm has entries: "<<obj[histonr][charmbegin]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][charmbegin],-1.);
	// subtr.   unlike jpsi:  (subtraction of like has been done above):
 	cout<<"3.1 bins at sub data: "<<obj[histonr][jpsi_position1]->GetNbinsX()<<endl;
 	cout<<"3.1 name at sub data: "<<obj[histonr][jpsi_position1]->GetName()<<endl;
	cout<<" unlike jpsi1 has entries: "<<obj[histonr][jpsi_position1]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][jpsi_position1],-1.);
	cout<<"3.2 bins at sub data: "<<obj[histonr][jpsi_position2]->GetNbinsX()<<endl;
 	cout<<"3.2 name at sub data: "<<obj[histonr][jpsi_position2]->GetName()<<endl;
	cout<<" unlike jpsi2 has entries: "<<obj[histonr][jpsi_position2]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][jpsi_position2],-1.);
	// subtr.   unlike psiprime:  (subtraction of like has been done above):
 	cout<<"4.1 bins at sub data: "<<obj[histonr][psiprime_position1]->GetNbinsX()<<endl;
 	cout<<"4.1 name at sub data: "<<obj[histonr][psiprime_position1]->GetName()<<endl;
	cout<<" unlike psiprime1 has entries: "<<obj[histonr][psiprime_position1]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][psiprime_position1],-1.);
	cout<<"4.2 bins at sub data: "<<obj[histonr][psiprime_position2]->GetNbinsX()<<endl;
 	cout<<"4.2 name at sub data: "<<obj[histonr][psiprime_position2]->GetName()<<endl;
	cout<<" unlike psiprime2 has entries: "<<obj[histonr][psiprime_position2]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][psiprime_position2],-1.);
	// subtr.   unlike bh:   (subtraction of like has been done above):
 	cout<<"5.1 bins at sub data: "<<obj[histonr][BH_position1]->GetNbinsX()<<endl;
 	cout<<"5.1 name at sub data: "<<obj[histonr][BH_position1]->GetName()<<endl;
	cout<<" unlike bh1 has entries: "<<obj[histonr][BH_position1]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][BH_position1],-1.);
	cout<<"5.2 bins at sub data: "<<obj[histonr][BH_position2]->GetNbinsX()<<endl;
 	cout<<"5.2 name at sub data: "<<obj[histonr][BH_position2]->GetName()<<endl;
	cout<<" unlike bh2 has entries: "<<obj[histonr][BH_position2]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][BH_position2],-1.);
	cout<<"5.3 bins at sub data: "<<obj[histonr][BH_position3]->GetNbinsX()<<endl;
 	cout<<"5.3 name at sub data: "<<obj[histonr][BH_position3]->GetName()<<endl;
	cout<<" unlike bh3 has entries: "<<obj[histonr][BH_position3]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][BH_position3],-1.);
	// subtr.   unlike Upsilon:   (subtraction of like has been done above):
 	cout<<"6.1 bins at sub data: "<<obj[histonr][ups1_position]->GetNbinsX()<<endl;
 	cout<<"6.1 name at sub data: "<<obj[histonr][ups1_position]->GetName()<<endl;
	cout<<" unlike Y1 has entries: "<<obj[histonr][ups1_position]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][ups1_position],-1.);
	cout<<"6.2 bins at sub data: "<<obj[histonr][ups2_position]->GetNbinsX()<<endl;
 	cout<<"6.2 name at sub data: "<<obj[histonr][ups2_position]->GetName()<<endl;
	cout<<" unlike Y2 has entries: "<<obj[histonr][ups2_position]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][ups2_position],-1.);
	cout<<"6.3 bins at sub data: "<<obj[histonr][ups3_position]->GetNbinsX()<<endl;
 	cout<<"6.3 name at sub data: "<<obj[histonr][ups3_position]->GetName()<<endl;
	cout<<" unlike Y3 has entries: "<<obj[histonr][ups3_position]->Integral()<<endl;
	b_frac[plotss]->Add(obj[histonr][ups3_position],-1.);

// subtract like   data:
// 	cout<<"2 bins at sub data: "<<hm_ls_data[plotss]->GetNbinsX()<<endl;
// 	cout<<"2 name at sub data: "<<hm_ls_data[plotss]->GetName()<<endl;
 	cout<<"7 bins at sub data: "<<hm_ls_data[plotss]->GetNbinsX()<<endl;
 	cout<<"7 name at sub data: "<<hm_ls_data[plotss]->GetName()<<endl;
	cout<<" likesign data has entries: "<<hm_ls_data[plotss]->Integral()<<endl;
	//	b_frac[plotss]->Add(hm_ls_data[plotss],-1.*us_bg_corr);
	b_frac[plotss]->Add(hm_ls_data[plotss],-1.*us_bg_corr);

	cout<<" (u-a*l)data has entries: "<<b_frac[plotss]->Integral()<<" with a= "<<us_bg_corr<<endl;

	// dump hm or lm:
	if(!plot_hm){
	  b_frac[plotss]->ls();
	  histoname = "uData_m_bg_m_lData_lm_";
	  histoname+=plotss;
	  gInclude->DumpHisto((TH1D*)b_frac[plotss]->Clone("uData_m_bg_m_lData_lm"),histoname);
	}
	else if(plot_hm){
	  b_frac[plotss]->ls();
	  histoname = "uData_m_bg_m_lData_hm_";
	  histoname+=plotss;
	  gInclude->DumpHisto((TH1D*)b_frac[plotss]->Clone("uData_m_bg_m_lData_hm"),histoname);
	}

	// make b(u+l) histo:
	// 	TH1D* bMC_u_plus_l[plotss] = (TH1D*) hm_us_bMC_buffer[plotss]->Clone("bMC_u_plus_l");
	bMC_u_plus_l[plotss] = (TH1D*) hm_us_bMC_buffer[plotss]->Clone("bMC_u_plus_l");
 	cout<<"8 bins at sub data: "<<hm_us_bMC_buffer[plotss]->GetNbinsX()<<endl;
 	cout<<"8 name at sub data: "<<hm_us_bMC_buffer[plotss]->GetName()<<endl;
 	cout<<"9 bins at sub data: "<<hm_ls_bMC_buffer[plotss]->GetNbinsX()<<endl;
 	cout<<"9 name at sub data: "<<hm_ls_bMC_buffer[plotss]->GetName()<<endl;
	bMC_u_plus_l[plotss]->Add(hm_ls_bMC_buffer[plotss],1.);
	cout<<" b(u+l) has entries: "<<bMC_u_plus_l[plotss]->Integral()<<" = "<<hm_us_bMC_buffer[plotss]->Integral()<<" + "<<hm_ls_bMC_buffer[plotss]->Integral()<<endl;
	// dump hm or lm:
	if(!plot_hm){
	  bMC_u_plus_l[plotss]->ls();
	  histoname = "uMC_p_lMC_lm_";
	  histoname+=plotss;
	  gInclude->DumpHisto((TH1D*)bMC_u_plus_l[plotss]->Clone("uMC_p_lMC_lm"),histoname);
	}
	else if(plot_hm){
	  bMC_u_plus_l[plotss]->ls();
	  histoname = "uMC_p_lMC_hm_";
	  histoname+=plotss;
	  gInclude->DumpHisto((TH1D*)bMC_u_plus_l[plotss]->Clone("uMC_p_lMC_hm"),histoname);
	}

	// make b(u-l) histo (corrected by like over unlike bg ratio):
	// 	TH1D* bMC_u_minus_l[plotss] = (TH1D*) hm_us_bMC_buffer[plotss]->Clone("bMC_u_minus_l");
	bMC_u_minus_l[plotss] = (TH1D*) hm_us_bMC_buffer[plotss]->Clone("bMC_u_minus_l");
 	cout<<"10 bins at sub data: "<<bMC_u_minus_l[plotss]->GetNbinsX()<<endl;
 	cout<<"10 name at sub data: "<<bMC_u_minus_l[plotss]->GetName()<<endl;
	// 	getchar();
	bMC_u_minus_l[plotss]->Add(hm_ls_bMC_buffer[plotss],-1.*us_bg_corr);
	cout<<" b(u-l) has entries: "<<bMC_u_minus_l[plotss]->Integral()<<" = "<<hm_us_bMC_buffer[plotss]->Integral()<<" - "<<hm_ls_bMC_buffer[plotss]->Integral()<<" * "<<us_bg_corr<<endl;

	// dump hm or lm:
	if(!plot_hm){
	  bMC_u_minus_l[plotss]->ls();
	  histoname = "uMC_m_lMC_lm_";
	  histoname+=plotss;
	  gInclude->DumpHisto((TH1D*)bMC_u_minus_l[plotss]->Clone("uMC_m_lMC_lm"),histoname);
	}
	else if(plot_hm){
	  bMC_u_minus_l[plotss]->ls();
	  histoname = "uMC_m_lMC_hm_";
	  histoname+=plotss;
	  gInclude->DumpHisto((TH1D*)bMC_u_minus_l[plotss]->Clone("uMC_m_lMC_hm"),histoname);
	}

	// from here on only as "hm" or "lm" xsec - just a cross check.
	// divide b(u+l)/b(u-corr*l):
	bMC_u_plus_l[plotss]->Divide(bMC_u_minus_l[plotss]);
	// rebin properly NOT HERE!!! was bug!! moved to above!:
	//	if(rebinvalue>0) bMC_u_plus_l[plotss]->Rebin(rebinvalue);
	// multiply result of division to b_frac histo:
	b_frac[plotss]->Multiply(bMC_u_plus_l[plotss]);
	//	getchar();
	cccc = new TCanvas();
	b_frac[plotss]->GetYaxis()->SetTitle("Number of b #rightarrow #mu events");
	b_frac[plotss]->SetFillColor(3);
	b_frac[plotss]->SetMarkerColor(6);
	b_frac[plotss]->SetMarkerStyle(8);
	if(bigmarker) b_frac[plotss]->SetMarkerSize(2.);
	//      if(rebinvalue>0) b_frac[plotss]->Rebin(rebinvalue*4);
	//      b_frac[plotss]->Draw("hist");
	b_frac[plotss]->Draw();
	Double_t intbuffer = b_frac[plotss]->Integral();
	Double_t errbuffer = b_frac[plotss]->GetBinError(1);
	cout<<"****************************"<<endl<<"Integral of the b_fraction plot: "<<intbuffer<<endl<<"****************************"<<endl;
	if(42 == 42){
	  // Now determine acceptance and calculate: xsec = b_frac/(acc*data_lumi)
	  // with acc = MC_rec/MC_true = (obj[54][0]+obj[60][0]+obj[66][0]+obj[72][0])/obj[2][0]
	  // explain [x][y]: y= beauty MC sum, x=histo position.
	  // xkey (on files in ~/lap_GUTANADIR/050411_2_xsecs_1sttry_all_iblhistos_usedforxesc_donttouch)
	  // 2  = h_mcdimumass1bin_true_hfl_mu_all
	  // 54 = h_etex2ir_lm_us_nis
	  // 60 = h_etex2ir_lm_ls_nis
	  // 66 = h_etex2ir_hm_us_nis
	  // 72 = h_etex2ir_hm_ls_nis
	  // 	TH1D* b_acc[plotss]   = (TH1D*) obj[54][0]->Clone("b_acc");
	  // 	b_acc[plotss]->Add(    obj[60][0],1); WROOONGG!!! at 0 we have the TOTAL MC SUM!!! IDIOT!! 050418
	  // 	b_acc[plotss]->Add(    obj[66][0],1);
	  // 	b_acc[plotss]->Add(    obj[72][0],1);
	  if(!plot_hm){
	    // Add like and unlike sign non-isolated histos
	    // key for the numbers given above - here we add:
	    // 54 (lm us) + 60 (lm ls) at position [0] (sum of all lumi
	    // weighted b MCs)
	    b_acc[plotss]   = (TH1D*) hm_us_bMC_buffer[plotss]->Clone("b_acc");
	    b_acc[plotss]->Add(  hm_ls_bMC_buffer[plotss]  ,1);
// 	    b_acc[plotss]   = (TH1D*) obj[54][0]->Clone("b_acc");
// 	    b_acc[plotss]->Add(    obj[60][0],1);
	  }
	  else if(plot_hm){
	    // Add like and unlike sign non-isolated histos
	    // key for the numbers given above - here we add:
	    // 66 (hm us) + 72 (hm ls) at position [0] (sum of all lumi
	    // weighted b MCs)
	    b_acc[plotss]   = (TH1D*) hm_us_bMC_buffer[plotss]->Clone("b_acc");
	    b_acc[plotss]->Add(  hm_ls_bMC_buffer[plotss]  ,1);
// 	    b_acc[plotss]   = (TH1D*) obj[66][0]->Clone("b_acc");
// 	    b_acc[plotss]->Add(    obj[72][0],1);
	  }
	  if(!plot_hm){
	    cout<<"HAAALOOOO!!!  Entries: "<<hm_us_bMC_buffer[plotss]->GetEntries()<<" Integral: "<<hm_us_bMC_buffer[plotss]->Integral()<<endl;
	    cout<<"HAAALOOOO!!!  Entries: "<<hm_ls_bMC_buffer[plotss]->GetEntries()<<" Integral: "<<hm_ls_bMC_buffer[plotss]->Integral()<<endl;
	    cout<<"HAAALOOOO!!!  Entries: "<<orig_true[plotss]->GetEntries()<<" Integral: "<<orig_true[plotss]->Integral()<<endl;
	  }
	  else{
	    cout<<"HAAALOOOO!!!  Entries: "<<hm_us_bMC_buffer[plotss]->GetEntries()<<" Integral: "<<hm_us_bMC_buffer[plotss]->Integral()<<endl;
	    cout<<"HAAALOOOO!!!  Entries: "<<hm_ls_bMC_buffer[plotss]->GetEntries()<<" Integral: "<<hm_ls_bMC_buffer[plotss]->Integral()<<endl;
	    cout<<"HAAALOOOO!!!  Entries: "<<orig_true[plotss]->GetEntries()<<" Integral: "<<orig_true[plotss]->Integral()<<endl;
	  }
	  ccccx4 = new TCanvas();
	  // 	TH1D* b_MCrec[plotss] =	(TH1D*) b_acc[plotss]->Clone("b_MCrec");
	  b_MCrec[plotss] =	(TH1D*) b_acc[plotss]->Clone("b_MCrec");
	  b_MCrec[plotss]->SetLineColor(4);
	  b_MCrec[plotss]->SetLineWidth(4);
	  b_MCrec[plotss]->Draw();

	  b_acc[plotss]->Divide( orig_true[plotss]   );

	  cout<<"acceptance has value of: "<<b_acc[plotss]->Integral()<<endl;

	  ccccx2 = new TCanvas();
	  //	orig_true[plotss]->Draw();
	  b_acc[plotss]->SetLineColor(3);
	  b_acc[plotss]->Draw();

	  // 	TH1D* b_xsec[plotss] = (TH1D*) b_frac[plotss]->Clone("b_xsec");
	  b_xsec[plotss] = (TH1D*) b_frac[plotss]->Clone("b_xsec");
	  b_xsec[plotss]->Divide(b_acc[plotss]);
	  b_xsec[plotss]->Scale(1./data_lumi);
	  // done. Now draw it. *zitter*
	  ccccx = new TCanvas();
	  b_xsec[plotss]->GetYaxis()->SetTitle("visible crossection [pb]");
	  b_xsec[plotss]->GetYaxis()->SetRangeUser(0,b_xsec[plotss]->GetMaximum()*1.3);
	  b_xsec[plotss]->SetFillColor(2);
	  b_xsec[plotss]->SetMarkerStyle(8);
	  if(bigmarker) b_xsec[plotss]->SetMarkerSize(2.);
	  //      if(rebinvalue>0) b_xsec[plotss]->Rebin(rebinvalue*4);
	  //      b_xsec[plotss]->Draw("hist");
	  b_xsec[plotss]->Draw();
	  intbuffer = b_xsec[plotss]->Integral();
	  errbuffer = b_xsec[plotss]->GetBinError(1);
	  cout<<"****************************"<<endl<<"Integral of the b cross section plot: "<<intbuffer<<endl<<"**************************** plotss: "<<plotss<<endl;
	  cout<<"****************************"<<endl<<"Error    of the b cross section plot: "<<errbuffer<<endl<<"**************************** plotss: "<<plotss<<endl;
	  //Dump Histos:
	  if(!plot_hm){
	    b_MCrec[plotss]->ls();
	    histoname = "recMC_lm_";
	    histoname+=plotss;
	    gInclude->DumpHisto((TH1D*)b_MCrec[plotss]->Clone("b_MCrec_lm"),histoname);
// 	    histoname = "recDATA_lm";
// 	    gInclude->DumpHisto((TH1D*)b_frac[plotss]->Clone("b_frac_lm"),histoname);
	    histoname = "true_lm_";
	    histoname+=plotss;
	    gInclude->DumpHisto(orig_true[plotss],histoname);
	  }
	  else if(plot_hm){
	    b_MCrec[plotss]->ls();
	    histoname = "recMC_hm_";
	    histoname+=plotss;
	    gInclude->DumpHisto((TH1D*)b_MCrec[plotss]->Clone("b_MCrec_hm"),histoname);
// 	    histoname = "recDATA_hm";
// 	    gInclude->DumpHisto((TH1D*)b_frac[plotss]->Clone("b_frac_hm"),histoname);
	    histoname = "true_hm_";
	    histoname+=plotss;
	    gInclude->DumpHisto(orig_true[plotss],histoname);
	  }
	  //	getchar();
	}
      }
      // *********************************************************************************************
      // plot beauty fraction in separate histo end.
      // *********************************************************************************************

    }
    if( 42 == 8 ){
      cccc = new TCanvas();
      xsec_buffer[plotss]->GetYaxis()->SetTitle("Visible cross section [pb]");
      xsec_buffer[plotss]->SetFillColor(3);
      xsec_buffer[plotss]->SetMarkerStyle(8);
      if(bigmarker) xsec_buffer[plotss]->SetMarkerSize(2.);
      if(rebinvalue>0) xsec_buffer[plotss]->Rebin(rebinvalue*4);
      //      xsec_buffer[plotss]->Draw("hist");
      xsec_buffer[plotss]->Draw();
    }
    if((plot_dists_std || plot_dists_kum) && print_single){
      printname = ".eps";
      printname.Insert(0, obj[histonr][dataposition]->GetName() );
      cc->Print(printname);
      printname = ".eps";
      printname = ".gif";
      printname.Insert(0, obj[histonr][dataposition]->GetName() );
      cc->Print(printname);
      printname = ".eps";
    }
    //       for(Int_t k=0; k<count1; k++){
    // 	display2->cd(0);
    // 	obj[k][0]->Draw();
    // 	display2->Modified();
    // 	display2->Update();
    // 	printname->Insert(0, obj[k][0]->GetName() );
    // 	display2->Print(printname);
    // 	if(k<count1-1)    display2->SaveAs("all_histos_in_one_etcut.ps(");
    // 	else   display2->SaveAs("all_histos_in_one_etcut.ps)");
    // 	printname = "_etcut.ps";
    //       }
    //     }
    //cc->Print();
    //  cout<<"plot_ls has value "<<plot_ls*1<<endl;

    if((plot_dists_std || plot_dists_kum) && plot_good && !lastplot) {
      cc->SaveAs("all_histos_in_one_etcut.ps(");
      //    cout<<"*** printed canvas with histo: "<< obj[histonr][dataposition]->GetName()<<endl;
    }
    else if((plot_dists_std || plot_dists_kum) && plot_good && lastplot){
      cc->SaveAs("all_histos_in_one_etcut.ps)");
      cout<<"*** printed last canvas with histo: "<< obj[histonr][dataposition]->GetName()<<endl;
    }
  } //plotting loop end<<<
  if( during_construction ) {
    //******* CONSTRUCTION WARNING!!!
      cout<<"*******************************************************************************************************"<<endl;
    cout<<"*** CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! ***"<<endl;
    cout<<"*** CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! CONSTRUCTION WARNING!!! ***"<<endl;
    cout<<"*******************************************************************************************************"<<endl;
  }
  if(dim_fl_exc != 1.0) {
    //******* FL EXC FUDGED -  WARNING!!!
      cout<<"***********************************************************************************************************************"<<endl;
    cout<<"*** FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! ***"<<endl;
    cout<<"*** FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! FL EXC FUDGED -  WARNING!!! ***"<<endl;
    cout<<"***********************************************************************************************************************"<<endl;
  }

  //smile!!
  cout<<"Nice?  "<<nhistos<<endl;
      if(autoquit)    gROOT->ProcessLine(".q");
  return 1;
}
//**********NEW********040210*********************************<<<   // add lumi-reweighted beauty histos to first beauty histo sample:

#!bin/sh
rm -r */mini_*
rm -r */test*

#!/bin/sh
cat ../log/latest.txt| grep error
cat ../log/latest.txt| grep ERROR
cat ../log/latest.txt| grep Error

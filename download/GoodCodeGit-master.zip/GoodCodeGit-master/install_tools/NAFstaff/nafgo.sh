#!/bin/sh
#qsub -l os=sld6 -q short.q -cwd /afs/desy.de/user/s/stefan/NAFruns/NAFstaff/nafsetups.sh $1 -cwd:
qsub -l os=sld6 -q short.q -cwd /nfs/dust/zeus/group/stefan/test2/GoodCodeGit/install_tools/NAFstaff/nafsetups.sh $1 -cwd:

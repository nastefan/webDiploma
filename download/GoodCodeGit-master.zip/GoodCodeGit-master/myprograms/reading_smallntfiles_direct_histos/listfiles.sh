#bin/sh/
# /// bb
infile[0] = "/data/zenith234d/stefan/GutCode/anadir/b/03p-04p/dir/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[1] = "/data/zenith234d/stefan/GutCode/anadir/b/03p-04p/res/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[2] = "/data/zenith234d/stefan/GutCode/anadir/b/03p-04p/resrap/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[3] = "/data/zenith234d/stefan/GutCode/anadir/b/03p-04p/dirrap/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[4] = "/data/zenith234d/stefan/GutCode/anadir/b/03p-04p/exgamma/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[5] = "/data/zenith234d/stefan/GutCode/anadir/b/03p-04p/exproton/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root

infile[6] = "/data/zenith234d/stefan/GutCode/anadir/b/05e/dir/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[7] = "/data/zenith234d/stefan/GutCode/anadir/b/05e/res/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[8] = "/data/zenith234d/stefan/GutCode/anadir/b/05e/resrap/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[9] = "/data/zenith234d/stefan/GutCode/anadir/b/05e/dirrap/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[10] = "/data/zenith234d/stefan/GutCode/anadir/b/05e/exgamma/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[11] = "/data/zenith234d/stefan/GutCode/anadir/b/05e/exproton/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root

infile[12] = "/data/zenith234d/stefan/GutCode/anadir/b/06e/dir/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[13] = "/data/zenith234d/stefan/GutCode/anadir/b/06e/res/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[14] = "/data/zenith234d/stefan/GutCode/anadir/b/06e/resrap/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[15] = "/data/zenith234d/stefan/GutCode/anadir/b/06e/dirrap/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[16] = "/data/zenith234d/stefan/GutCode/anadir/b/06e/exgamma/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[17] = "/data/zenith234d/stefan/GutCode/anadir/b/06e/exproton/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root

infile[18] = "/data/zenith234d/stefan/GutCode/anadir/b/06p-07p/dir/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[19] = "/data/zenith234d/stefan/GutCode/anadir/b/06p-07p/res/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[20] = "/data/zenith234d/stefan/GutCode/anadir/b/06p-07p/resrap/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[21] = "/data/zenith234d/stefan/GutCode/anadir/b/06p-07p/dirrap/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[22] = "/data/zenith234d/stefan/GutCode/anadir/b/06p-07p/exgamma/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[23] = "/data/zenith234d/stefan/GutCode/anadir/b/06p-07p/exproton/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root

# /// cc
infile[24] = "/data/zenith234d/stefan/GutCode/anadir/c/03p-04p/dir/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[25] = "/data/zenith234d/stefan/GutCode/anadir/c/03p-04p/res/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[25] = "/data/zenith234d/stefan/GutCode/anadir/c/03p-04p/resrap/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[27] = "/data/zenith234d/stefan/GutCode/anadir/c/03p-04p/dirrap/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[28] = "/data/zenith234d/stefan/GutCode/anadir/c/03p-04p/exgamma/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[29] = "/data/zenith234d/stefan/GutCode/anadir/c/03p-04p/exproton/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root

infile[30] = "/data/zenith234d/stefan/GutCode/anadir/c/05e/dir/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[31] = "/data/zenith234d/stefan/GutCode/anadir/c/05e/res/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[32] = "/data/zenith234d/stefan/GutCode/anadir/c/05e/resrap/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[33] = "/data/zenith234d/stefan/GutCode/anadir/c/05e/dirrap/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[34] = "/data/zenith234d/stefan/GutCode/anadir/c/05e/exgamma/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[35] = "/data/zenith234d/stefan/GutCode/anadir/c/05e/exproton/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root

infile[36] = "/data/zenith234d/stefan/GutCode/anadir/c/06e/dir/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[37] = "/data/zenith234d/stefan/GutCode/anadir/c/06e/res/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[38] = "/data/zenith234d/stefan/GutCode/anadir/c/06e/resrap/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[39] = "/data/zenith234d/stefan/GutCode/anadir/c/06e/dirrap/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[40] = "/data/zenith234d/stefan/GutCode/anadir/c/06e/exgamma/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[41] = "/data/zenith234d/stefan/GutCode/anadir/c/06e/exproton/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root

infile[42] = "/data/zenith234d/stefan/GutCode/anadir/c/06p-07p/dir/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[43] = "/data/zenith234d/stefan/GutCode/anadir/c/06p-07p/res/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[44] = "/data/zenith234d/stefan/GutCode/anadir/c/06p-07p/resrap/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[45] = "/data/zenith234d/stefan/GutCode/anadir/c/06p-07p/dirrap/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[46] = "/data/zenith234d/stefan/GutCode/anadir/c/06p-07p/exgamma/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[47] = "/data/zenith234d/stefan/GutCode/anadir/c/06p-07p/exproton/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root

# /// bh
infile[48] = "/data/zenith234d/stefan/GutCode/anadir/bh/03p-04p/DIS/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[49] = "/data/zenith234d/stefan/GutCode/anadir/bh/03p-04p/elastic/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[50] = "/data/zenith234d/stefan/GutCode/anadir/bh/03p-04p/inelastic/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root

infile[51] = "/data/zenith234d/stefan/GutCode/anadir/bh/05e/DIS/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[52] = "/data/zenith234d/stefan/GutCode/anadir/bh/05e/elastic/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[53] = "/data/zenith234d/stefan/GutCode/anadir/bh/05e/inelastic/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root

infile[54] = "/data/zenith234d/stefan/GutCode/anadir/bh/06e/DIS/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[55] = "/data/zenith234d/stefan/GutCode/anadir/bh/06e/elastic/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[56] = "/data/zenith234d/stefan/GutCode/anadir/bh/06e/inelastic/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root

infile[57] = "/data/zenith234d/stefan/GutCode/anadir/bh/06p-07p/DIS/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[58] = "/data/zenith234d/stefan/GutCode/anadir/bh/06p-07p/elastic/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[59] = "/data/zenith234d/stefan/GutCode/anadir/bh/06p-07p/inelastic/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root

# /// jpsi
infile[60] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/03p-04p/jpsi1/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[61] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/03p-04p/jpsi2/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[62] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/05e/jpsi1/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[63] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/05e/jpsi2/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[64] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/06e/jpsi1/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[65] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/06e/jpsi2/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[66] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/06p-07p/jpsi1/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[67] = "/data/zenith234d/stefan/GutCode/anadir/jpsi/06p-07p/jpsi2/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root

# /// psiprime
infile[68] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/03p-04p/all/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[69] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/03p-04p/psi2/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[70] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/05e/all/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[71] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/05e/psi2/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[72] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/06e/all/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[73] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/06e/psi2/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[74] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/06p-07p/all/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[75] = "/data/zenith234d/stefan/GutCode/anadir/psiprime/06p-07p/psi2/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root

# /// Upsilon
infile[76] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/03p-04p/1s_dir/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[77] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/03p-04p/2s_dir/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root
infile[78] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/03p-04p/3s_dir/mini_HeraII_0304p_Data_MC_Dimuon_Finalversion/histos.root

infile[79] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/05e/1s_dir/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[80] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/05e/2s_dir/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root
infile[81] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/05e/3s_dir/mini_HeraII_05e_Data_MC_Dimuon_Finalversion/histos.root

infile[82] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/06e/1s_dir/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[83] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/06e/2s_dir/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root
infile[84] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/06e/3s_dir/mini_HeraII_06e_Data_MC_Dimuon_Finalversion/histos.root

infile[85] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/06p-07p/1s_dir/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[86] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/06p-07p/2s_dir/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root
infile[87] = "/data/zenith234d/stefan/GutCode/anadir/upsilon/06p-07p/3s_dir/mini_HeraII_0607p_Data_MC_Dimuon_Finalversion/histos.root



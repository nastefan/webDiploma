// -*- C++ -*-
//
// Package:    DemoAnalyzer
// Class:      DemoAnalyzer
// 
/**\class DemoAnalyzer DemoAnalyzer.cc Demo/DemoAnalyzer/src/DemoAnalyzer.cc

 Description: [one line class summary]

 Implementation:
     [Notes on implementation]
*/


// 	Original Author: mkdeanlzr;   
//         Created by:  Stefaniuk Nazar



// system include files
#include <memory>

// user include files (standart after creation)
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "FWCore/Framework/interface/EDAnalyzer.h"
#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"
#include "FWCore/ParameterSet/interface/ParameterSet.h"
//
//
// New libs: 
// primary setup:
#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/EDAnalyzer.h"
#include "FWCore/ParameterSet/interface/ParameterSet.h"
#include "JetMETCorrections/Objects/interface/JetCorrector.h"
#include "CondFormats/JetMETObjects/interface/JetCorrectionUncertainty.h"
#include "FWCore/ServiceRegistry/interface/Service.h"
#include "CommonTools/UtilAlgos/interface/TFileService.h"

//
// gen level setup: 
#include "FWCore/Framework/interface/EventSetup.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "DataFormats/HepMCCandidate/interface/GenParticle.h"

#include "SimDataFormats/GeneratorProducts/interface/GenEventInfoProduct.h"
#include "SimDataFormats/PileupSummaryInfo/interface/PileupSummaryInfo.h"

#include "CondFormats/JetMETObjects/interface/JetCorrectorParameters.h"
#include "JetMETCorrections/Objects/interface/JetCorrectionsRecord.h"
//
//
//

class DemoAnalyzer : public edm::EDAnalyzer {
   public:
      explicit DemoAnalyzer(const edm::ParameterSet&);
      ~DemoAnalyzer();

      static void fillDescriptions(edm::ConfigurationDescriptions& descriptions);


   private:
      virtual void beginJob() ;
      virtual void analyze(const edm::Event&, const edm::EventSetup&);
      virtual void endJob() ;

      virtual void beginRun(edm::Run const&, edm::EventSetup const&);
      virtual void endRun(edm::Run const&, edm::EventSetup const&);
      virtual void beginLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&);
      virtual void endLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&);

      // ----------member data ---------------------------
      /// define folder object;
      edm::Service<TFileService> fs;
      
      /// create set of histograms;
      TH1D *histset[1000];
      
};

//
// constants, enums and typedefs
//

//
// static data member definitions
//

//
// constructors and destructor
//
DemoAnalyzer::DemoAnalyzer(const edm::ParameterSet& iConfig)

{

  
  
  TFileDirectory generalinfo       = fs->mkdir( "GeneralINFO" );
  TFileDirectory puInfo      	   = fs->mkdir( "PU_Info" );
  TFileDirectory genparticles      = fs->mkdir( "GenParticles" );
  
  histset[0] = generalinfo.make<TH1D>("Run number", "Run number", 3100, 146400, 149500);
  histset[1] = generalinfo.make<TH1D>("Event number", "Event number", 2000, 0, 2000000000);
  histset[2] = generalinfo.make<TH1D>("NGenParticles", "NGenParticles", 400, 0, 2000);


  histset[100] = puInfo.make<TH1D>("PU_Niter", "PU_Niter", 100, 0, 100);
  histset[300] = genparticles.make<TH1D>("PDG_IDs", "PDG_IDs", 1000, -500, 500);

  histset[351] = genparticles.make<TH1D>("gen_c_pt", "gen_c_pt", 200, 0, 100);
  histset[352] = genparticles.make<TH1D>("gen_cbar_pt", "gen_cbar_pt", 200, 0, 100);
  histset[353] = genparticles.make<TH1D>("gen_Dstar_plus_pt", "gen_Dstar_plus_pt", 200, 0, 100);
  histset[354] = genparticles.make<TH1D>("gen_Dstar_minus_pt", "gen_Dstar_minus_pt", 200, 0, 100);
  histset[355] = genparticles.make<TH1D>("gen_D0_plus_pt", "gen_D0_plus_pt", 200, 0, 100);
  histset[356] = genparticles.make<TH1D>("gen_D0_minus_pt", "gen_D0_minus_pt", 200, 0, 100);

  histset[400] = genparticles.make<TH1D>("gen_Dstar_pm_mass", "gen_Dstar_pm_mass", 200, 1.6, 2.2);
  histset[401] = genparticles.make<TH1D>("gen_charm_pm_mass", "gen_charm_pm_mass", 200, 0., 2.);
  histset[402] = genparticles.make<TH1D>("gen_D0_pm_mass", "gen_D0_pm_mass", 200, 0., 4.);

}


DemoAnalyzer::~DemoAnalyzer()
{
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}


//
// member functions
//

// ------------ method called for each event  ------------
void
DemoAnalyzer::analyze(const edm::Event& iEvent, const edm::EventSetup& iSetup)
{
   using namespace edm;
   using namespace reco;
   using namespace std;
	
   histset[0]->Fill(iEvent.run());
   histset[1]->Fill((iEvent.id()).event());

   /// *******************  GenParticles  ******************************   ///
   Handle<GenParticleCollection> genParticles;
   iEvent.getByLabel("genParticles", genParticles);
 	

   histset[2]->Fill(genParticles->size());

        for(size_t i = 0; i < genParticles->size(); ++ i)
        {
                const GenParticle & p = (*genParticles)[i];

                histset[300]->Fill(p.pdgId());

                // add Pt distributions
                if ( p.pdgId() == 4 )           { histset[351]->Fill(p.pt()); }
                if ( p.pdgId() == -4 )          { histset[352]->Fill(p.pt()); }
                if ( p.pdgId() == 413 )         { histset[353]->Fill(p.pt()); }
                if ( p.pdgId() == -413 )        { histset[354]->Fill(p.pt()); }
                if ( p.pdgId() == 421 )         { histset[355]->Fill(p.pt()); }
                if ( p.pdgId() == -421 )        { histset[356]->Fill(p.pt()); }

                // add mass distributions: 
                if ( abs(p.pdgId()) == 413)     { histset[400]->Fill(p.mass()); }
                if ( abs(p.pdgId()) == 4)       { histset[401]->Fill(p.mass()); }
                if ( abs(p.pdgId()) == 421)     { histset[402]->Fill(p.mass()); }

                // int id = p.pdgId();                            

                // get status of the particle decay: 
                // int st = p.status();
		
		/*
 		/// get particle mother: 
		const Candidate * mom = p.mother();

		/// parameters of the particle: 
		double pt = p.pt(), eta = p.eta(), phi = p.phi(), mass = p.mass();
		double vx = p.vx(), vy = p.vy(), vz = p.vz();
		
		//int charge = p.charge();
		
		// number of the dauther particles: 
                int n = p.numberOfDaughters();

		/// loop over all douther particles:
                for(Int_t j = 0; j < n; ++ j)
                {
                        const Candidate * d = p.daughter( j );
                	int dauId = d->pdgId();
			cout<<dauId<<endl;	

                }
		*/	
			
        }
		


}


// ------------ meth(d called once each job just before starting event loop  ------------
void 
DemoAnalyzer::beginJob()
{
}

// ------------ method called once each job just after ending the event loop  ------------
void 
DemoAnalyzer::endJob() 
{
}

// ------------ method called when starting to processes a run  ------------
void 
DemoAnalyzer::beginRun(edm::Run const&, edm::EventSetup const&)
{
}

// ------------ method called when ending the processing of a run  ------------
void 
DemoAnalyzer::endRun(edm::Run const&, edm::EventSetup const&)
{
}

// ------------ method called when starting to processes a luminosity block  ------------
void 
DemoAnalyzer::beginLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&)
{
}

// ------------ method called when ending the processing of a luminosity block  ------------
void 
DemoAnalyzer::endLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&)
{
}

// ------------ method fills 'descriptions' with the allowed parameters for the module  ------------
void
DemoAnalyzer::fillDescriptions(edm::ConfigurationDescriptions& descriptions) {
  //The following says we do not know what parameters are allowed so do no validation
  // Please change this to state exactly what you do use, even if it is no parameters
  edm::ParameterSetDescription desc;
  desc.setUnknown();
  descriptions.addDefault(desc);
}

//define this as a plug-in
DEFINE_FWK_MODULE(DemoAnalyzer);

import FWCore.ParameterSet.Config as cms
import FWCore.ParameterSet.Types as CfgTypes
import FWCore.Utilities.FileUtils as FileUtils

process = cms.Process("Demo")

# intialize MessageLogger and output report
process.load("FWCore.MessageLogger.MessageLogger_cfi")
process.MessageLogger.cerr.threshold = 'INFO'
process.MessageLogger.cerr.suppressWarning = cms.untracked.vstring('DemoAnalyzer')
process.MessageLogger.categories.append('Demo')
process.MessageLogger.cerr.FwkReport.reportEvery = 1000
process.load("SimGeneral.HepPDTESSource.pythiapdt_cfi")
  
process.options   = cms.untracked.PSet( wantSummary = cms.untracked.bool(True) )
                                        
# set the maximum number of events to be processed here
process.maxEvents = cms.untracked.PSet( input = cms.untracked.int32(1))

#files2011mc = FileUtils.loadListFromFile ('/home/cms-opendata/EXAMPLES/CMSSW_5_3_32/src/MC_data2011_QCD_Pt5_15.txt')
files2011mc = FileUtils.loadListFromFile ('/home/cms-opendata/EXAMPLES/CMSSW_5_3_32/src/MC_data2011_QCD_Pt50_80.txt')

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring(*files2011mc)
    #skipEvents=cms.untracked.uint32(1000)	
)

process.demo = cms.EDAnalyzer('DemoAnalyzer'
)

# change this output file name according to input file
process.TFileService = cms.Service("TFileService",
                                       fileName = cms.string('OutputMC.root')
                                   )


### List all decays with wide information
##process.load("SimGeneral.HepPDTESSource.pythiapdt_cfi")
process.printTree = cms.EDAnalyzer("ParticleListDrawer",
	maxEventsToPrint = cms.untracked.int32(1),
 	printVertex = cms.untracked.bool(False),
 	printOnlyHardInteraction = cms.untracked.bool(False), # Print only status=3 particles. This will not work for Pythia8, which does not have any such particles.
 	src = cms.InputTag("genParticles")
	)
process.path = cms.Path(process.printTree)
#process.p = cms.Path(process.demo)

### List decay channel step by step
##process.load("SimGeneral.HepPDTESSource.pythiapdt_cfi")
#process.printTree = cms.EDAnalyzer("ParticleTreeDrawer",
#                                   src = cms.InputTag("genParticles"),                                                                 
#                                   printP4 = cms.untracked.bool(False),
#                                   printPtEtaPhi = cms.untracked.bool(False),
#                                   printVertex = cms.untracked.bool(False),
#                                   printStatus = cms.untracked.bool(False),
#                                   printIndex = cms.untracked.bool(False),
#                                   #status = cms.untracked.vint32( 3 )
#                                   )
#process.p = cms.Path(process.printTree)
#---------------------------------------------------------------------------

// -*- C++ -*-
//
// Package:    DemoAnalyzer
// Class:      DemoAnalyzer
// 
/**\class DemoAnalyzer DemoAnalyzer.cc Demo/DemoAnalyzer/src/DemoAnalyzer.cc

 Description: [one line class summary]

 Implementation:
     [Notes on implementation]
*/
//
// Original Author:  
//         Created:  Mon Jul 11 19:17:42 CEST 2016
// $Id$
//
//


// system include files
#include <memory>
#include <vector>
#include <algorithm>

// user include files
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "FWCore/Framework/interface/EDAnalyzer.h"

#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"

#include "FWCore/ParameterSet/interface/ParameterSet.h"
//
// class declaration
//
// trigger libs: 
#include "FWCore/Common/interface/TriggerNames.h"
#include "DataFormats/Common/interface/TriggerResults.h"
#include "DataFormats/L1GlobalTrigger/interface/L1GlobalTriggerObjectMaps.h"
#include "DataFormats/L1GlobalTrigger/interface/L1GlobalTriggerObjectMap.h"
#include "DataFormats/L1GlobalTrigger/interface/L1GlobalTriggerReadoutRecord.h" 
#include "DataFormats/L1GlobalTrigger/interface/L1GlobalTriggerObjectMapRecord.h"
#include "DataFormats/L1GlobalTrigger/interface/L1GlobalTriggerObjectMapFwd.h"

///
#include "CondFormats/HLTObjects/interface/AlCaRecoTriggerBits.h"
#include "CondFormats/DataRecord/interface/AlCaRecoTriggerBitsRcd.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "DataFormats/Common/interface/Handle.h"
#include "HLTrigger/HLTfilters/interface/HLTHighLevel.h"

#include <typeinfo>
//#include <trigger>
#include "DataFormats/PatCandidates/interface/TriggerEvent.h"
#include "DataFormats/HLTReco/interface/TriggerEvent.h"
/////


class DemoAnalyzer : public edm::EDAnalyzer {
   public:
      explicit DemoAnalyzer(const edm::ParameterSet&);
      ~DemoAnalyzer();

      static void fillDescriptions(edm::ConfigurationDescriptions& descriptions);


   private:
      virtual void beginJob() ;
      virtual void analyze(const edm::Event&, const edm::EventSetup&);
      virtual void endJob() ;

      virtual void beginRun(edm::Run const&, edm::EventSetup const&);
      virtual void endRun(edm::Run const&, edm::EventSetup const&);
      virtual void beginLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&);
      virtual void endLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&);

      // ----------member data ---------------------------
};

//
// constants, enums and typedefs
//

//
// static data member definitions
//

//
// constructors and destructor
//
DemoAnalyzer::DemoAnalyzer(const edm::ParameterSet& iConfig)

{
   //now do what ever initialization is needed

}


DemoAnalyzer::~DemoAnalyzer()
{
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}


//
// member functions
//

// ------------ method called for each event  ------------
void
DemoAnalyzer::analyze(const edm::Event& iEvent, const edm::EventSetup& iSetup)
{

   	using namespace edm;
   	using namespace std;
	using namespace trigger;
///
	edm::ESHandle<AlCaRecoTriggerBits> triggerBits;
	iSetup.get<AlCaRecoTriggerBitsRcd>().get(triggerBits);		

		
	std::cout << typeid(triggerBits).name() << '\n';


	///
	edm::Handle<pat::TriggerEvent> trgEvent;
    	iEvent.getByLabel(InputTag("hltTriggerSummaryAOD","","HLT"), trgEvent);

	std::cout << typeid(trgEvent).name() << '\n';


	edm::Handle<trigger::TriggerEvent> triggerEventHandle_;
	edm::InputTag trigEventTag("hltTriggerSummaryAOD","","HLT");
	iEvent.getByLabel(trigEventTag, triggerEventHandle_);


	std::string filterName("hltSingleJet190Regional"); 

	trigger::size_type filterIndex = triggerEventHandle_->filterIndex(edm::InputTag(filterName,"",trigEventTag.process())); 
	if(filterIndex<triggerEventHandle_->sizeFilters()){ 
    	const trigger::Keys& trigKeys = triggerEventHandle_->filterKeys(filterIndex); 
    	//const trigger::TriggerObjectCollection & trigObjColl(triggerEventHandle_->getObjects());
	    for(trigger::Keys::const_iterator keyIt=trigKeys.begin();keyIt!=trigKeys.end();++keyIt){ 
      		//const trigger::TriggerObject& obj = trigObjColl[*keyIt];
      		cout<<"Hallo here"<<*keyIt<<endl;
		
	}
	}
	
	//string table = trgEvent->nameHltTable();
	//cout<<table<<endl;

///
	/* does not work now
	edm::Handle<L1GlobalTriggerReadoutRecord> gtObjectMapRecord;
	iEvent.getByLabel("gtDigis", gtObjectMapRecord);
	*/
 
      	edm::Handle<L1GlobalTriggerObjectMaps> gtObjectMaps;
      	iEvent.getByLabel("l1L1GtObjectMap", gtObjectMaps);
	
      	// gtObjectMaps->consistencyCheck();	


      	vector<int> bitsN;
      	gtObjectMaps->getAlgorithmBitNumbers(bitsN);
	cout<<"Nbits = "<<bitsN.size()<<endl;
      	// for(unsigned int i=0; i< bitsN.size(); i++) {cout<<bitsN[i]<<endl;}	

	int k = 0;
	for (std::vector<int>::const_iterator iBit = bitsN.begin(), endBits = bitsN.end();
	iBit != endBits; ++iBit) {
	
	cout<<"bit# "<<bitsN[k]<<" : "<<gtObjectMaps->algorithmResult(*iBit)<<"....";
	k++;
	}
	
	cout<<endl;
	
	//edm::InputTag("HBHENoiseFilterResultProducer","HBHENoiseFilterResult")

      	edm::Handle<edm::TriggerResults> triggerResults;
	//iEvent.getByLabel("TriggerResults",triggerResults);
      	iEvent.getByLabel(edm::InputTag("TriggerResults", "", "HLT"),triggerResults);
      	const edm::TriggerNames & triggerNames = iEvent.triggerNames(*triggerResults);
	std::cout<<" Analysis "<<triggerNames.size()<<std::endl;

	//cout<<triggerResults->size()<<endl;

	//if (triggerResults->accept(3)) {cout<<"Accepted! "<<endl;}	


	for(unsigned i= 0; i<triggerNames.size(); i++) 
	{
   		std::cout<<" Trigger name "<<triggerNames.triggerName(i)<<",  Accepted = ";
   		cout<<triggerResults->accept(i)<<endl;
   		//cout<<triggerNames.triggerIndex(triggerNames.triggerName(i))<<endl; 
	}


#ifdef THIS_IS_AN_EVENT_EXAMPLE
   Handle<ExampleData> pIn;
   iEvent.getByLabel("example",pIn);
#endif
   
#ifdef THIS_IS_AN_EVENTSETUP_EXAMPLE
   ESHandle<SetupData> pSetup;
   iSetup.get<SetupRecord>().get(pSetup);
#endif
}


// ------------ method called once each job just before starting event loop  ------------
void 
DemoAnalyzer::beginJob()
{
}

// ------------ method called once each job just after ending the event loop  ------------
void 
DemoAnalyzer::endJob() 
{
}

// ------------ method called when starting to processes a run  ------------
void 
DemoAnalyzer::beginRun(edm::Run const&, edm::EventSetup const&)
{
}

// ------------ method called when ending the processing of a run  ------------
void 
DemoAnalyzer::endRun(edm::Run const&, edm::EventSetup const&)
{
}

// ------------ method called when starting to processes a luminosity block  ------------
void 
DemoAnalyzer::beginLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&)
{
}

// ------------ method called when ending the processing of a luminosity block  ------------
void 
DemoAnalyzer::endLuminosityBlock(edm::LuminosityBlock const&, edm::EventSetup const&)
{
}

// ------------ method fills 'descriptions' with the allowed parameters for the module  ------------
void
DemoAnalyzer::fillDescriptions(edm::ConfigurationDescriptions& descriptions) {
  //The following says we do not know what parameters are allowed so do no validation
  // Please change this to state exactly what you do use, even if it is no parameters
  edm::ParameterSetDescription desc;
  desc.setUnknown();
  descriptions.addDefault(desc);
}

//define this as a plug-in
DEFINE_FWK_MODULE(DemoAnalyzer);
